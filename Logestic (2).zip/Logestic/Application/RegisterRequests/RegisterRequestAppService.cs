using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.RegisterRequests;

namespace Logestic.Application.RegisterRequests
{
    public class RegisterRequestAppService
    {
        private readonly IRegisterRequestRepository _repository;
        private readonly RegisterRequestManager _requestManager;
        public RegisterRequestAppService(IRegisterRequestRepository repository, RegisterRequestManager requestManager) { _repository = repository; _requestManager = requestManager; }

        public async Task<(List<RegisterRequestDto> Items, int TotalCount)> GetListAsync(string? search = null, int? requestType = null, int? requestStatus = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, null, null, fromDate, toDate);
            return (new List<RegisterRequestDto>(), count);
        }
        public async Task<RegisterRequestDto?> GetByIdAsync(int id) => null;
        public async Task<RegisterRequestDto> InsertAsync(CreateRegisterRequestDto dto) => new(0, "", dto.RequestType, dto.ChassisNumber, dto.VehicleId, dto.CustomerId, dto.AgencyId, dto.RequestDate, 0, dto.Description, null);
        public async Task UpdateAsync(int id, UpdateRegisterRequestDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task ChangeStatusAsync(int id, int status) { }
    }

    public record RegisterRequestDto(int Id, string RequestNo, int RequestType, string ChassisNumber, int? VehicleId, int? CustomerId, int? AgencyId, DateTime RequestDate, int RequestStatus, string? Description, DateTime? ProcessedDate);
    public record CreateRegisterRequestDto(int RequestType, string ChassisNumber, int? VehicleId, int? CustomerId, int? AgencyId, DateTime RequestDate, string? Description);
    public record UpdateRegisterRequestDto(int RequestType, string ChassisNumber, int? VehicleId, int? CustomerId, int? AgencyId, string? Description);
}
