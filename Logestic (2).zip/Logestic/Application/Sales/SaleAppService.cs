using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Sales;

namespace Logestic.Application.Sales
{
    public class SaleAppService
    {
        private readonly ISaleRepository _repository;
        private readonly SaleManager _saleManager;
        public SaleAppService(ISaleRepository repository, SaleManager saleManager) { _repository = repository; _saleManager = saleManager; }

        public async Task<(List<SaleDto> Items, int TotalCount)> GetListAsync(string? search = null, int? saleType = null, int? saleStatus = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20) => (new List<SaleDto>(), 0);
        public async Task<SaleDto?> GetByIdAsync(int id) { var s = await _repository.GetSaleByIdAsync(id); return s == null ? null : MapToDto(s); }
        public async Task<SaleDto> InsertAsync(CreateSaleDto dto)
        {
            var sale = new CarSale { SaleNo = dto.SaleNumber, SaleDate = dto.SaleDate, CustomerId = dto.CustomerId, AgencyId = dto.AgencyId, SaleAmount = dto.SaleAmount, Description = dto.Description, IsActive = true };
            await _repository.InsertSaleAsync(sale);
            return MapToDto(sale);
        }
        public async Task UpdateAsync(int id, UpdateSaleDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task ConfirmAsync(int id) { }
        public async Task CancelAsync(int id) { }

        private static SaleDto MapToDto(CarSale s) => new(s.Id, s.SaleNo, s.Description ?? "", null, s.CustomerId ?? 0, s.AgencyId, s.SaleDate, s.SaleAmount, 0, SaleStateType.Pending, s.Description);
    }

    public record SaleDto(int Id, string SaleNumber, string ChassisNumber, int? VehicleId, int CustomerId, int? AgencyId, DateTime SaleDate, decimal SaleAmount, decimal DiscountAmount, SaleStateType State, string? Description);
    public record CreateSaleDto(string SaleNumber, string ChassisNumber, int? VehicleId, int CustomerId, int? AgencyId, DateTime SaleDate, decimal SaleAmount, decimal DiscountAmount, string? Description);
    public record UpdateSaleDto(string SaleNumber, string ChassisNumber, decimal SaleAmount, decimal DiscountAmount, string? Description);
}
