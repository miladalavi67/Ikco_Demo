using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Placements;

namespace Logestic.Application.Placements
{
    public class PlacementAppService
    {
        private readonly IPlacementRepository _repository;
        public PlacementAppService(IPlacementRepository repository) { _repository = repository; }

        public async Task<(List<PlacementDto> Items, int TotalCount)> GetListAsync(string? search = null, int? parkingCode = null, int? zoneCode = null, bool? onlyActive = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetZoneCountAsync(search, onlyActive);
            return (new List<PlacementDto>(), count);
        }
        public async Task<PlacementDto?> GetByIdAsync(int id) => null;
        public async Task<PlacementDto> InsertAsync(CreatePlacementDto dto) => new(0, "", dto.ChassisNumber, dto.VehicleId, dto.ParkingCode, dto.ZoneCode, dto.CellCode, dto.PlacementDate, dto.PaymentAmount, dto.PaymentStatus, false, null, 0);
        public async Task UpdateAsync(int id, UpdatePlacementDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task RelocateAsync(int id, RelocatePlacementDto dto) { }
        public async Task RecordPaymentAsync(int id, decimal amount) { }
        public async Task ReleaseAsync(int id) { }
    }

    public record PlacementDto(int Id, string PlacementNo, string ChassisNumber, int? VehicleId, int ParkingCode, int ZoneCode, string CellCode, DateTime PlacementDate, decimal PaymentAmount, int PaymentStatus, bool IsReleased, DateTime? ReleaseDate, int RelocationCount);
    public record CreatePlacementDto(string ChassisNumber, int? VehicleId, int ParkingCode, int ZoneCode, string CellCode, DateTime PlacementDate, decimal PaymentAmount, int PaymentStatus, string? Description);
    public record UpdatePlacementDto(int ParkingCode, int ZoneCode, string CellCode, string? Description);
    public record RelocatePlacementDto(int NewParkingCode, int NewZoneCode, string NewCellCode);
}
