using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.BaseInfo;

namespace Logestic.Application.BaseInfo
{
    public class BaseInfoAppService
    {
        private readonly IBaseInfoRepository _repository;
        public BaseInfoAppService(IBaseInfoRepository repository) { _repository = repository; }

        public async Task<(List<BaseInfoDto> Items, int TotalCount)> GetListAsync(string? search = null, int? infoType = null, bool? onlyActive = null, int page = 0, int pageSize = 20) => (new List<BaseInfoDto>(), 0);
        public async Task<BaseInfoDto?> GetByIdAsync(int id) => null;
        public async Task<BaseInfoDto> InsertAsync(CreateBaseInfoDto dto) => new(0, dto.InfoType, dto.Code, dto.Title, dto.Description, dto.ParentId, dto.IsActive, dto.SortOrder);
        public async Task UpdateAsync(int id, UpdateBaseInfoDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task<List<Driver>> GetDriversAsync() => new();
        public async Task<List<CarType>> GetCarTypesAsync() => new();
        public async Task<List<object>> GetUserAccessListAsync() => new();
    }

    public record BaseInfoDto(int Id, int InfoType, string Code, string Title, string? Description, int? ParentId, bool IsActive, int SortOrder);
    public record CreateBaseInfoDto(int InfoType, string Code, string Title, string? Description, int? ParentId, bool IsActive, int SortOrder);
    public record UpdateBaseInfoDto(int InfoType, string Code, string Title, string? Description, int? ParentId, bool IsActive, int SortOrder);
}
