using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Logestic.Application.Audits
{
    public class AuditAppService
    {
        public AuditAppService() { }
        public async Task<(List<AuditLogDto> Items, int TotalCount)> GetListAsync(string? search = null, int? actionType = null, int? userId = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20) => (new List<AuditLogDto>(), 0);
        public async Task<AuditLogDto?> GetByIdAsync(int id) => null;
        public async Task<AuditLogDto> InsertAsync(CreateAuditLogDto dto) => new(0, dto.EntityType, dto.EntityId, dto.ActionType, dto.UserId, dto.UserName, dto.ActionDate, dto.OldValues, dto.NewValues, dto.IpAddress);
        public async Task UpdateAsync(int id, UpdateAuditLogDto dto) { }
        public async Task DeleteAsync(int id) { }
    }

    public record AuditLogDto(int Id, string EntityType, int EntityId, int ActionType, int? UserId, string? UserName, DateTime ActionDate, string? OldValues, string? NewValues, string? IpAddress);
    public record CreateAuditLogDto(string EntityType, int EntityId, int ActionType, int? UserId, string? UserName, DateTime ActionDate, string? OldValues, string? NewValues, string? IpAddress);
    public record UpdateAuditLogDto(string EntityType, int EntityId, int ActionType, string? OldValues, string? NewValues);
}
