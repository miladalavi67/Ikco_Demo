using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Technicians;

namespace Logestic.Application.Technicians
{
    public class TechnicianAppService
    {
        private readonly ITechnicianRepository _repository;
        public TechnicianAppService(ITechnicianRepository repository) { _repository = repository; }

        public async Task<(List<TechnicianDto> Items, int TotalCount)> GetListAsync(string? search = null, bool? onlyActive = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, onlyActive);
            return (new List<TechnicianDto>(), count);
        }

        public async Task<TechnicianDto?> GetByIdAsync(int id)
        {
            var t = await _repository.GetByIdAsync(id);
            return t == null ? null : MapToDto(t);
        }

        public async Task<List<TechnicianDto>> GetActiveLookupAsync() => new();

        public async Task<TechnicianDto> InsertAsync(CreateTechnicianDto dto)
        {
            if (await _repository.HasDuplicatePersonnelCodeAsync(dto.PersonnelCode))
                throw new AfterSalesException("AfterSales:DuplicatePersonnelCode", "کد پرسنلی تکراری است.");
            var tech = new Technician { FullName = dto.FullName, PersonnelCode = dto.PersonnelCode, Specialty = dto.Specialty, HourlyRate = dto.HourlyRate, IsActive = dto.IsActive };
            await _repository.InsertAsync(tech);
            return MapToDto(tech);
        }

        public async Task UpdateAsync(int id, UpdateTechnicianDto dto) { }
        public async Task DeleteAsync(int id)
        {
            var isInUse = await _repository.IsInUseAsync(id);
            if (isInUse) throw new AfterSalesException("AfterSales:TechnicianInUse", "تعمیرکار در حال استفاده است.");
        }

        private static TechnicianDto MapToDto(Technician t) => new(t.Id, t.FullName, t.PersonnelCode, t.Specialty, t.HourlyRate, t.IsActive);
    }

    public record TechnicianDto(int TechnicianId, string FullName, string PersonnelCode, string? Specialty, decimal HourlyRate, bool IsActive);
    public record CreateTechnicianDto(string FullName, string PersonnelCode, string? Specialty, decimal HourlyRate, bool IsActive);
    public record UpdateTechnicianDto(string FullName, string PersonnelCode, string? Specialty, decimal HourlyRate, bool IsActive);
}
