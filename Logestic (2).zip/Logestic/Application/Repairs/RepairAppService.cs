using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Repairs;

namespace Logestic.Application.Repairs
{
    public class RepairAppService
    {
        private readonly IRepairRepository _repository;
        private readonly RepairManager _repairManager;
        public RepairAppService(IRepairRepository repository, RepairManager repairManager) { _repository = repository; _repairManager = repairManager; }

        public async Task<(List<RepairDto> Items, int TotalCount)> GetListAsync(string? search = null, int? status = null, int? technicianId = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, null, fromDate, toDate);
            return (new List<RepairDto>(), count);
        }
        public async Task<RepairDto?> GetByIdAsync(int id) => null;
        public async Task<RepairDto> InsertAsync(CreateRepairDto dto) => new(0, dto.ChassisNumber, dto.VehicleId, dto.TechnicianId, dto.RepairType, null, null, 0, false, null, dto.Description);
        public async Task UpdateAsync(int id, UpdateRepairDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task ChangeStatusAsync(int id, int status) { }
    }

    public record RepairDto(int Id, string ChassisNumber, int? VehicleId, int? TechnicianId, string RepairType, DateTime? StartDate, DateTime? EndDate, decimal Cost, bool IsCompleted, DateTime? CompletedDate, string? Description);
    public record CreateRepairDto(string ChassisNumber, int? VehicleId, int? TechnicianId, string RepairType, string? Description);
    public record UpdateRepairDto(int? TechnicianId, string RepairType, string? Description);
}
