using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Pelaks;

namespace Logestic.Application.Pelaks
{
    public class PelakAppService
    {
        private readonly IPelakRepository _repository;
        public PelakAppService(IPelakRepository repository) { _repository = repository; }

        public async Task<(List<PelakDto> Items, int TotalCount)> GetListAsync(string? search = null, int? pelakType = null, int? status = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetPlaceCountAsync(search, null);
            return (new List<PelakDto>(), count);
        }
        public async Task<PelakDto?> GetByIdAsync(int id) => null;
        public async Task<PelakDto> InsertAsync(CreatePelakDto dto) => new(0, dto.PelakNo, dto.ChassisNumber, dto.VehicleId, dto.PelakType, null, dto.IssueDate, null, 0);
        public async Task UpdateAsync(int id, UpdatePelakDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task<PelakDto> RequestNajaNumberingAsync(int id) => new(id, "", "", null, 0, null, DateTime.Now, null, 0);
        public async Task TransferAsync(int id, TransferPelakDto dto) { }
    }

    public record PelakDto(int Id, string PelakNo, string ChassisNumber, int? VehicleId, int PelakType, string? NajaRequestNo, DateTime IssueDate, DateTime? TransferDate, int Status);
    public record CreatePelakDto(string PelakNo, string ChassisNumber, int? VehicleId, int PelakType, DateTime IssueDate, string? Description);
    public record UpdatePelakDto(string PelakNo, string ChassisNumber, int? VehicleId, int PelakType, string? Description);
    public record TransferPelakDto(string NewChassisNumber, int? NewVehicleId, DateTime TransferDate);
}
