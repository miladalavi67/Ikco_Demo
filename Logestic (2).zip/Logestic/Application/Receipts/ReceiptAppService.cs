using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Receipts;

namespace Logestic.Application.Receipts
{
    public class ReceiptAppService
    {
        private readonly IReceiptRepository _repository;
        private readonly ReceiptManager _receiptManager;
        public ReceiptAppService(IReceiptRepository repository, ReceiptManager receiptManager) { _repository = repository; _receiptManager = receiptManager; }

        public async Task<(List<ReceiptDto> Items, int TotalCount)> GetListAsync(string? search = null, int? receiptType = null, bool? onlyConfirmed = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, null, null, fromDate, toDate);
            return (new List<ReceiptDto>(), count);
        }
        public async Task<ReceiptDto?> GetByIdAsync(int id) => null;
        public async Task<ReceiptDto> InsertAsync(CreateReceiptDto dto) => new(0, dto.ReceiptNo, dto.ReceiptType, dto.Amount, dto.PayerName, dto.BankName, dto.ReferenceNo, dto.PaymentDate, false, null);
        public async Task UpdateAsync(int id, UpdateReceiptDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task ConfirmAsync(int id) { }
    }

    public record ReceiptDto(int Id, string ReceiptNo, int ReceiptType, decimal Amount, string? PayerName, string? BankName, string? ReferenceNo, DateTime PaymentDate, bool IsConfirmed, DateTime? ConfirmDate);
    public record CreateReceiptDto(string ReceiptNo, int ReceiptType, decimal Amount, string? PayerName, string? BankName, string? ReferenceNo, DateTime PaymentDate, string? Description);
    public record UpdateReceiptDto(string ReceiptNo, int ReceiptType, decimal Amount, string? PayerName, string? Description);
}
