namespace Logestic.Application
{
    // Placeholder for application service interfaces
}
