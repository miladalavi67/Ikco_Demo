using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.RelapseGateBuffers;

namespace Logestic.Application.RelapseGateBuffers
{
    public class RelapseGateBufferAppService
    {
        private readonly IRelapseGateBufferRepository _repository;
        public RelapseGateBufferAppService(IRelapseGateBufferRepository repository) { _repository = repository; }

        public async Task<(List<RelapseGateBufferDto> Items, int TotalCount)> GetListAsync(string? search = null, int? bufferStatus = null, int? priority = null, int page = 0, int pageSize = 20)
        {
            var items = await _repository.GetListAsync(search, page * pageSize, pageSize);
            return (new List<RelapseGateBufferDto>(), items.Count);
        }
        public async Task<RelapseGateBufferDto?> GetByIdAsync(int id) => null;
        public async Task<RelapseGateBufferDto> InsertAsync(CreateRelapseGateBufferDto dto) => new(0, dto.ChassisNumber, dto.VehicleId, dto.GateOperationId, dto.BufferDate, 1, dto.Priority, dto.Description, null);
        public async Task UpdateAsync(int id, UpdateRelapseGateBufferDto dto) { }
        public async Task DeleteAsync(int id) => await _repository.DeleteAsync(id);
        public async Task ChangeStatusAsync(int id, int status) { }
    }

    public record RelapseGateBufferDto(int Id, string ChassisNumber, int? VehicleId, int? GateOperationId, DateTime BufferDate, int BufferStatus, int Priority, string? Description, DateTime? ProcessedDate);
    public record CreateRelapseGateBufferDto(string ChassisNumber, int? VehicleId, int? GateOperationId, DateTime BufferDate, int Priority, string? Description);
    public record UpdateRelapseGateBufferDto(int Priority, string? Description);
}
