using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Reports;

namespace Logestic.Application.Reports
{
    public class ReportAppService
    {
        private readonly IReportRepository _repository;
        public ReportAppService(IReportRepository repository) { _repository = repository; }

        public async Task<List<TechnicianPerformanceRow>> GetGateReportAsync(DateTime? fromDate, DateTime? toDate, int? gateType, int? operationType) => await _repository.GetTechnicianPerformanceAsync(fromDate, toDate);
        public async Task<List<RevenueByMonthRow>> GetPlacementReportAsync(int? parkingCode, int? zoneCode, bool? onlyActive) => await _repository.GetRevenueByMonthAsync(DateTime.Now.Year);
        public async Task<List<LowStockPartRow>> GetSaleReportAsync(DateTime? fromDate, DateTime? toDate, int? saleType, int? saleStatus) => await _repository.GetLowStockPartsAsync();
        public async Task<List<TechnicianPerformanceRow>> GetFaultReportAsync(int? faultLevel, int? faultSource) => new();
        public async Task<List<RevenueByMonthRow>> GetDeliveryReportAsync(DateTime? fromDate, DateTime? toDate, int? deliveryType, int? deliveryStatus) => new();
        public async Task<List<TechnicianPerformanceRow>> GetRepairReportAsync(DateTime? fromDate, DateTime? toDate, int? status, int? technicianId) => new();
        public async Task<List<LowStockPartRow>> GetPdiReportAsync(DateTime? fromDate, DateTime? toDate, int? qualityStatus) => new();
        public async Task<Dictionary<string, object>> GetDailySummaryAsync(DateTime date) => new();
        public async Task<Dictionary<string, object>> GetMonthlySummaryAsync(int year, int month) => new();
        public async Task<List<LowStockPartRow>> GetPelakReportAsync(int? pelakType, int? status) => new();
        public async Task<List<RevenueByMonthRow>> GetReceiptReportAsync(DateTime? fromDate, DateTime? toDate, int? receiptType, bool? onlyConfirmed) => new();
    }
}
