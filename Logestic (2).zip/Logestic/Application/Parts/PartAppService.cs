using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Parts;

namespace Logestic.Application.Parts
{
    public class PartAppService
    {
        private readonly IPartRepository _partRepository;

        public PartAppService(IPartRepository partRepository)
        {
            _partRepository = partRepository;
        }

        public async Task<List<PartDto>> GetListAsync(string? search = null, bool? onlyLowStock = null, int page = 0, int pageSize = 20)
        {
            var parts = await _partRepository.GetListAsync(search, onlyLowStock, page * pageSize, pageSize);
            var total = await _partRepository.GetCountAsync(search, onlyLowStock);
            return parts.ConvertAll(MapToDto);
        }

        public async Task<PartDto?> GetByIdAsync(int id)
        {
            var part = await _partRepository.GetByIdAsync(id);
            return part == null ? null : MapToDto(part);
        }

        public async Task<PartDto> InsertAsync(CreatePartDto dto)
        {
            var part = new Part
            {
                PartCode = dto.PartCode,
                PartName = dto.PartName,
                UnitPrice = dto.UnitPrice,
                StockQty = dto.StockQty,
                MinStockQty = dto.MinStockQty,
                IsActive = dto.IsActive
            };
            part = await _partRepository.InsertAsync(part);
            return MapToDto(part);
        }

        public async Task UpdateAsync(int id, UpdatePartDto dto)
        {
            var part = await _partRepository.GetByIdAsync(id);
            if (part == null) throw new Exception("Part not found");
            part.PartCode = dto.PartCode;
            part.PartName = dto.PartName;
            part.UnitPrice = dto.UnitPrice;
            part.StockQty = dto.StockQty;
            part.MinStockQty = dto.MinStockQty;
            part.IsActive = dto.IsActive;
            await _partRepository.UpdateAsync(part);
        }

        public async Task DeleteAsync(int id)
        {
            await _partRepository.DeleteAsync(id);
        }

        public async Task<List<PartDto>> GetActiveLookupAsync()
        {
            var parts = await _partRepository.GetActiveLookupAsync();
            return parts.ConvertAll(MapToDto);
        }

        private static PartDto MapToDto(Part part) => new(part.Id, part.PartCode, part.PartName, part.UnitPrice, part.StockQty, part.MinStockQty, part.IsActive, part.IsLowStock);
    }

    public record CreatePartDto(string PartCode, string PartName, decimal UnitPrice, int StockQty, int MinStockQty, bool IsActive);
    public record UpdatePartDto(string PartCode, string PartName, decimal UnitPrice, int StockQty, int MinStockQty, bool IsActive);
    public record PartDto(int PartId, string PartCode, string PartName, decimal UnitPrice, int StockQty, int MinStockQty, bool IsActive, bool IsLowStock);
}
