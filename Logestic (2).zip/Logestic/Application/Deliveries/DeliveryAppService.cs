using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Deliveries;

namespace Logestic.Application.Deliveries
{
    public class DeliveryAppService
    {
        private readonly IDeliveryRepository _repository;
        private readonly DeliveryManager _deliveryManager;
        public DeliveryAppService(IDeliveryRepository repository, DeliveryManager deliveryManager) { _repository = repository; _deliveryManager = deliveryManager; }

        public async Task<(List<DeliveryDto> Items, int TotalCount)> GetListAsync(string? search = null, int? deliveryType = null, int? deliveryStatus = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20) => (new List<DeliveryDto>(), 0);
        public async Task<DeliveryDto?> GetByIdAsync(int id) => null;
        public async Task<DeliveryDto> InsertAsync(CreateDeliveryDto dto) => new(0, "", dto.ChassisNumber, dto.VehicleId, dto.CustomerId, dto.DeliveryType, dto.DeliveryDate, dto.ReceiverName, dto.ReceiverNationalCode, 0, dto.Description, null);
        public async Task UpdateAsync(int id, UpdateDeliveryDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task CompleteAsync(int id) { }
    }

    public record DeliveryDto(int Id, string DeliveryNo, string ChassisNumber, int? VehicleId, int? CustomerId, int DeliveryType, DateTime DeliveryDate, string? ReceiverName, string? ReceiverNationalCode, int DeliveryStatus, string? Description, DateTime? DeliveredDate);
    public record CreateDeliveryDto(string ChassisNumber, int? VehicleId, int? CustomerId, int DeliveryType, DateTime DeliveryDate, string? ReceiverName, string? ReceiverNationalCode, string? Description);
    public record UpdateDeliveryDto(int DeliveryType, string? ReceiverName, string? ReceiverNationalCode, string? Description);
}
