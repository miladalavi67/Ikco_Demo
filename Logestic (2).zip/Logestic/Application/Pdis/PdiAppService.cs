using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Pdis;

namespace Logestic.Application.Pdis
{
    public class PdiAppService
    {
        private readonly IPdiRepository _repository;
        public PdiAppService(IPdiRepository repository) { _repository = repository; }

        public async Task<(List<PdiOperationDto> Items, int TotalCount)> GetListAsync(string? search = null, int? qualityStatus = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, fromDate, toDate, null);
            return (new List<PdiOperationDto>(), count);
        }
        public async Task<PdiOperationDto?> GetByIdAsync(int id) { var p = await _repository.GetByIdAsync(id); return p == null ? null : MapToDto(p); }
        public async Task<PdiOperationDto> InsertAsync(CreatePdiOperationDto dto)
        {
            var pdi = new Pdi { CarLogId = 0, PdiDate = dto.PdiDate, Description = dto.InspectionNotes, UserId = dto.InspectorId };
            await _repository.InsertAsync(pdi);
            return MapToDto(pdi);
        }
        public async Task UpdateAsync(int id, UpdatePdiOperationDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task CompleteAsync(int id, CompletePdiDto dto) { }

        private static PdiOperationDto MapToDto(Pdi p) => new(p.Id, $"PDI-{p.Id}", p.Description ?? "", null, p.PdiDate, p.UserId, p.IsPassed ? 1 : 0, p.Description, 0, p.IsPassed, null);
    }

    public record PdiOperationDto(int Id, string PdiNo, string ChassisNumber, int? VehicleId, DateTime PdiDate, int? InspectorId, int QualityStatus, string? InspectionNotes, int FaultCount, bool IsCompleted, DateTime? CompletedDate);
    public record CreatePdiOperationDto(string ChassisNumber, int? VehicleId, DateTime PdiDate, int? InspectorId, string? InspectionNotes);
    public record UpdatePdiOperationDto(int? InspectorId, string? InspectionNotes);
    public record CompletePdiDto(int QualityStatus, int FaultCount, string? InspectionNotes);
}
