using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.ServiceRequests;

namespace Logestic.Application.ServiceRequests
{
    public class ServiceRequestAppService
    {
        private readonly IServiceRequestRepository _requestRepository;
        private readonly IServiceRequestPartRepository _partRepository;
        private readonly IServiceStatusRepository _statusRepository;
        private readonly ServiceRequestManager _requestManager;

        public ServiceRequestAppService(IServiceRequestRepository requestRepository, IServiceRequestPartRepository partRepository, IServiceStatusRepository statusRepository, ServiceRequestManager requestManager)
        {
            _requestRepository = requestRepository; _partRepository = partRepository;
            _statusRepository = statusRepository; _requestManager = requestManager;
        }

        public async Task<(List<ServiceRequestDto> Items, int TotalCount)> GetListAsync(string? search = null, int? statusId = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20)
        {
            var count = await _requestRepository.GetCountAsync(search, statusId, fromDate, toDate);
            return (new List<ServiceRequestDto>(), count);
        }

        public async Task<ServiceRequestDto?> GetByIdAsync(int id)
        {
            var r = await _requestRepository.GetByIdAsync(id);
            return r == null ? null : MapToDto(r);
        }

        public async Task<ServiceRequestDto> InsertAsync(CreateServiceRequestDto dto)
        {
            var (requestId, requestNo) = await _requestRepository.InsertAsync(dto.VehicleId, dto.TechnicianId, dto.RequestDate, dto.Description, dto.LaborHours, dto.DiscountAmount);
            return new ServiceRequestDto(requestId, requestNo, dto.VehicleId, "", "", 0, "", dto.TechnicianId, "", 0, "", false, dto.RequestDate, dto.Description, dto.LaborHours, 0, 0, dto.DiscountAmount, 0, null);
        }

        public async Task UpdateAsync(int id, UpdateServiceRequestDto dto) { }
        public async Task ChangeStatusAsync(int requestId, int statusId) { }
        public async Task DeleteAsync(int requestId) => await _requestManager.DeleteRequestAsync(requestId);

        public async Task<List<ServiceRequestPartDto>> GetPartsAsync(int requestId)
        {
            var parts = await _partRepository.GetByRequestAsync(requestId);
            return parts.ConvertAll(p => new ServiceRequestPartDto(p.Id, p.RequestId, p.PartId, p.Quantity, p.UnitPrice, p.LineTotal));
        }
        public async Task AddPartAsync(int requestId, int partId, int quantity) => await _requestManager.AddPartAsync(requestId, partId, quantity);
        public async Task RemovePartAsync(int lineId) => await _partRepository.DeleteAsync(lineId);
        public async Task<List<ServiceStatusDto>> GetStatusesAsync()
        {
            var statuses = await _statusRepository.GetAllAsync();
            return statuses.ConvertAll(s => new ServiceStatusDto(s.Id, s.StatusName, s.IsFinal));
        }

        private static ServiceRequestDto MapToDto(ServiceRequest r) => new(r.Id, r.RequestNo, r.VehicleId, "", "", r.CustomerId, "", r.TechnicianId, "", r.StatusId, "", r.IsFinal, r.RequestDate, r.Description, r.LaborHours, r.LaborCost, r.PartsCost, r.DiscountAmount, r.TotalCost, r.CompletedDate);
    }

    public record ServiceRequestDto(int RequestId, string RequestNo, int VehicleId, string PlateNumber, string Model, int CustomerId, string CustomerName, int? TechnicianId, string? TechnicianName, int StatusId, string StatusName, bool IsFinal, DateTime RequestDate, string? Description, decimal LaborHours, decimal LaborCost, decimal PartsCost, decimal DiscountAmount, decimal TotalCost, DateTime? CompletedDate);
    public record CreateServiceRequestDto(int VehicleId, int? TechnicianId, DateTime RequestDate, string? Description, decimal LaborHours, decimal DiscountAmount);
    public record UpdateServiceRequestDto(int VehicleId, int? TechnicianId, DateTime RequestDate, string? Description, decimal LaborHours, decimal DiscountAmount);
    public record ServiceRequestPartDto(int Id, int RequestId, int PartId, int Quantity, decimal UnitPrice, decimal LineTotal);
    public record ServiceStatusDto(int StatusId, string StatusName, bool IsFinal);
}
