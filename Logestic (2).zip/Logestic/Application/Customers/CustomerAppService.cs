using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Customers;

namespace Logestic.Application.Customers
{
    public class CustomerAppService
    {
        private readonly ICustomerRepository _repository;
        private readonly CustomerManager _customerManager;

        public CustomerAppService(ICustomerRepository repository, CustomerManager customerManager)
        {
            _repository = repository;
            _customerManager = customerManager;
        }

        public async Task<(List<CustomerDto> Items, int TotalCount)> GetListAsync(string? search = null, bool? onlyActive = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, onlyActive);
            return (new List<CustomerDto>(), count);
        }

        public async Task<CustomerDto?> GetByIdAsync(int id)
        {
            var customer = await _repository.GetByIdAsync(id);
            if (customer == null) return null;
            var vehicleCount = await _repository.GetVehicleCountAsync(id);
            return MapToDto(customer, vehicleCount);
        }

        public async Task<CustomerDto> InsertAsync(CreateCustomerDto dto)
        {
            if (await _repository.HasDuplicateNationalCodeAsync(dto.NationalCode))
                throw new AfterSalesException(AfterSalesErrorCodes.DuplicateNationalCode, "کد ملی تکراری است.");
            var customer = new Customer
            {
                FullName = dto.FullName, NationalCode = dto.NationalCode, Mobile = dto.Mobile,
                Email = dto.Email, City = dto.City, Address = dto.Address, IsActive = dto.IsActive
            };
            await _repository.InsertAsync(customer);
            return MapToDto(customer);
        }

        public async Task UpdateAsync(int id, UpdateCustomerDto dto) { }
        public async Task DeleteAsync(int id)
        {
            var isInUse = await _repository.IsInUseAsync(id);
            _customerManager.CheckCanDelete(isInUse);
        }
        public async Task<int> GetCompletedRequestCountAsync(int customerId) => await _repository.GetCompletedRequestCountAsync(customerId);

        private static CustomerDto MapToDto(Customer c, int vehicleCount = 0) => new(
            c.Id, c.FullName, c.NationalCode, c.Mobile, c.Email, c.City, c.Address, c.IsActive, vehicleCount);
    }

    public record CustomerDto(int CustomerId, string FullName, string NationalCode, string Mobile, string? Email, string? City, string? Address, bool IsActive, int VehicleCount);
    public record CreateCustomerDto(string FullName, string NationalCode, string Mobile, string? Email, string? City, string? Address, bool IsActive);
    public record UpdateCustomerDto(string FullName, string NationalCode, string Mobile, string? Email, string? City, string? Address, bool IsActive);
}
