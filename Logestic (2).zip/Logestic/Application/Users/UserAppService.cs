using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Users;

namespace Logestic.Application.Users
{
    public class UserAppService
    {
        private readonly IUserRepository _repository;
        public UserAppService(IUserRepository repository) { _repository = repository; }

        public async Task<(List<UserDto> Items, int TotalCount)> GetListAsync(string? search = null, int? roleId = null, int? agencyId = null, bool? onlyActive = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, onlyActive);
            return (new List<UserDto>(), count);
        }
        public async Task<UserDto?> GetByIdAsync(int id) { var u = await _repository.GetByIdAsync(id); return u == null ? null : MapToDto(u); }
        public async Task<UserDto> InsertAsync(CreateUserDto dto)
        {
            if (await _repository.HasDuplicateUserNameAsync(dto.UserName)) throw new System.Exception("Duplicate user name");
            var user = new User { UserName = dto.UserName, FullName = dto.FullName, NationalCode = dto.NationalCode, Mobile = dto.Phone, Email = dto.Email, AgencyId = dto.AgencyId, IsActive = dto.IsActive };
            await _repository.InsertAsync(user);
            return MapToDto(user);
        }
        public async Task UpdateAsync(int id, UpdateUserDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task RecordLoginAsync(int id) { }

        private static UserDto MapToDto(User u) => new(u.Id, u.UserName, u.FullName, u.NationalCode, u.Mobile, u.Email, u.AgencyId, null, u.IsActive);
    }

    public record UserDto(int Id, string UserName, string FullName, string? NationalCode, string? Phone, string? Email, int? AgencyId, string? Role, bool IsActive);
    public record CreateUserDto(string UserName, string FullName, string? NationalCode, string? Phone, string? Email, int? AgencyId, string? Role, bool IsActive);
    public record UpdateUserDto(string UserName, string FullName, string? NationalCode, string? Phone, string? Email, int? AgencyId, string? Role, bool IsActive);
}
