using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Agencies;

namespace Logestic.Application.Agencies
{
    public class AgencyAppService
    {
        private readonly IAgencyRepository _repository;
        public AgencyAppService(IAgencyRepository repository) { _repository = repository; }

        public async Task<(List<AgencyDto> Items, int TotalCount)> GetListAsync(string? search = null, int? agencyType = null, bool? onlyActive = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, null, null, onlyActive);
            return (new List<AgencyDto>(), count);
        }
        public async Task<AgencyDto?> GetByIdAsync(int id) { var a = await _repository.GetByIdAsync(id); return a == null ? null : MapToDto(a); }
        public async Task<AgencyDto> InsertAsync(CreateAgencyDto dto)
        {
            var agency = new Agency { AgencyName = dto.AgencyName, Code = dto.AgencyCode, Address = dto.Address, Phone = dto.Phone, IsActive = dto.IsActive };
            await _repository.InsertAsync(agency);
            return MapToDto(agency);
        }
        public async Task UpdateAsync(int id, UpdateAgencyDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task<List<AgencyDto>> GetActiveLookupAsync() => new();

        private static AgencyDto MapToDto(Agency a) => new(a.Id, a.Code ?? "", a.AgencyName, null, a.Address, a.Phone, null, 0, a.IsActive);
    }

    public record AgencyDto(int Id, string AgencyCode, string AgencyName, string? City, string? Address, string? Phone, string? ManagerName, int AgencyType, bool IsActive);
    public record CreateAgencyDto(string AgencyCode, string AgencyName, string? City, string? Address, string? Phone, string? ManagerName, int AgencyType, bool IsActive);
    public record UpdateAgencyDto(string AgencyCode, string AgencyName, string? City, string? Address, string? Phone, string? ManagerName, int AgencyType, bool IsActive);
}
