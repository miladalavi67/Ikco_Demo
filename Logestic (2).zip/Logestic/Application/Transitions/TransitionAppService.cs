using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Transitions;

namespace Logestic.Application.Transitions
{
    public class TransitionAppService
    {
        private readonly ITransitionRepository _repository;
        public TransitionAppService(ITransitionRepository repository) { _repository = repository; }

        public async Task<(List<TransitionDto> Items, int TotalCount)> GetListAsync(string? search = null, string? flowCode = null, string? moduleName = null, bool? onlyActive = null, int page = 0, int pageSize = 20) => (new List<TransitionDto>(), 0);
        public async Task<TransitionDto?> GetByIdAsync(int id) => null;
        public async Task<List<TransitionDto>> GetByFlowAsync(string flowCode) => new();
        public async Task<TransitionDto> InsertAsync(CreateTransitionDto dto)
        {
            var t = new Transition { FromStepId = dto.FromStepId, ToStepId = dto.ToStepId, TransitionName = dto.TransitionName, IsActive = dto.IsActive };
            await _repository.InsertTransitionAsync(t);
            return new TransitionDto(t.Id, 0, t.FromStepId, t.ToStepId, t.TransitionName, t.IsActive);
        }
        public async Task UpdateAsync(int id, UpdateTransitionDto dto) { }
        public async Task DeleteAsync(int id) { }
    }

    public record TransitionDto(int Id, int FlowId, int FromStepId, int ToStepId, string? TransitionName, bool IsActive);
    public record CreateTransitionDto(int FlowId, int FromStepId, int ToStepId, string? TransitionName, bool IsActive);
    public record UpdateTransitionDto(string? TransitionName, bool IsActive);
}
