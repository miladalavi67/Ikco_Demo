using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Faults;

namespace Logestic.Application.Faults
{
    public class FaultAppService
    {
        private readonly IFaultRepository _repository;
        private readonly FaultManager _faultManager;
        public FaultAppService(IFaultRepository repository, FaultManager faultManager) { _repository = repository; _faultManager = faultManager; }

        public async Task<(List<FaultDto> Items, int TotalCount)> GetListAsync(string? search = null, int? faultLevel = null, int? faultSource = null, bool? onlyActive = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, null, null, null, null);
            return (new List<FaultDto>(), count);
        }
        public async Task<FaultDto?> GetByIdAsync(int id) { var f = await _repository.GetByIdAsync(id); return f == null ? null : MapToDto(f); }
        public async Task<FaultDto> InsertAsync(CreateFaultDto dto)
        {
            var fault = new Fault { CarLogId = 0, FaultDate = System.DateTime.Now, Description = dto.Description, IsResolved = false };
            await _repository.InsertAsync(fault);
            return MapToDto(fault);
        }
        public async Task UpdateAsync(int id, UpdateFaultDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task<List<FaultDto>> GetActiveLookupAsync() => new();

        private static FaultDto MapToDto(Fault f) => new(f.Id, $"F-{f.Id}", f.Description ?? "", f.FaultBodyId ?? 0, f.FaultLevelId, f.FaultSourceId ?? 0, f.Description, !f.IsResolved);
    }

    public record FaultDto(int Id, string FaultCode, string FaultName, int FaultLevel, int? PartId, int FaultSource, string? Description, bool IsActive);
    public record CreateFaultDto(string FaultCode, string FaultName, int FaultLevel, int? PartId, int FaultSource, string? Description, bool IsActive);
    public record UpdateFaultDto(string FaultCode, string FaultName, int FaultLevel, int? PartId, int FaultSource, string? Description, bool IsActive);
}
