using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Vehicles;

namespace Logestic.Application.Vehicles
{
    public class VehicleAppService
    {
        private readonly IVehicleRepository _repository;

        public VehicleAppService(IVehicleRepository repository) { _repository = repository; }

        public async Task<(List<VehicleDto> Items, int TotalCount)> GetListAsync(string? search = null, int? customerId = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, customerId);
            return (new List<VehicleDto>(), count);
        }

        public async Task<VehicleDto?> GetByIdAsync(int id)
        {
            var v = await _repository.GetByIdAsync(id);
            return v == null ? null : MapToDto(v);
        }

        public async Task<VehicleDto> InsertAsync(CreateVehicleDto dto)
        {
            if (await _repository.HasDuplicatePlateAsync(dto.PlateNumber))
                throw new AfterSalesException("AfterSales:DuplicatePlate", "شماره پلاک تکراری است.");
            var vehicle = new Vehicle
            {
                CustomerId = dto.CustomerId, PlateNumber = dto.PlateNumber, Model = dto.Model,
                ProductionYear = dto.ProductionYear, VIN = dto.VIN, Mileage = dto.Mileage
            };
            await _repository.InsertAsync(vehicle);
            return MapToDto(vehicle);
        }

        public async Task UpdateAsync(int id, UpdateVehicleDto dto) { }
        public async Task DeleteAsync(int id)
        {
            var isInUse = await _repository.IsInUseAsync(id);
            if (isInUse) throw new AfterSalesException("AfterSales:VehicleHasRequests", "خودرو در حال استفاده است.");
        }

        private static VehicleDto MapToDto(Vehicle v) => new(v.Id, v.CustomerId, "", v.PlateNumber, v.Model, v.ProductionYear, v.VIN, v.Mileage);
    }

    public record VehicleDto(int VehicleId, int CustomerId, string CustomerName, string PlateNumber, string Model, int ProductionYear, string? VIN, int Mileage);
    public record CreateVehicleDto(int CustomerId, string PlateNumber, string Model, int ProductionYear, string? VIN, int Mileage);
    public record UpdateVehicleDto(int CustomerId, string PlateNumber, string Model, int ProductionYear, string? VIN, int Mileage);
}
