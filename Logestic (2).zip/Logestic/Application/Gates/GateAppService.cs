using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Gates;

namespace Logestic.Application.Gates
{
    public class GateAppService
    {
        private readonly IGateOperationRepository _repository;
        public GateAppService(IGateOperationRepository repository) { _repository = repository; }

        public async Task<(List<GateOperationDto> Items, int TotalCount)> GetListAsync(string? search = null, int? operationType = null, int? gateType = null, DateTime? fromDate = null, DateTime? toDate = null, int page = 0, int pageSize = 20)
        {
            var count = await _repository.GetCountAsync(search, null, null, null, fromDate, toDate);
            return (new List<GateOperationDto>(), count);
        }
        public async Task<GateOperationDto?> GetByIdAsync(int id)
        {
            var op = await _repository.GetByIdAsync(id);
            return op == null ? null : MapToDto(op);
        }
        public async Task<GateOperationDto> InsertAsync(CreateGateOperationDto dto)
        {
            var gate = new EnterGate { CarLogId = 0, AgencyId = dto.AgencyId, EnterDate = dto.OperationDate, Pelak = dto.ChassisNumber, Description = dto.Description, IsActive = true };
            await _repository.InsertEnterAsync(gate);
            return MapToDto(new GateOperation { Id = gate.Id });
        }
        public async Task UpdateAsync(int id, UpdateGateOperationDto dto) { }
        public async Task DeleteAsync(int id) { }
        public async Task<List<GateOperationDto>> GetPendingExitsAsync() => new();

        private static GateOperationDto MapToDto(GateOperation op) => new(op.Id, "", 0, 0, "", null, null, null, null, DateTime.Now, null, false);
    }

    public record GateOperationDto(int Id, string OperationNo, int OperationType, int GateType, string ChassisNumber, string? PlateNumber, int? VehicleId, int? AgencyId, int? DriverId, DateTime OperationDate, string? Description, bool IsFinal);
    public record CreateGateOperationDto(int OperationType, int GateType, string ChassisNumber, string? PlateNumber, int? VehicleId, int? AgencyId, int? DriverId, DateTime OperationDate, string? Description);
    public record UpdateGateOperationDto(int OperationType, int GateType, string ChassisNumber, string? PlateNumber, int? VehicleId, int? AgencyId, int? DriverId, DateTime OperationDate, string? Description);
}
