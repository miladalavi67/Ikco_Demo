using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Infrastructure.Repositories;
using Logestic.Application.Parts;
using Logestic.Application.Customers;
using Logestic.Application.Vehicles;
using Logestic.Application.Technicians;
using Logestic.Application.ServiceRequests;
using Logestic.Application.Gates;
using Logestic.Application.Placements;
using Logestic.Application.Pelaks;
using Logestic.Application.Pdis;
using Logestic.Application.Faults;
using Logestic.Application.Audits;
using Logestic.Application.BaseInfo;
using Logestic.Application.Repairs;
using Logestic.Application.Receipts;
using Logestic.Application.RegisterRequests;
using Logestic.Application.RelapseGateBuffers;
using Logestic.Application.Deliveries;
using Logestic.Application.Sales;
using Logestic.Application.Transitions;
using Logestic.Application.Users;
using Logestic.Application.Agencies;
using Logestic.Application.Reports;
using Logestic.Domain.Parts;
using Logestic.Domain.Customers;
using Logestic.Domain.Vehicles;
using Logestic.Domain.Technicians;
using Logestic.Domain.ServiceRequests;
using Logestic.Domain.Gates;
using Logestic.Domain.Placements;
using Logestic.Domain.Pelaks;
using Logestic.Domain.Pdis;
using Logestic.Domain.Faults;
using Logestic.Domain.Audits;
using Logestic.Domain.BaseInfo;
using Logestic.Domain.Repairs;
using Logestic.Domain.Receipts;
using Logestic.Domain.RegisterRequests;
using Logestic.Domain.RelapseGateBuffers;
using Logestic.Domain.Deliveries;
using Logestic.Domain.Sales;
using Logestic.Domain.Transitions;
using Logestic.Domain.Users;
using Logestic.Domain.Agencies;
using Logestic.Domain.Reports;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// --- DbContext ---
builder.Services.AddDbContext<AfterSalesDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("Default")));

// --- Repository Interfaces → Implementations (DI) ---
builder.Services.AddScoped<IPartRepository, EfCorePartRepository>();
builder.Services.AddScoped<ICustomerRepository, EfCoreCustomerRepository>();
builder.Services.AddScoped<IVehicleRepository, EfCoreVehicleRepository>();
builder.Services.AddScoped<ITechnicianRepository, EfCoreTechnicianRepository>();
builder.Services.AddScoped<IServiceRequestRepository, DapperServiceRequestRepository>();
builder.Services.AddScoped<IServiceRequestPartRepository, EfCoreServiceRequestPartRepository>();
builder.Services.AddScoped<IServiceStatusRepository, EfCoreServiceStatusRepository>();

// Modules migrated from Logestic
builder.Services.AddScoped<IGateOperationRepository, DapperGateRepository>();
builder.Services.AddScoped<IPlacementRepository, DapperPlacementRepository>();
builder.Services.AddScoped<IPelakRepository, DapperPelakRepository>();
builder.Services.AddScoped<IPdiRepository, DapperPdiRepository>();
builder.Services.AddScoped<IFaultRepository, EfCoreFaultRepository>();
builder.Services.AddScoped<IAuditRepository, EfCoreAuditRepository>();
builder.Services.AddScoped<IBaseInfoRepository, EfCoreBaseInfoRepository>();
builder.Services.AddScoped<IRepairRepository, DapperRepairRepository>();
builder.Services.AddScoped<IReceiptRepository, DapperReceiptRepository>();
builder.Services.AddScoped<IRegisterRequestRepository, DapperRegisterRequestRepository>();
builder.Services.AddScoped<IRelapseGateBufferRepository, EfCoreRelapseGateBufferRepository>();
builder.Services.AddScoped<IDeliveryRepository, DapperDeliveryRepository>();
builder.Services.AddScoped<ISaleRepository, EfCoreSaleRepository>();
builder.Services.AddScoped<ITransitionRepository, EfCoreTransitionRepository>();
builder.Services.AddScoped<IUserRepository, EfCoreUserRepository>();
builder.Services.AddScoped<IAgencyRepository, EfCoreAgencyRepository>();
builder.Services.AddScoped<IReportRepository, DapperReportRepository>();

// --- Domain Managers (from Domain) ---
builder.Services.AddScoped<CustomerManager>();
builder.Services.AddScoped<PartManager>();
builder.Services.AddScoped<ServiceRequestManager>();

// --- Application-layer Managers ---
builder.Services.AddScoped<FaultManager>();
builder.Services.AddScoped<DeliveryManager>();
builder.Services.AddScoped<SaleManager>();
builder.Services.AddScoped<RepairManager>();
builder.Services.AddScoped<ReceiptManager>();
builder.Services.AddScoped<RegisterRequestManager>();

// --- Application Services ---
builder.Services.AddScoped<PartAppService>();
builder.Services.AddScoped<CustomerAppService>();
builder.Services.AddScoped<VehicleAppService>();
builder.Services.AddScoped<TechnicianAppService>();
builder.Services.AddScoped<ServiceRequestAppService>();
builder.Services.AddScoped<GateAppService>();
builder.Services.AddScoped<PlacementAppService>();
builder.Services.AddScoped<PelakAppService>();
builder.Services.AddScoped<PdiAppService>();
builder.Services.AddScoped<FaultAppService>();
builder.Services.AddScoped<AuditAppService>();
builder.Services.AddScoped<BaseInfoAppService>();
builder.Services.AddScoped<RepairAppService>();
builder.Services.AddScoped<ReceiptAppService>();
builder.Services.AddScoped<RegisterRequestAppService>();
builder.Services.AddScoped<RelapseGateBufferAppService>();
builder.Services.AddScoped<DeliveryAppService>();
builder.Services.AddScoped<SaleAppService>();
builder.Services.AddScoped<TransitionAppService>();
builder.Services.AddScoped<UserAppService>();
builder.Services.AddScoped<AgencyAppService>();
builder.Services.AddScoped<ReportAppService>();

var app = builder.Build();

// --- Middleware ---
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();

// --- Apply migration on startup ---
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AfterSalesDbContext>();
    db.Database.Migrate();
}

app.Run();
