using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.Agencies;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر نمایندگی. مدیریت نمایندگی‌های اصلی، شعبه و نماینده.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class AgencyController : ControllerBase
    {
        private readonly AgencyAppService _appService;

        public AgencyController(AgencyAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? agencyType = null,
            [FromQuery] bool? onlyActive = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, agencyType, onlyActive, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var agency = await _appService.GetByIdAsync(id);
            return agency == null ? NotFound() : Ok(agency);
        }

        [HttpGet("lookup/active")]
        public async Task<IActionResult> GetActiveLookup()
        {
            var agencies = await _appService.GetActiveLookupAsync();
            return Ok(agencies);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateAgencyDto dto)
        {
            var agency = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = agency.Id }, agency);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateAgencyDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
