using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.Transitions;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر انتقال. مدیریت جریان‌ها، مراحل و انتقالات بین مراحل.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class TransitionController : ControllerBase
    {
        private readonly TransitionAppService _appService;

        public TransitionController(TransitionAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] string? flowCode = null,
            [FromQuery] string? moduleName = null,
            [FromQuery] bool? onlyActive = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, flowCode, moduleName, onlyActive, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var transition = await _appService.GetByIdAsync(id);
            return transition == null ? NotFound() : Ok(transition);
        }

        [HttpGet("flow/{flowCode}")]
        public async Task<IActionResult> GetByFlow(string flowCode)
        {
            var transitions = await _appService.GetByFlowAsync(flowCode);
            return Ok(transitions);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateTransitionDto dto)
        {
            var transition = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = transition.Id }, transition);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateTransitionDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
