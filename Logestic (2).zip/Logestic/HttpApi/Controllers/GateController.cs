using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Gates;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر عملیات درب. شامل ورود، خروج و برگشت برای انواع نمایندگی، شهرستان، حضوری مستقیم و عادی.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class GateController : ControllerBase
    {
        private readonly GateAppService _appService;

        public GateController(GateAppService appService) => _appService = appService;

        /// <summary>
        /// دریافت لیست عملیات درب با فیلتر و صفحه‌بندی.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? operationType = null,
            [FromQuery] int? gateType = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, operationType, gateType, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        /// <summary>
        /// دریافت یک عملیات درب بر اساس شناسه.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var operation = await _appService.GetByIdAsync(id);
            return operation == null ? NotFound() : Ok(operation);
        }

        /// <summary>
        /// ثبت ورود خودرو به درب.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateGateOperationDto dto)
        {
            var operation = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = operation.Id }, operation);
        }

        /// <summary>
        /// به‌روزرسانی عملیات درب.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateGateOperationDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        /// <summary>
        /// حذف عملیات درب.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// دریافت لیست خروج‌های در انتظار.
        /// </summary>
        [HttpGet("pending-exits")]
        public async Task<IActionResult> GetPendingExits()
        {
            var items = await _appService.GetPendingExitsAsync();
            return Ok(items);
        }
    }
}
