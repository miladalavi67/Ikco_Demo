using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.ServiceRequests;

namespace Logestic.HttpApi.ServiceRequests
{
    [ApiController]
    [Route("api/[controller]")]
    public class ServiceRequestController : ControllerBase
    {
        private readonly ServiceRequestAppService _appService;

        public ServiceRequestController(ServiceRequestAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null, [FromQuery] int? statusId = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0, [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, statusId, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var request = await _appService.GetByIdAsync(id);
            return request == null ? NotFound() : Ok(request);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateServiceRequestDto dto)
        {
            var request = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = request.RequestId }, request);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateServiceRequestDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        [HttpPost("{id}/status")]
        public async Task<IActionResult> ChangeStatus(int id, [FromQuery] int statusId)
        {
            await _appService.ChangeStatusAsync(id, statusId);
            return NoContent();
        }

        [HttpGet("{id}/parts")]
        public async Task<IActionResult> GetParts(int id)
        {
            var parts = await _appService.GetPartsAsync(id);
            return Ok(parts);
        }

        [HttpPost("{id}/parts")]
        public async Task<IActionResult> AddPart(int id, [FromQuery] int partId, [FromQuery] int quantity)
        {
            await _appService.AddPartAsync(id, partId, quantity);
            return NoContent();
        }

        [HttpDelete("parts/{lineId}")]
        public async Task<IActionResult> RemovePart(int lineId)
        {
            await _appService.RemovePartAsync(lineId);
            return NoContent();
        }

        [HttpGet("statuses")]
        public async Task<IActionResult> GetStatuses()
        {
            var statuses = await _appService.GetStatusesAsync();
            return Ok(statuses);
        }
    }
}
