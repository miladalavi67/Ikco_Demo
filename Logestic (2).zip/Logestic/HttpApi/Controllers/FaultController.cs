using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.Faults;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر ایراد. مدیریت ایرادها، سطوح ایراد، قطعات و منشأ ایراد.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class FaultController : ControllerBase
    {
        private readonly FaultAppService _appService;

        public FaultController(FaultAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? faultLevel = null,
            [FromQuery] int? faultSource = null,
            [FromQuery] bool? onlyActive = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, faultLevel, faultSource, onlyActive, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var fault = await _appService.GetByIdAsync(id);
            return fault == null ? NotFound() : Ok(fault);
        }

        [HttpGet("lookup/active")]
        public async Task<IActionResult> GetActiveLookup()
        {
            var faults = await _appService.GetActiveLookupAsync();
            return Ok(faults);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateFaultDto dto)
        {
            var fault = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = fault.Id }, fault);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateFaultDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
