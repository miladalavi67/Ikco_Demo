using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Audits;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر ممیزی. ثبت و پرس‌وجو تغییرات داده‌ای.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class AuditController : ControllerBase
    {
        private readonly AuditAppService _appService;

        public AuditController(AuditAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? actionType = null,
            [FromQuery] int? userId = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, actionType, userId, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var log = await _appService.GetByIdAsync(id);
            return log == null ? NotFound() : Ok(log);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateAuditLogDto dto)
        {
            var log = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = log.Id }, log);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateAuditLogDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
