using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Pdis;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر عملیات PDI. شامل بررسی‌های کیفی و کنترل کیفیت خودرو.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class PdiController : ControllerBase
    {
        private readonly PdiAppService _appService;

        public PdiController(PdiAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? qualityStatus = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, qualityStatus, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var pdi = await _appService.GetByIdAsync(id);
            return pdi == null ? NotFound() : Ok(pdi);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreatePdiOperationDto dto)
        {
            var pdi = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = pdi.Id }, pdi);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePdiOperationDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// تکمیل عملیات PDI با تعیین وضعیت کیفی.
        /// </summary>
        [HttpPost("{id}/complete")]
        public async Task<IActionResult> Complete(int id, [FromBody] CompletePdiDto dto)
        {
            await _appService.CompleteAsync(id, dto);
            return NoContent();
        }
    }
}
