using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.RelapseGateBuffers;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر بافر درب برگشت. مدیریت صف برگشت خودروها از درب.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class RelapseGateBufferController : ControllerBase
    {
        private readonly RelapseGateBufferAppService _appService;

        public RelapseGateBufferController(RelapseGateBufferAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? bufferStatus = null,
            [FromQuery] int? priority = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, bufferStatus, priority, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var buffer = await _appService.GetByIdAsync(id);
            return buffer == null ? NotFound() : Ok(buffer);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateRelapseGateBufferDto dto)
        {
            var buffer = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = buffer.Id }, buffer);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateRelapseGateBufferDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// تغییر وضعیت بافر.
        /// </summary>
        [HttpPost("{id}/status")]
        public async Task<IActionResult> ChangeStatus(int id, [FromQuery] int status)
        {
            await _appService.ChangeStatusAsync(id, status);
            return NoContent();
        }
    }
}
