using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.Vehicles;

namespace Logestic.HttpApi.Vehicles
{
    [ApiController]
    [Route("api/[controller]")]
    public class VehicleController : ControllerBase
    {
        private readonly VehicleAppService _appService;

        public VehicleController(VehicleAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null, [FromQuery] int? customerId = null,
            [FromQuery] int page = 0, [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, customerId, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var vehicle = await _appService.GetByIdAsync(id);
            return vehicle == null ? NotFound() : Ok(vehicle);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateVehicleDto dto)
        {
            var vehicle = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = vehicle.VehicleId }, vehicle);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateVehicleDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
