using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.RegisterRequests;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر درخواست ثبت. مدیریت درخواست‌های ثبت برای انواع نمایندگی، شهرستان، حضوری مستقیم و عادی.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class RegisterRequestController : ControllerBase
    {
        private readonly RegisterRequestAppService _appService;

        public RegisterRequestController(RegisterRequestAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? requestType = null,
            [FromQuery] int? requestStatus = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, requestType, requestStatus, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var request = await _appService.GetByIdAsync(id);
            return request == null ? NotFound() : Ok(request);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateRegisterRequestDto dto)
        {
            var request = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = request.Id }, request);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateRegisterRequestDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// تغییر وضعیت درخواست ثبت (تایید/رد/تکمیل).
        /// </summary>
        [HttpPost("{id}/status")]
        public async Task<IActionResult> ChangeStatus(int id, [FromQuery] int status)
        {
            await _appService.ChangeStatusAsync(id, status);
            return NoContent();
        }
    }
}
