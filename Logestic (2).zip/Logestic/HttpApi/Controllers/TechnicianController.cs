using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.Technicians;

namespace Logestic.HttpApi.Technicians
{
    [ApiController]
    [Route("api/[controller]")]
    public class TechnicianController : ControllerBase
    {
        private readonly TechnicianAppService _appService;

        public TechnicianController(TechnicianAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null, [FromQuery] bool? onlyActive = null,
            [FromQuery] int page = 0, [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, onlyActive, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("lookup/active")]
        public async Task<IActionResult> GetActiveLookup()
        {
            var items = await _appService.GetActiveLookupAsync();
            return Ok(items);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var tech = await _appService.GetByIdAsync(id);
            return tech == null ? NotFound() : Ok(tech);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateTechnicianDto dto)
        {
            var tech = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = tech.TechnicianId }, tech);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateTechnicianDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
