using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.BaseInfo;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر اطلاعات پایه. مدیریت رانندگان، انواع خودرو و دسترسی کاربران.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class BaseInfoController : ControllerBase
    {
        private readonly BaseInfoAppService _appService;

        public BaseInfoController(BaseInfoAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? infoType = null,
            [FromQuery] bool? onlyActive = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, infoType, onlyActive, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var info = await _appService.GetByIdAsync(id);
            return info == null ? NotFound() : Ok(info);
        }

        [HttpGet("drivers")]
        public async Task<IActionResult> GetDrivers()
        {
            var drivers = await _appService.GetDriversAsync();
            return Ok(drivers);
        }

        [HttpGet("car-types")]
        public async Task<IActionResult> GetCarTypes()
        {
            var carTypes = await _appService.GetCarTypesAsync();
            return Ok(carTypes);
        }

        [HttpGet("user-access")]
        public async Task<IActionResult> GetUserAccessList()
        {
            var accessList = await _appService.GetUserAccessListAsync();
            return Ok(accessList);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateBaseInfoDto dto)
        {
            var info = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = info.Id }, info);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateBaseInfoDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
