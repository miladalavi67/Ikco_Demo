using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.Customers;

namespace Logestic.HttpApi.Customers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly CustomerAppService _appService;

        public CustomerController(CustomerAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null, [FromQuery] bool? onlyActive = null,
            [FromQuery] int page = 0, [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, onlyActive, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var customer = await _appService.GetByIdAsync(id);
            return customer == null ? NotFound() : Ok(customer);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateCustomerDto dto)
        {
            var customer = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = customer.CustomerId }, customer);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateCustomerDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
