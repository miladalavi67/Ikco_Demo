using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Sales;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر فروش. مدیریت فروش خودرو، فاکتورها و لاگ‌های فروش.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class SaleController : ControllerBase
    {
        private readonly SaleAppService _appService;

        public SaleController(SaleAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? saleType = null,
            [FromQuery] int? saleStatus = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, saleType, saleStatus, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var sale = await _appService.GetByIdAsync(id);
            return sale == null ? NotFound() : Ok(sale);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateSaleDto dto)
        {
            var sale = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = sale.Id }, sale);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateSaleDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// تایید فروش.
        /// </summary>
        [HttpPost("{id}/confirm")]
        public async Task<IActionResult> Confirm(int id)
        {
            await _appService.ConfirmAsync(id);
            return NoContent();
        }

        /// <summary>
        /// لغو فروش.
        /// </summary>
        [HttpPost("{id}/cancel")]
        public async Task<IActionResult> Cancel(int id)
        {
            await _appService.CancelAsync(id);
            return NoContent();
        }
    }
}
