using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Reports;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر گزارش. تمام کوئری‌های فقط‌خواندنی گزارش‌ها از اینجا انجام می‌شود.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class ReportController : ControllerBase
    {
        private readonly ReportAppService _appService;

        public ReportController(ReportAppService appService) => _appService = appService;

        /// <summary>
        /// گزارش عملیات درب.
        /// </summary>
        [HttpGet("gate")]
        public async Task<IActionResult> GetGateReport(
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int? gateType = null,
            [FromQuery] int? operationType = null)
        {
            var report = await _appService.GetGateReportAsync(fromDate, toDate, gateType, operationType);
            return Ok(report);
        }

        /// <summary>
        /// گزارش جای‌گذاری.
        /// </summary>
        [HttpGet("placement")]
        public async Task<IActionResult> GetPlacementReport(
            [FromQuery] int? parkingCode = null,
            [FromQuery] int? zoneCode = null,
            [FromQuery] bool? onlyActive = null)
        {
            var report = await _appService.GetPlacementReportAsync(parkingCode, zoneCode, onlyActive);
            return Ok(report);
        }

        /// <summary>
        /// گزارش فروش.
        /// </summary>
        [HttpGet("sale")]
        public async Task<IActionResult> GetSaleReport(
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int? saleType = null,
            [FromQuery] int? saleStatus = null)
        {
            var report = await _appService.GetSaleReportAsync(fromDate, toDate, saleType, saleStatus);
            return Ok(report);
        }

        /// <summary>
        /// گزارش ایرادها.
        /// </summary>
        [HttpGet("fault")]
        public async Task<IActionResult> GetFaultReport(
            [FromQuery] int? faultLevel = null,
            [FromQuery] int? faultSource = null)
        {
            var report = await _appService.GetFaultReportAsync(faultLevel, faultSource);
            return Ok(report);
        }

        /// <summary>
        /// گزارش تحویل.
        /// </summary>
        [HttpGet("delivery")]
        public async Task<IActionResult> GetDeliveryReport(
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int? deliveryType = null,
            [FromQuery] int? deliveryStatus = null)
        {
            var report = await _appService.GetDeliveryReportAsync(fromDate, toDate, deliveryType, deliveryStatus);
            return Ok(report);
        }

        /// <summary>
        /// گزارش تعمیرات.
        /// </summary>
        [HttpGet("repair")]
        public async Task<IActionResult> GetRepairReport(
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int? status = null,
            [FromQuery] int? technicianId = null)
        {
            var report = await _appService.GetRepairReportAsync(fromDate, toDate, status, technicianId);
            return Ok(report);
        }

        /// <summary>
        /// گزارش PDI.
        /// </summary>
        [HttpGet("pdi")]
        public async Task<IActionResult> GetPdiReport(
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int? qualityStatus = null)
        {
            var report = await _appService.GetPdiReportAsync(fromDate, toDate, qualityStatus);
            return Ok(report);
        }

        /// <summary>
        /// خلاصه روزانه.
        /// </summary>
        [HttpGet("daily-summary")]
        public async Task<IActionResult> GetDailySummary([FromQuery] DateTime date)
        {
            var summary = await _appService.GetDailySummaryAsync(date);
            return Ok(summary);
        }

        /// <summary>
        /// خلاصه ماهانه.
        /// </summary>
        [HttpGet("monthly-summary")]
        public async Task<IActionResult> GetMonthlySummary([FromQuery] int year, [FromQuery] int month)
        {
            var summary = await _appService.GetMonthlySummaryAsync(year, month);
            return Ok(summary);
        }

        /// <summary>
        /// گزارش پلاک‌ها.
        /// </summary>
        [HttpGet("pelak")]
        public async Task<IActionResult> GetPelakReport(
            [FromQuery] int? pelakType = null,
            [FromQuery] int? status = null)
        {
            var report = await _appService.GetPelakReportAsync(pelakType, status);
            return Ok(report);
        }

        /// <summary>
        /// گزارش رسیدها.
        /// </summary>
        [HttpGet("receipt")]
        public async Task<IActionResult> GetReceiptReport(
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int? receiptType = null,
            [FromQuery] bool? onlyConfirmed = null)
        {
            var report = await _appService.GetReceiptReportAsync(fromDate, toDate, receiptType, onlyConfirmed);
            return Ok(report);
        }
    }
}
