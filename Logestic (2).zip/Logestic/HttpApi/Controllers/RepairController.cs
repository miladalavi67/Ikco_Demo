using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Repairs;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر تعمیر. مدیریت عملیات تعمیر، هزینه‌ها و وضعیت‌ها.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class RepairController : ControllerBase
    {
        private readonly RepairAppService _appService;

        public RepairController(RepairAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? status = null,
            [FromQuery] int? technicianId = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, status, technicianId, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var repair = await _appService.GetByIdAsync(id);
            return repair == null ? NotFound() : Ok(repair);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateRepairDto dto)
        {
            var repair = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = repair.Id }, repair);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateRepairDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// تغییر وضعیت تعمیر.
        /// </summary>
        [HttpPost("{id}/status")]
        public async Task<IActionResult> ChangeStatus(int id, [FromQuery] int status)
        {
            await _appService.ChangeStatusAsync(id, status);
            return NoContent();
        }
    }
}
