using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Placements;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر جای‌گذاری. مدیریت پارکینگ، سلول‌ها، زون‌ها، جابه‌جایی و پرداخت‌ها.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class PlacementController : ControllerBase
    {
        private readonly PlacementAppService _appService;

        public PlacementController(PlacementAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? parkingCode = null,
            [FromQuery] int? zoneCode = null,
            [FromQuery] bool? onlyActive = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, parkingCode, zoneCode, onlyActive, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var placement = await _appService.GetByIdAsync(id);
            return placement == null ? NotFound() : Ok(placement);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreatePlacementDto dto)
        {
            var placement = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = placement.Id }, placement);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePlacementDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// جابه‌جایی خودرو از یک سلول به سلول دیگر.
        /// </summary>
        [HttpPost("{id}/relocate")]
        public async Task<IActionResult> Relocate(int id, [FromBody] RelocatePlacementDto dto)
        {
            await _appService.RelocateAsync(id, dto);
            return NoContent();
        }

        /// <summary>
        /// ثبت پرداخت برای جای‌گذاری.
        /// </summary>
        [HttpPost("{id}/payment")]
        public async Task<IActionResult> RecordPayment(int id, [FromQuery] decimal amount)
        {
            await _appService.RecordPaymentAsync(id, amount);
            return NoContent();
        }

        /// <summary>
        /// آزاد کردن جای‌گذاری (خروج خودرو از پارکینگ).
        /// </summary>
        [HttpPost("{id}/release")]
        public async Task<IActionResult> Release(int id)
        {
            await _appService.ReleaseAsync(id);
            return NoContent();
        }
    }
}
