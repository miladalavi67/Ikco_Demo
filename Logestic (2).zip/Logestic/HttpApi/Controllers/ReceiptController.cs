using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Receipts;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر رسید. مدیریت رسیدهای پرداختی و تایید آن‌ها.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class ReceiptController : ControllerBase
    {
        private readonly ReceiptAppService _appService;

        public ReceiptController(ReceiptAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? receiptType = null,
            [FromQuery] bool? onlyConfirmed = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, receiptType, onlyConfirmed, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var receipt = await _appService.GetByIdAsync(id);
            return receipt == null ? NotFound() : Ok(receipt);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateReceiptDto dto)
        {
            var receipt = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = receipt.Id }, receipt);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateReceiptDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// تایید رسید.
        /// </summary>
        [HttpPost("{id}/confirm")]
        public async Task<IActionResult> Confirm(int id)
        {
            await _appService.ConfirmAsync(id);
            return NoContent();
        }
    }
}
