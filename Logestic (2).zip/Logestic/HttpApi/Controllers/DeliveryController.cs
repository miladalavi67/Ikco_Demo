using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Deliveries;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر تحویل. مدیریت تحویل خودرو به مشتریان و نمایندگی‌ها.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class DeliveryController : ControllerBase
    {
        private readonly DeliveryAppService _appService;

        public DeliveryController(DeliveryAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? deliveryType = null,
            [FromQuery] int? deliveryStatus = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, deliveryType, deliveryStatus, fromDate, toDate, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var delivery = await _appService.GetByIdAsync(id);
            return delivery == null ? NotFound() : Ok(delivery);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateDeliveryDto dto)
        {
            var delivery = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = delivery.Id }, delivery);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateDeliveryDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// تکمیل تحویل (تحویل خودرو به دریافت‌کننده).
        /// </summary>
        [HttpPost("{id}/complete")]
        public async Task<IActionResult> Complete(int id)
        {
            await _appService.CompleteAsync(id);
            return NoContent();
        }
    }
}
