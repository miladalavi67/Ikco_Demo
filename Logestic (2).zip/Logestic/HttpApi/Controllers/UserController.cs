using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Logestic.Application.Users;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر کاربر. مدیریت کاربران سیستم، نقش‌ها و دسترسی‌ها.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly UserAppService _appService;

        public UserController(UserAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? roleId = null,
            [FromQuery] int? agencyId = null,
            [FromQuery] bool? onlyActive = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, roleId, agencyId, onlyActive, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var user = await _appService.GetByIdAsync(id);
            return user == null ? NotFound() : Ok(user);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreateUserDto dto)
        {
            var user = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = user.Id }, user);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateUserDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// ثبت زمان ورود به سیستم.
        /// </summary>
        [HttpPost("{id}/login")]
        public async Task<IActionResult> RecordLogin(int id)
        {
            await _appService.RecordLoginAsync(id);
            return NoContent();
        }
    }
}
