using Microsoft.AspNetCore.Mvc;
using Logestic.Application.Parts;
using System.Threading.Tasks;

namespace Logestic.HttpApi.Parts
{
    [ApiController]
    [Route("api/[controller]")]
    public class PartController : ControllerBase
    {
        private readonly PartAppService _appService;

        public PartController(PartAppService appService)
        {
            _appService = appService;
        }

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] bool? onlyLowStock = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var result = await _appService.GetListAsync(search, onlyLowStock, page, pageSize);
            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var part = await _appService.GetByIdAsync(id);
            if (part == null) return NotFound();
            return Ok(part);
        }

        [HttpGet("lookup/active")]
        public async Task<IActionResult> GetActiveLookup()
        {
            var parts = await _appService.GetActiveLookupAsync();
            return Ok(parts);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreatePartDto dto)
        {
            var part = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = part.PartId }, part);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePartDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }
    }
}
