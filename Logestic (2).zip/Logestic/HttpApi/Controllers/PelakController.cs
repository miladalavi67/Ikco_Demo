using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Logestic.Application.Pelaks;

namespace Logestic.HttpApi.Controllers
{
    /// <summary>
    /// کنترلر پلاک. مدیریت پلاک‌ها، شماره‌گذاری، یکپارچه‌سازی با ناجا و انتقالات.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class PelakController : ControllerBase
    {
        private readonly PelakAppService _appService;

        public PelakController(PelakAppService appService) => _appService = appService;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? search = null,
            [FromQuery] int? pelakType = null,
            [FromQuery] int? status = null,
            [FromQuery] int page = 0,
            [FromQuery] int pageSize = 20)
        {
            var (items, total) = await _appService.GetListAsync(search, pelakType, status, page, pageSize);
            return Ok(new { items, total });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var pelak = await _appService.GetByIdAsync(id);
            return pelak == null ? NotFound() : Ok(pelak);
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] CreatePelakDto dto)
        {
            var pelak = await _appService.InsertAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = pelak.Id }, pelak);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePelakDto dto)
        {
            await _appService.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _appService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// ثبت درخواست شماره‌گذاری پلاک در ناجا.
        /// </summary>
        [HttpPost("{id}/naja-numbering")]
        public async Task<IActionResult> RequestNajaNumbering(int id)
        {
            var pelak = await _appService.RequestNajaNumberingAsync(id);
            return Ok(pelak);
        }

        /// <summary>
        /// انتقال پلاک از یک خودرو به خودروی دیگر.
        /// </summary>
        [HttpPost("{id}/transfer")]
        public async Task<IActionResult> Transfer(int id, [FromBody] TransferPelakDto dto)
        {
            await _appService.TransferAsync(id, dto);
            return NoContent();
        }
    }
}
