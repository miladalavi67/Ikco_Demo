using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Repairs;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperRepairRepository : IRepairRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperRepairRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetCountAsync(string? chassis = null, bool? completed = null, DateTime? fromDate = null, DateTime? toDate = null)
        {
            var query = _context.Repairs.AsQueryable();
            if (!string.IsNullOrWhiteSpace(chassis)) query = query.Where(r => r.Description != null && r.Description.Contains(chassis));
            if (completed.HasValue) query = query.Where(r => r.IsCompleted == completed.Value);
            if (fromDate.HasValue) query = query.Where(r => r.RepairDate >= fromDate.Value);
            if (toDate.HasValue) query = query.Where(r => r.RepairDate < toDate.Value.AddDays(1));
            return await query.CountAsync();
        }

        public async Task<RepairOperation?> GetByIdAsync(int id)
        {
            var e = await _context.Repairs.FindAsync(id);
            return e == null ? null : new RepairOperation { Id = e.Id, RefId = e.CarLogId };
        }

        public async Task<RepairOperation> InsertAsync(RepairOperation repair)
        {
            var entity = new RepairEntity
            {
                CarLogId = repair.RefId, RepairDate = DateTime.Now, IsCompleted = false
            };
            _context.Repairs.Add(entity);
            await _context.SaveChangesAsync();
            repair.Id = entity.Id;
            repair.RefId = entity.CarLogId;
            return repair;
        }
    }
}
