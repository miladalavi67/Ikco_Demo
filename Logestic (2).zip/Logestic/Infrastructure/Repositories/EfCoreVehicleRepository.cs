using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain;
using Logestic.Domain.Vehicles;

namespace Logestic.Infrastructure.Repositories
{
    /// <summary>
    /// پیاده‌سازی ریپازیتوری خودرو با EF Core / LINQ.
    /// </summary>
    public class EfCoreVehicleRepository : IVehicleRepository
    {
        private readonly AfterSalesDbContext _context;

        public EfCoreVehicleRepository(AfterSalesDbContext context)
        {
            _context = context;
        }

        public async Task<List<Vehicle>> GetListAsync(string? search = null, int? customerId = null, int skip = 0, int take = 20)
        {
            var query = from v in _context.Vehicles
                        join c in _context.Customers on v.CustomerId equals c.Id
                        where (string.IsNullOrWhiteSpace(search)
                               || v.PlateNumber.Contains(search) || v.Model.Contains(search) || c.FullName.Contains(search))
                              && (customerId == null || v.CustomerId == customerId.Value)
                        orderby v.Id descending
                        select v;

            var entities = await query.Skip(skip).Take(take).ToListAsync();
            return entities.ConvertAll(MapToDomain);
        }

        public async Task<int> GetCountAsync(string? search = null, int? customerId = null)
        {
            var query = from v in _context.Vehicles
                        join c in _context.Customers on v.CustomerId equals c.Id
                        where (string.IsNullOrWhiteSpace(search)
                               || v.PlateNumber.Contains(search) || v.Model.Contains(search) || c.FullName.Contains(search))
                              && (customerId == null || v.CustomerId == customerId.Value)
                        select v;

            return await query.CountAsync();
        }

        public async Task<Vehicle?> GetByIdAsync(int id)
        {
            var entity = await _context.Vehicles.FindAsync(id);
            return entity == null ? null : MapToDomain(entity);
        }

        public async Task<Vehicle> InsertAsync(Vehicle vehicle)
        {
            var entity = MapToEntity(vehicle);
            _context.Vehicles.Add(entity);
            await _context.SaveChangesAsync();
            vehicle.Id = entity.Id;
            return vehicle;
        }

        public async Task UpdateAsync(Vehicle vehicle)
        {
            var entity = await _context.Vehicles.FindAsync(vehicle.Id)
                ?? throw new AfterSalesException("AfterSales:VehicleNotFound", "خودرو یافت نشد.");

            entity.CustomerId = vehicle.CustomerId;
            entity.PlateNumber = vehicle.PlateNumber;
            entity.Model = vehicle.Model;
            entity.ProductionYear = vehicle.ProductionYear;
            entity.VIN = vehicle.VIN;
            entity.Mileage = vehicle.Mileage;

            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await _context.Vehicles.FindAsync(id);
            if (entity != null)
            {
                _context.Vehicles.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> IsInUseAsync(int id)
        {
            return await _context.ServiceRequests.AnyAsync(r => r.VehicleId == id);
        }

        public async Task<bool> HasDuplicatePlateAsync(string plateNumber, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.Vehicles.AnyAsync(v => v.PlateNumber == plateNumber && v.Id != excludeId.Value)
                : await _context.Vehicles.AnyAsync(v => v.PlateNumber == plateNumber);
        }

        // --- نگاشت ---

        private static Vehicle MapToDomain(VehicleEntity e) => new()
        {
            Id = e.Id,
            CustomerId = e.CustomerId,
            PlateNumber = e.PlateNumber,
            Model = e.Model,
            ProductionYear = e.ProductionYear,
            VIN = e.VIN,
            Mileage = e.Mileage
        };

        private static VehicleEntity MapToEntity(Vehicle v) => new()
        {
            Id = v.Id,
            CustomerId = v.CustomerId,
            PlateNumber = v.PlateNumber,
            Model = v.Model,
            ProductionYear = v.ProductionYear,
            VIN = v.VIN,
            Mileage = v.Mileage
        };
    }
}
