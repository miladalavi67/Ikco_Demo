using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.RegisterRequests;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperRegisterRequestRepository : IRegisterRequestRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperRegisterRequestRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetCountAsync(string? search = null, RegisterRequestState? state = null, string? chassis = null, DateTime? fromDate = null, DateTime? toDate = null)
        {
            var query = _context.RegisterRequests.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search)) query = query.Where(r => r.RequestNo.Contains(search));
            if (fromDate.HasValue) query = query.Where(r => r.RequestDate >= fromDate.Value);
            if (toDate.HasValue) query = query.Where(r => r.RequestDate < toDate.Value.AddDays(1));
            return await query.CountAsync();
        }

        public async Task<RegisterRequest?> GetByIdAsync(int id)
        {
            var e = await _context.RegisterRequests.FindAsync(id);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<RegisterRequest?> GetByRequestNumberAsync(string requestNumber)
        {
            var e = await _context.RegisterRequests.FirstOrDefaultAsync(r => r.RequestNo == requestNumber);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<RegisterRequest> InsertAsync(RegisterRequest request)
        {
            var entity = MapToEntity(request);
            _context.RegisterRequests.Add(entity);
            await _context.SaveChangesAsync();
            request.Id = entity.Id;
            return request;
        }

        public async Task<bool> HasDuplicateRequestNumberAsync(string requestNumber, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.RegisterRequests.AnyAsync(r => r.RequestNo == requestNumber && r.Id != excludeId.Value)
                : await _context.RegisterRequests.AnyAsync(r => r.RequestNo == requestNumber);
        }

        public async Task<ManagementRequest?> GetManagementByIdAsync(int id)
        {
            var e = await _context.ManagementRequests.FindAsync(id);
            return e == null ? null : MapToManagement(e);
        }

        public async Task<ManagementRequest> InsertManagementAsync(ManagementRequest request)
        {
            var entity = MapToManagementEntity(request);
            _context.ManagementRequests.Add(entity);
            await _context.SaveChangesAsync();
            request.Id = entity.Id;
            return request;
        }

        private static RegisterRequest MapToDomain(RegisterRequestEntity e) => new()
        {
            Id = e.Id, RequestNo = e.RequestNo, CarLogId = e.CarLogId, AgencyId = e.AgencyId,
            RequestDate = e.RequestDate, RequestType = e.RequestType, Description = e.Description,
            UserId = e.UserId, IsApproved = e.IsApproved
        };

        private static RegisterRequestEntity MapToEntity(RegisterRequest r) => new()
        {
            Id = r.Id, RequestNo = r.RequestNo, CarLogId = r.CarLogId, AgencyId = r.AgencyId,
            RequestDate = r.RequestDate, RequestType = r.RequestType, Description = r.Description,
            UserId = r.UserId, IsApproved = r.IsApproved
        };

        private static ManagementRequest MapToManagement(ManagementRequestEntity e) => new()
        {
            Id = e.Id, RequestNo = e.RequestNo, CarLogId = e.CarLogId, AgencyId = e.AgencyId,
            RequestDate = e.RequestDate, RequestType = e.RequestType, Description = e.Description,
            UserId = e.UserId, IsApproved = e.IsApproved
        };

        private static ManagementRequestEntity MapToManagementEntity(ManagementRequest r) => new()
        {
            Id = r.Id, RequestNo = r.RequestNo, CarLogId = r.CarLogId, AgencyId = r.AgencyId,
            RequestDate = r.RequestDate, RequestType = r.RequestType, Description = r.Description,
            UserId = r.UserId, IsApproved = r.IsApproved
        };
    }
}
