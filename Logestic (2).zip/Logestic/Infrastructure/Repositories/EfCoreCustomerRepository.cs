using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain;
using Logestic.Domain.Customers;

namespace Logestic.Infrastructure.Repositories
{
    /// <summary>
    /// پیاده‌سازی ریپازیتوری مشتری با EF Core / LINQ.
    /// تمام دسترسی به داده از طریق LINQ روی DbContext انجام می‌شود.
    /// </summary>
    public class EfCoreCustomerRepository : ICustomerRepository
    {
        private readonly AfterSalesDbContext _context;

        public EfCoreCustomerRepository(AfterSalesDbContext context)
        {
            _context = context;
        }

        public async Task<List<Customer>> GetListAsync(string? search = null, bool? onlyActive = null, int skip = 0, int take = 20)
        {
            var query = _context.Customers.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(c => c.FullName.Contains(search) || c.NationalCode.StartsWith(search) || c.Mobile.StartsWith(search));

            if (onlyActive == true)
                query = query.Where(c => c.IsActive);

            var entities = await query.OrderBy(c => c.FullName).Skip(skip).Take(take).ToListAsync();
            return entities.ConvertAll(MapToDomain);
        }

        public async Task<int> GetCountAsync(string? search = null, bool? onlyActive = null)
        {
            var query = _context.Customers.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(c => c.FullName.Contains(search) || c.NationalCode.StartsWith(search) || c.Mobile.StartsWith(search));

            if (onlyActive == true)
                query = query.Where(c => c.IsActive);

            return await query.CountAsync();
        }

        public async Task<Customer?> GetByIdAsync(int id)
        {
            var entity = await _context.Customers.FindAsync(id);
            return entity == null ? null : MapToDomain(entity);
        }

        public async Task<int> GetVehicleCountAsync(int customerId)
        {
            return await _context.Vehicles.CountAsync(v => v.CustomerId == customerId);
        }

        public async Task<Customer> InsertAsync(Customer customer)
        {
            var entity = MapToEntity(customer);
            _context.Customers.Add(entity);
            await _context.SaveChangesAsync();
            customer.Id = entity.Id;
            return customer;
        }

        public async Task UpdateAsync(Customer customer)
        {
            var entity = await _context.Customers.FindAsync(customer.Id);
            if (entity == null) throw new AfterSalesException(AfterSalesErrorCodes.CustomerNotFound, "مشتری یافت نشد.");

            entity.FullName = customer.FullName;
            entity.NationalCode = customer.NationalCode;
            entity.Mobile = customer.Mobile;
            entity.Email = customer.Email;
            entity.City = customer.City;
            entity.Address = customer.Address;
            entity.IsActive = customer.IsActive;

            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await _context.Customers.FindAsync(id);
            if (entity != null)
            {
                _context.Customers.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> IsInUseAsync(int id)
        {
            return await _context.Vehicles.AnyAsync(v => v.CustomerId == id);
        }

        public async Task<bool> HasDuplicateNationalCodeAsync(string nationalCode, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.Customers.AnyAsync(c => c.NationalCode == nationalCode && c.Id != excludeId.Value)
                : await _context.Customers.AnyAsync(c => c.NationalCode == nationalCode);
        }

        public async Task<int> GetCompletedRequestCountAsync(int customerId)
        {
            // شمارش درخواست‌های تکمیل‌شده برای مشتری (StatusId == 5)
            return await (
                from r in _context.ServiceRequests
                join v in _context.Vehicles on r.VehicleId equals v.Id
                where v.CustomerId == customerId && r.StatusId == 5
                select r
            ).CountAsync();
        }

        // --- نگاشت بین Entity و Domain ---

        private static Customer MapToDomain(CustomerEntity e) => new()
        {
            Id = e.Id,
            FullName = e.FullName,
            NationalCode = e.NationalCode,
            Mobile = e.Mobile,
            Email = e.Email,
            City = e.City,
            Address = e.Address,
            IsActive = e.IsActive
        };

        private static CustomerEntity MapToEntity(Customer c) => new()
        {
            Id = c.Id,
            FullName = c.FullName,
            NationalCode = c.NationalCode,
            Mobile = c.Mobile,
            Email = c.Email,
            City = c.City,
            Address = c.Address,
            IsActive = c.IsActive
        };
    }
}
