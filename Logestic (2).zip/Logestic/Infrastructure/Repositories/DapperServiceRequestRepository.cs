using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain;
using Logestic.Domain.ServiceRequests;

namespace Logestic.Infrastructure.Repositories
{
    /// <summary>
    /// پیاده‌سازی ریپازیتوری درخواست سرویس با Dapper.
    /// منطق پیچیده (تولید شماره درخواست، محاسبه مجدد مجموع‌ها، مدیریت تراکنش)
    /// از رویه‌های ذخیره‌شده گرفته شده و در C# بازنویسی شده است.
    /// اتصال و تراکنش از DbContext گرفته می‌شود تا با EF Core در یک unit of work قرار گیرد.
    /// </summary>
    public class DapperServiceRequestRepository : IServiceRequestRepository
    {
        private readonly AfterSalesDbContext _context;

        public DapperServiceRequestRepository(AfterSalesDbContext context)
        {
            _context = context;
        }

        public async Task<List<ServiceRequest>> GetListAsync(
            string? search = null, int? statusId = null,
            DateTime? fromDate = null, DateTime? toDate = null,
            int skip = 0, int take = 20)
        {
            // استفاده از LINQ روی DbContext برای کوئری لیست با join
            var query = from r in _context.ServiceRequests
                        join v in _context.Vehicles on r.VehicleId equals v.Id
                        join c in _context.Customers on v.CustomerId equals c.Id
                        join s in _context.ServiceStatuses on r.StatusId equals s.Id
                        join t in _context.Technicians on r.TechnicianId equals t.Id into techGroup
                        from t in techGroup.DefaultIfEmpty()
                        where (string.IsNullOrWhiteSpace(search)
                               || r.RequestNo.Contains(search) || v.PlateNumber.Contains(search) || c.FullName.Contains(search))
                              && (statusId == null || r.StatusId == statusId.Value)
                              && (fromDate == null || r.RequestDate >= fromDate.Value)
                              && (toDate == null || r.RequestDate < toDate.Value.AddDays(1))
                        orderby r.RequestDate descending, r.Id descending
                        select new
                        {
                            r.Id, r.RequestNo, r.VehicleId, v.PlateNumber, v.Model,
                            CustomerId = v.CustomerId, CustomerName = c.FullName,
                            r.TechnicianId, TechnicianName = t.FullName != null ? t.FullName : null,
                            r.StatusId, s.StatusName, s.IsFinal,
                            r.RequestDate, r.Description, r.LaborHours,
                            r.LaborCost, r.PartsCost, r.DiscountAmount, r.TotalCost,
                            r.CompletedDate
                        };

            var rows = await query.Skip(skip).Take(take).ToListAsync();

            return rows.Select(r => new ServiceRequest
            {
                Id = r.Id,
                RequestNo = r.RequestNo,
                VehicleId = r.VehicleId,
                CustomerId = r.CustomerId,
                TechnicianId = r.TechnicianId,
                StatusId = r.StatusId,
                IsFinal = r.IsFinal,
                RequestDate = r.RequestDate,
                Description = r.Description,
                LaborHours = r.LaborHours,
                LaborCost = r.LaborCost,
                PartsCost = r.PartsCost,
                DiscountAmount = r.DiscountAmount,
                TotalCost = r.TotalCost,
                CompletedDate = r.CompletedDate
            }).ToList();
        }

        public async Task<int> GetCountAsync(
            string? search = null, int? statusId = null,
            DateTime? fromDate = null, DateTime? toDate = null)
        {
            var query = from r in _context.ServiceRequests
                        join v in _context.Vehicles on r.VehicleId equals v.Id
                        join c in _context.Customers on v.CustomerId equals c.Id
                        where (string.IsNullOrWhiteSpace(search)
                               || r.RequestNo.Contains(search) || v.PlateNumber.Contains(search) || c.FullName.Contains(search))
                              && (statusId == null || r.StatusId == statusId.Value)
                              && (fromDate == null || r.RequestDate >= fromDate.Value)
                              && (toDate == null || r.RequestDate < toDate.Value.AddDays(1))
                        select r;

            return await query.CountAsync();
        }

        public async Task<ServiceRequest?> GetByIdAsync(int id)
        {
            var query = from r in _context.ServiceRequests
                        join v in _context.Vehicles on r.VehicleId equals v.Id
                        join c in _context.Customers on v.CustomerId equals c.Id
                        join s in _context.ServiceStatuses on r.StatusId equals s.Id
                        join t in _context.Technicians on r.TechnicianId equals t.Id into techGroup
                        from t in techGroup.DefaultIfEmpty()
                        where r.Id == id
                        select new
                        {
                            r.Id, r.RequestNo, r.VehicleId, v.PlateNumber, v.Model,
                            CustomerId = v.CustomerId, CustomerName = c.FullName,
                            r.TechnicianId, TechnicianName = t.FullName != null ? t.FullName : null,
                            r.StatusId, s.StatusName, s.IsFinal,
                            r.RequestDate, r.Description, r.LaborHours,
                            r.LaborCost, r.PartsCost, r.DiscountAmount, r.TotalCost,
                            r.CompletedDate
                        };

            var row = await query.FirstOrDefaultAsync();
            if (row == null) return null;

            return new ServiceRequest
            {
                Id = row.Id,
                RequestNo = row.RequestNo,
                VehicleId = row.VehicleId,
                CustomerId = row.CustomerId,
                TechnicianId = row.TechnicianId,
                StatusId = row.StatusId,
                IsFinal = row.IsFinal,
                RequestDate = row.RequestDate,
                Description = row.Description,
                LaborHours = row.LaborHours,
                LaborCost = row.LaborCost,
                PartsCost = row.PartsCost,
                DiscountAmount = row.DiscountAmount,
                TotalCost = row.TotalCost,
                CompletedDate = row.CompletedDate
            };
        }

        /// <summary>
        /// درج درخواست جدید. شماره درخواست به صورت SR-{سال}-{دنباله} تولید می‌شود.
        /// این منطق از رویه usp_ServiceRequest_Insert گرفته شده اما در C# پیاده‌سازی شده
        /// تا از race condition جلوگیری شود. از تراکنش EF Core استفاده می‌کند.
        /// </summary>
        public async Task<(int RequestId, string RequestNo)> InsertAsync(
            int vehicleId, int? technicianId, DateTime requestDate,
            string? description, decimal laborHours, decimal discountAmount)
        {
            var strategy = _context.Database.CreateExecutionStrategy();

            return await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await _context.Database.BeginTransactionAsync();

                try
                {
                    // تولید شماره درخواست: SR-{سال}-{دنباله چهاررقمی}
                    var year = requestDate.Year;
                    var prefix = $"SR-{year}-";

                    // پیدا کردن بزرگ‌ترین دنباله برای این سال
                    // AsEnumerable بعد از آن سمت کلاینت است؛ Max همگام است و نیازی به await ندارد
                    var maxSeq = _context.ServiceRequests
                        .Where(r => r.RequestNo.StartsWith(prefix))
                        .Select(r => r.RequestNo)
                        .AsEnumerable()
                        .Select(rn => int.TryParse(rn.Substring(rn.Length - 4), out var n) ? n : 0)
                        .DefaultIfEmpty(0)
                        .Max();

                    var seq = maxSeq + 1;
                    var requestNo = $"{prefix}{seq:D4}";

                    var entity = new ServiceRequestEntity
                    {
                        RequestNo = requestNo,
                        VehicleId = vehicleId,
                        TechnicianId = technicianId,
                        StatusId = 1, // وضعیت اولیه
                        RequestDate = requestDate,
                        Description = description,
                        LaborHours = laborHours,
                        DiscountAmount = discountAmount
                    };

                    _context.ServiceRequests.Add(entity);
                    await _context.SaveChangesAsync();

                    // محاسبه مجدد مجموع‌ها
                    await RecalculateAsync(entity.Id);

                    await transaction.CommitAsync();

                    return (entity.Id, requestNo);
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            });
        }

        public async Task UpdateAsync(ServiceRequest request)
        {
            var entity = await _context.ServiceRequests.FindAsync(request.Id)
                ?? throw new AfterSalesException("AfterSales:RequestNotFound", "درخواست یافت نشد.");

            // بررسی وضعیت نهایی — درخواست نهایی قابل ویرایش نیست
            if (await IsFinalAsync(request.Id))
                throw new AfterSalesException(AfterSalesErrorCodes.RequestIsFinal, "درخواست در وضعیت نهایی است و قابل ویرایش نیست.");

            entity.VehicleId = request.VehicleId;
            entity.TechnicianId = request.TechnicianId;
            entity.RequestDate = request.RequestDate;
            entity.Description = request.Description;
            entity.LaborHours = request.LaborHours;
            entity.DiscountAmount = request.DiscountAmount;

            await _context.SaveChangesAsync();

            // محاسبه مجدد مجموع‌ها
            await RecalculateAsync(entity.Id);
        }

        public async Task ChangeStatusAsync(int requestId, int statusId)
        {
            var entity = await _context.ServiceRequests.FindAsync(requestId)
                ?? throw new AfterSalesException("AfterSales:RequestNotFound", "درخواست یافت نشد.");

            // اعتبارسنجی وضعیت
            var statusExists = await _context.ServiceStatuses.AnyAsync(s => s.Id == statusId);
            if (!statusExists)
                throw new AfterSalesException(AfterSalesErrorCodes.InvalidStatus, "وضعیت نامعتبر است.");

            entity.StatusId = statusId;
            // اگر وضعیت تکمیل (5) است، تاریخ تکمیل را ثبت کن
            entity.CompletedDate = statusId == 5 ? DateTime.Now : null;

            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int requestId)
        {
            if (await IsFinalAsync(requestId))
                throw new AfterSalesException(AfterSalesErrorCodes.RequestIsFinal, "درخواست در وضعیت نهایی است و قابل حذف نیست.");

            var strategy = _context.Database.CreateExecutionStrategy();

            await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await _context.Database.BeginTransactionAsync();

                try
                {
                    // برگرداندن قطعات مصرف‌شده به انبار
                    var parts = await _context.ServiceRequestParts
                        .Where(srp => srp.RequestId == requestId)
                        .ToListAsync();

                    foreach (var line in parts)
                    {
                        var part = await _context.Parts.FindAsync(line.PartId);
                        if (part != null)
                        {
                            part.StockQty += line.Quantity;
                        }
                    }

                    _context.ServiceRequestParts.RemoveRange(parts);

                    var request = await _context.ServiceRequests.FindAsync(requestId);
                    if (request != null)
                        _context.ServiceRequests.Remove(request);

                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            });
        }

        public async Task<bool> IsFinalAsync(int requestId)
        {
            var query = from r in _context.ServiceRequests
                        join s in _context.ServiceStatuses on r.StatusId equals s.Id
                        where r.Id == requestId
                        select s.IsFinal;

            return await query.FirstOrDefaultAsync();
        }

        /// <summary>
        /// محاسبه مجدد مجموع‌ها. این منطق از رویه usp_ServiceRequest_Recalculate گرفته شده.
        /// PartsCost = جمع LineTotal تمام ردیف‌ها
        /// LaborCost = LaborHours * HourlyRate تعمیرکار
        /// TotalCost = PartsCost + LaborCost - DiscountAmount
        /// </summary>
        private async Task RecalculateAsync(int requestId)
        {
            var request = await _context.ServiceRequests.FindAsync(requestId);
            if (request == null) return;

            // مجموع هزینه قطعات
            var partsCost = await _context.ServiceRequestParts
                .Where(srp => srp.RequestId == requestId)
                .SumAsync(srp => srp.Quantity * srp.UnitPrice);

            // هزینه دستمزد: LaborHours * HourlyRate تعمیرکار
            decimal laborCost = 0;
            if (request.TechnicianId.HasValue)
            {
                var technician = await _context.Technicians.FindAsync(request.TechnicianId.Value);
                if (technician != null)
                {
                    laborCost = request.LaborHours * technician.HourlyRate;
                }
            }

            request.PartsCost = partsCost;
            request.LaborCost = laborCost;
            request.TotalCost = partsCost + laborCost - request.DiscountAmount;

            await _context.SaveChangesAsync();
        }
    }
}
