using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Deliveries;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperDeliveryRepository : IDeliveryRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperDeliveryRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<ListForExit?> GetListForExitByIdAsync(int id)
        {
            var e = await _context.ListForExits.FindAsync(id);
            return e == null ? null : MapToListForExit(e);
        }

        public async Task<ListForExit> InsertListForExitAsync(ListForExit listForExit)
        {
            var entity = MapToListForExitEntity(listForExit);
            _context.ListForExits.Add(entity);
            await _context.SaveChangesAsync();
            listForExit.Id = entity.Id;
            return listForExit;
        }

        public async Task<Bijak?> GetBijakByIdAsync(int id)
        {
            var e = await _context.Bijaks.FindAsync(id);
            return e == null ? null : MapToBijak(e);
        }

        public async Task<Bijak> InsertBijakAsync(Bijak bijak)
        {
            var entity = MapToBijakEntity(bijak);
            _context.Bijaks.Add(entity);
            await _context.SaveChangesAsync();
            bijak.Id = entity.Id;
            return bijak;
        }

        public async Task<bool> HasDuplicateBijakNumberAsync(string bijakNumber, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.Bijaks.AnyAsync(b => b.BijakNo == bijakNumber && b.Id != excludeId.Value)
                : await _context.Bijaks.AnyAsync(b => b.BijakNo == bijakNumber);
        }

        public async Task<BlockDelivery?> GetBlockDeliveryByIdAsync(int id)
        {
            var e = await _context.SltBlockDeliveries.FindAsync(id);
            return e == null ? null : new BlockDelivery { Id = e.Id, RefId = e.CarLogId };
        }

        public async Task<BlockDelivery?> GetActiveBlockByChassisAsync(string chassisNumber)
        {
            var e = await _context.SltBlockDeliveries.FirstOrDefaultAsync(b => b.Description != null && b.Description.Contains(chassisNumber));
            return e == null ? null : new BlockDelivery { Id = e.Id, RefId = e.CarLogId };
        }

        public async Task<BlockDelivery> InsertBlockDeliveryAsync(BlockDelivery blockDelivery)
        {
            var entity = new SltBlockDeliveryEntity
            {
                CarLogId = blockDelivery.RefId, BlockNo = string.Empty, BlockDate = DateTime.Now,
                Description = string.Empty
            };
            _context.SltBlockDeliveries.Add(entity);
            await _context.SaveChangesAsync();
            blockDelivery.Id = entity.Id;
            blockDelivery.RefId = entity.CarLogId;
            return blockDelivery;
        }

        public async Task<DeliveryTransport?> GetTransportByIdAsync(int id)
        {
            var e = await _context.DeliveryTransportHeaders.FindAsync(id);
            return e == null ? null : new DeliveryTransport { Id = e.Id, RefId = e.DriverId ?? 0 };
        }

        public async Task<DeliveryTransport> InsertTransportAsync(DeliveryTransport transport)
        {
            var entity = new DeliveryTransportHeaderEntity
            {
                TransportNo = string.Empty, TransportDate = DateTime.Now, DriverId = transport.RefId
            };
            _context.DeliveryTransportHeaders.Add(entity);
            await _context.SaveChangesAsync();
            transport.Id = entity.Id;
            transport.RefId = entity.DriverId ?? 0;
            return transport;
        }

        private static ListForExit MapToListForExit(ListForExitEntity e) => new()
        {
            Id = e.Id, ListNo = e.ListNo, ListDate = e.ListDate, AgencyId = e.AgencyId,
            Description = e.Description, UserId = e.UserId, IsActive = e.IsActive
        };

        private static ListForExitEntity MapToListForExitEntity(ListForExit l) => new()
        {
            Id = l.Id, ListNo = l.ListNo, ListDate = l.ListDate, AgencyId = l.AgencyId,
            Description = l.Description, UserId = l.UserId, IsActive = l.IsActive
        };

        private static Bijak MapToBijak(BijakEntity e) => new()
        {
            Id = e.Id, CarLogId = e.CarLogId, BijakNo = e.BijakNo, BijakDate = e.BijakDate,
            Description = e.Description, UserId = e.UserId
        };

        private static BijakEntity MapToBijakEntity(Bijak b) => new()
        {
            Id = b.Id, CarLogId = b.CarLogId, BijakNo = b.BijakNo, BijakDate = b.BijakDate,
            Description = b.Description, UserId = b.UserId
        };
    }
}
