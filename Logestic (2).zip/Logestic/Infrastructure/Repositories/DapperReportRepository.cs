using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Reports;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperReportRepository : IReportRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperReportRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<List<TechnicianPerformanceRow>> GetTechnicianPerformanceAsync(DateTime? fromDate, DateTime? toDate)
        {
            var query = _context.ServiceRequests.AsQueryable();
            if (fromDate.HasValue) query = query.Where(s => s.RequestDate >= fromDate.Value);
            if (toDate.HasValue) query = query.Where(s => s.RequestDate < toDate.Value.AddDays(1));

            var rows = await query
                .GroupBy(s => s.TechnicianId)
                .Select(g => new
                {
                    TechnicianId = g.Key,
                    RequestCount = g.Count(),
                    TotalHours = g.Sum(s => s.LaborHours),
                    TotalRevenue = g.Sum(s => s.TotalCost)
                })
                .ToListAsync();

            var result = new List<TechnicianPerformanceRow>();
            foreach (var r in rows)
            {
                var tech = r.TechnicianId.HasValue ? await _context.Technicians.FindAsync(r.TechnicianId.Value) : null;
                result.Add(new TechnicianPerformanceRow(
                    r.TechnicianId ?? 0,
                    tech?.FullName ?? string.Empty,
                    tech?.Specialty,
                    r.RequestCount,
                    r.TotalHours,
                    r.TotalRevenue));
            }
            return result;
        }

        public async Task<List<RevenueByMonthRow>> GetRevenueByMonthAsync(int year)
        {
            var rows = await _context.ServiceRequests
                .Where(s => s.RequestDate.Year == year)
                .GroupBy(s => s.RequestDate.Month)
                .Select(g => new
                {
                    MonthNo = g.Key,
                    RequestCount = g.Count(),
                    LaborSum = g.Sum(s => s.LaborCost),
                    PartsSum = g.Sum(s => s.PartsCost),
                    TotalSum = g.Sum(s => s.TotalCost)
                })
                .ToListAsync();

            return rows.ConvertAll(r => new RevenueByMonthRow(r.MonthNo, r.RequestCount, r.LaborSum, r.PartsSum, r.TotalSum));
        }

        public async Task<List<LowStockPartRow>> GetLowStockPartsAsync()
        {
            var parts = await _context.Parts
                .Where(p => p.StockQty < p.MinStockQty)
                .Select(p => new { p.Id, p.PartCode, p.PartName, p.UnitPrice, p.StockQty, p.MinStockQty })
                .ToListAsync();

            return parts.ConvertAll(p => new LowStockPartRow(p.Id, p.PartCode, p.PartName, p.UnitPrice, p.StockQty, p.MinStockQty));
        }
    }
}
