using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.BaseInfo;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCoreBaseInfoRepository : IBaseInfoRepository
    {
        private readonly AfterSalesDbContext _context;
        public EfCoreBaseInfoRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetDriverCountAsync(string? search = null, DriverJobType? jobType = null, bool? onlyActive = null)
        {
            var query = _context.Drivers.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search)) query = query.Where(d => d.FullName.Contains(search) || (d.NationalCode != null && d.NationalCode.Contains(search)));
            if (onlyActive == true) query = query.Where(d => d.IsActive);
            return await query.CountAsync();
        }

        public async Task<Driver?> GetDriverByIdAsync(int id)
        {
            var e = await _context.Drivers.FindAsync(id);
            return e == null ? null : MapToDriver(e);
        }

        public async Task<Driver> InsertDriverAsync(Driver driver)
        {
            var entity = MapToDriverEntity(driver);
            _context.Drivers.Add(entity);
            await _context.SaveChangesAsync();
            driver.Id = entity.Id;
            return driver;
        }

        public async Task<bool> IsDriverInUseAsync(int id) => false;

        public async Task<bool> HasDuplicateDriverCodeAsync(string personnelCode, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.Drivers.AnyAsync(d => d.NationalCode == personnelCode && d.Id != excludeId.Value)
                : await _context.Drivers.AnyAsync(d => d.NationalCode == personnelCode);
        }

        public async Task<DriverJob?> GetDriverJobByIdAsync(int id)
        {
            var e = await _context.DriverJobs.FindAsync(id);
            return e == null ? null : MapToDriverJob(e);
        }

        public async Task<DriverJob> InsertDriverJobAsync(DriverJob job)
        {
            var entity = MapToDriverJobEntity(job);
            _context.DriverJobs.Add(entity);
            await _context.SaveChangesAsync();
            job.Id = entity.Id;
            return job;
        }

        public async Task<bool> HasDriverStepAccessAsync(int driverId, int stepId)
            => await _context.DriverStepAccesses.AnyAsync(a => a.DriverId == driverId && a.StepId == stepId && a.HasAccess);

        public async Task<CarType?> GetCarTypeByIdAsync(int id)
        {
            var e = await _context.CarTypes.FindAsync(id);
            return e == null ? null : MapToCarType(e);
        }

        public async Task<CarType> InsertCarTypeAsync(CarType carType)
        {
            var entity = MapToCarTypeEntity(carType);
            _context.CarTypes.Add(entity);
            await _context.SaveChangesAsync();
            carType.Id = entity.Id;
            return carType;
        }

        public async Task<bool> HasUserFlowAccessAsync(int userId, int flowId)
            => await _context.UserFlowAccesses.AnyAsync(a => a.UserId == userId && a.FlowId == flowId && a.HasAccess);

        public async Task<bool> HasUserZoneAccessAsync(int userId, int zoneId)
            => await _context.UserZoneAccesses.AnyAsync(a => a.UserId == userId && a.ZoneId == zoneId && a.HasAccess);

        private static Driver MapToDriver(DriverEntity e) => new()
        {
            Id = e.Id, FullName = e.FullName, NationalCode = e.NationalCode,
            Mobile = e.Mobile, DriverJobId = e.DriverJobId, IsActive = e.IsActive
        };

        private static DriverEntity MapToDriverEntity(Driver d) => new()
        {
            Id = d.Id, FullName = d.FullName, NationalCode = d.NationalCode,
            Mobile = d.Mobile, DriverJobId = d.DriverJobId, IsActive = d.IsActive
        };

        private static DriverJob MapToDriverJob(DriverJobEntity e) => new()
        {
            Id = e.Id, JobName = e.JobName, Code = e.Code, IsActive = e.IsActive
        };

        private static DriverJobEntity MapToDriverJobEntity(DriverJob j) => new()
        {
            Id = j.Id, JobName = j.JobName, Code = j.Code, IsActive = j.IsActive
        };

        private static CarType MapToCarType(CarTypeEntity e) => new()
        {
            Id = e.Id, TypeName = e.TypeName, Code = e.Code, IsActive = e.IsActive
        };

        private static CarTypeEntity MapToCarTypeEntity(CarType c) => new()
        {
            Id = c.Id, TypeName = c.TypeName, Code = c.Code, IsActive = c.IsActive
        };
    }
}
