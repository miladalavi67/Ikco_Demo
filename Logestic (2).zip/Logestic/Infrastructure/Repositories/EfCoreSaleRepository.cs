using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Sales;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCoreSaleRepository : ISaleRepository
    {
        private readonly AfterSalesDbContext _context;
        public EfCoreSaleRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<CarSale?> GetSaleByIdAsync(int id)
        {
            var e = await _context.CarSales.FindAsync(id);
            return e == null ? null : MapSale(e);
        }

        public async Task<CarSale?> GetSaleByChassisAsync(string chassisNumber)
        {
            var e = await _context.CarSales.FirstOrDefaultAsync(s => s.Description != null && s.Description.Contains(chassisNumber));
            return e == null ? null : MapSale(e);
        }

        public async Task<CarSale> InsertSaleAsync(CarSale sale)
        {
            var entity = MapSaleEntity(sale);
            _context.CarSales.Add(entity);
            await _context.SaveChangesAsync();
            sale.Id = entity.Id;
            return sale;
        }

        public async Task<bool> HasDuplicateSaleNumberAsync(string saleNumber, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.CarSales.AnyAsync(s => s.SaleNo == saleNumber && s.Id != excludeId.Value)
                : await _context.CarSales.AnyAsync(s => s.SaleNo == saleNumber);
        }

        public async Task<CarLog> InsertLogAsync(CarLog log)
        {
            var entity = MapCarLogEntity(log);
            _context.CarLogs.Add(entity);
            await _context.SaveChangesAsync();
            log.Id = entity.Id;
            return log;
        }

        public async Task<FactorHeader?> GetFactorByIdAsync(int id)
        {
            var e = await _context.FactorHeaders.FindAsync(id);
            return e == null ? null : MapFactor(e);
        }

        public async Task<FactorHeader> InsertFactorAsync(FactorHeader factor)
        {
            var entity = MapFactorEntity(factor);
            _context.FactorHeaders.Add(entity);
            await _context.SaveChangesAsync();
            factor.Id = entity.Id;
            return factor;
        }

        public async Task<ContractHeader?> GetContractByIdAsync(int id)
        {
            var e = await _context.ContractHeaders.FindAsync(id);
            return e == null ? null : MapContract(e);
        }

        public async Task<ContractHeader> InsertContractAsync(ContractHeader contract)
        {
            var entity = MapContractEntity(contract);
            _context.ContractHeaders.Add(entity);
            await _context.SaveChangesAsync();
            contract.Id = entity.Id;
            return contract;
        }

        public async Task<ContractDetail> InsertContractDetailAsync(ContractDetail detail)
        {
            var entity = MapContractDetailEntity(detail);
            _context.ContractDetails.Add(entity);
            await _context.SaveChangesAsync();
            detail.Id = entity.Id;
            return detail;
        }

        public async Task<CarReserveAgencyLog?> GetActiveReserveByChassisAsync(string chassisNumber)
        {
            var e = await _context.CarReserveAgencyLogs.FirstOrDefaultAsync(r => r.ReleaseDate == null && r.Description != null && r.Description.Contains(chassisNumber));
            return e == null ? null : MapReserve(e);
        }

        public async Task<CarReserveAgencyLog> InsertReserveLogAsync(CarReserveAgencyLog log)
        {
            var entity = MapReserveEntity(log);
            _context.CarReserveAgencyLogs.Add(entity);
            await _context.SaveChangesAsync();
            log.Id = entity.Id;
            return log;
        }

        private static CarSale MapSale(CarSaleEntity e) => new()
        {
            Id = e.Id, SaleNo = e.SaleNo, SaleDate = e.SaleDate, ContractHeaderId = e.ContractHeaderId,
            FactorHeaderId = e.FactorHeaderId, CustomerId = e.CustomerId, AgencyId = e.AgencyId,
            SaleAmount = e.SaleAmount, Description = e.Description, IsActive = e.IsActive
        };

        private static CarSaleEntity MapSaleEntity(CarSale s) => new()
        {
            Id = s.Id, SaleNo = s.SaleNo, SaleDate = s.SaleDate, ContractHeaderId = s.ContractHeaderId,
            FactorHeaderId = s.FactorHeaderId, CustomerId = s.CustomerId, AgencyId = s.AgencyId,
            SaleAmount = s.SaleAmount, Description = s.Description, IsActive = s.IsActive
        };

        private static CarLogEntity MapCarLogEntity(CarLog l) => new()
        {
            Id = l.Id, Pelak = l.Pelak, VIN = l.VIN, CarTypeId = l.CarTypeId, CarSaleId = l.CarSaleId,
            AgencyId = l.AgencyId, EnterDate = l.EnterDate, ExitDate = l.ExitDate, CurrentCellId = l.CurrentCellId,
            Description = l.Description, IsActive = l.IsActive
        };

        private static FactorHeader MapFactor(FactorHeaderEntity e) => new()
        {
            Id = e.Id, FactorNo = e.FactorNo, FactorDate = e.FactorDate, ContractHeaderId = e.ContractHeaderId,
            CustomerId = e.CustomerId, TotalAmount = e.TotalAmount, DiscountAmount = e.DiscountAmount,
            FinalAmount = e.FinalAmount, Description = e.Description, IsActive = e.IsActive
        };

        private static FactorHeaderEntity MapFactorEntity(FactorHeader f) => new()
        {
            Id = f.Id, FactorNo = f.FactorNo, FactorDate = f.FactorDate, ContractHeaderId = f.ContractHeaderId,
            CustomerId = f.CustomerId, TotalAmount = f.TotalAmount, DiscountAmount = f.DiscountAmount,
            FinalAmount = f.FinalAmount, Description = f.Description, IsActive = f.IsActive
        };

        private static ContractHeader MapContract(ContractHeaderEntity e) => new()
        {
            Id = e.Id, ContractNo = e.ContractNo, ContractDate = e.ContractDate, CustomerId = e.CustomerId,
            AgencyId = e.AgencyId, TotalAmount = e.TotalAmount, Description = e.Description, IsActive = e.IsActive
        };

        private static ContractHeaderEntity MapContractEntity(ContractHeader c) => new()
        {
            Id = c.Id, ContractNo = c.ContractNo, ContractDate = c.ContractDate, CustomerId = c.CustomerId,
            AgencyId = c.AgencyId, TotalAmount = c.TotalAmount, Description = c.Description, IsActive = c.IsActive
        };

        private static ContractDetailEntity MapContractDetailEntity(ContractDetail d) => new()
        {
            Id = d.Id, ContractHeaderId = d.ContractHeaderId, ItemName = d.ItemName, Quantity = d.Quantity,
            UnitPrice = d.UnitPrice, TotalPrice = d.TotalPrice, Description = d.Description
        };

        private static CarReserveAgencyLog MapReserve(CarReserveAgencyLogEntity e) => new()
        {
            Id = e.Id, CarLogId = e.CarLogId, AgencyId = e.AgencyId, ReserveDate = e.ReserveDate,
            ReleaseDate = e.ReleaseDate, Description = e.Description, UserId = e.UserId
        };

        private static CarReserveAgencyLogEntity MapReserveEntity(CarReserveAgencyLog l) => new()
        {
            Id = l.Id, CarLogId = l.CarLogId, AgencyId = l.AgencyId, ReserveDate = l.ReserveDate,
            ReleaseDate = l.ReleaseDate, Description = l.Description, UserId = l.UserId
        };
    }
}
