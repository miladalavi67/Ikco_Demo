using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Pelaks;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperPelakRepository : IPelakRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperPelakRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetPlaceCountAsync(string? search, bool? onlyActive) => await _context.PelakPlaceStocks.CountAsync();
        public async Task<PelakPlace?> GetPlaceByIdAsync(int id) => null;
        public async Task<PelakPlace> InsertPlaceAsync(PelakPlace place) { place.Id = 0; return place; }
        public async Task<bool> IsPlaceInUseAsync(int id) => false;
        public async Task<PelakPlaceStock?> GetStockByIdAsync(int id) => null;
        public async Task<PelakPlaceStock?> GetStockByPlateAsync(string plateNumber) => null;
        public async Task<PelakPlaceStock> InsertStockAsync(PelakPlaceStock stock) { stock.Id = 0; return stock; }
        public async Task<bool> HasDuplicatePlateAsync(string plateNumber, int? excludeId) => false;
        public async Task<PelakPlaceLog> InsertLogAsync(PelakPlaceLog log) { var entity = new PelakPlaceLogEntity { CarLogId = log.CarLogId, PelakPlaceStateId = log.PelakPlaceStateId, PelakPlaceStockId = log.PelakPlaceStockId, ActionDate = log.ActionDate, Description = log.Description, UserId = log.UserId }; _context.PelakPlaceLogs.Add(entity); await _context.SaveChangesAsync(); log.Id = entity.Id; return log; }
        public async Task<PelakPlaceState?> GetStateByPlaceAsync(int placeId) => null;
        public async Task<PelakPlaceState> UpdateStateAsync(PelakPlaceState state) => state;
        public async Task<bool> HasUserAccessAsync(int userId, int placeId) => false;
        public async Task<CarNumberingFault> InsertFaultAsync(CarNumberingFault fault) { fault.Id = 0; return fault; }
    }
}
