using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Audits;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCoreAuditRepository : IAuditRepository
    {
        private readonly AfterSalesDbContext _context;
        public EfCoreAuditRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<AuditDetail?> GetDetailByIdAsync(int id) { var e = await _context.AuditDetails.FindAsync(id); return e == null ? null : MapDetail(e); }
        public async Task<AuditDetail> InsertDetailAsync(AuditDetail detail) { var entity = new AuditDetailEntity { CarLogId = detail.CarLogId, AuditTypeId = detail.AuditTypeId, AuditDate = detail.AuditDate, Description = detail.Description, UserId = detail.UserId, IsPassed = detail.IsPassed }; _context.AuditDetails.Add(entity); await _context.SaveChangesAsync(); detail.Id = entity.Id; return detail; }
        public async Task<AuditType?> GetTypeByIdAsync(int id) { var e = await _context.AuditTypes.FindAsync(id); return e == null ? null : new AuditType { Id = e.Id, TypeName = e.TypeName, Code = e.Code, IsActive = e.IsActive }; }
        public async Task<AuditType> InsertTypeAsync(AuditType type) { var entity = new AuditTypeEntity { TypeName = type.TypeName, Code = type.Code, IsActive = type.IsActive }; _context.AuditTypes.Add(entity); await _context.SaveChangesAsync(); type.Id = entity.Id; return type; }

        private static AuditDetail MapDetail(AuditDetailEntity e) => new() { Id = e.Id, CarLogId = e.CarLogId, AuditTypeId = e.AuditTypeId, AuditDate = e.AuditDate, Description = e.Description, UserId = e.UserId, IsPassed = e.IsPassed };
    }
}
