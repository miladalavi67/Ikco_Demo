using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.ServiceRequests;

namespace Logestic.Infrastructure.Repositories
{
    /// <summary>
    /// پیاده‌سازی ریپازیتوری وضعیت‌های درخواست سرویس با EF Core / LINQ.
    /// </summary>
    public class EfCoreServiceStatusRepository : IServiceStatusRepository
    {
        private readonly AfterSalesDbContext _context;

        public EfCoreServiceStatusRepository(AfterSalesDbContext context)
        {
            _context = context;
        }

        public async Task<List<ServiceStatus>> GetAllAsync()
        {
            var entities = await _context.ServiceStatuses.OrderBy(s => s.Id).ToListAsync();
            return entities.ConvertAll(MapToDomain);
        }

        private static ServiceStatus MapToDomain(ServiceStatusEntity e) => new()
        {
            Id = e.Id,
            StatusName = e.StatusName,
            IsFinal = e.IsFinal
        };
    }
}
