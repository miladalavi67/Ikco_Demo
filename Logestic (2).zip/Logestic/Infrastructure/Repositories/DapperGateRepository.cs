using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Gates;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperGateRepository : IGateOperationRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperGateRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetCountAsync(string? search, GateDirection? direction, GateType? gateType, GateMethod? gateMethod, DateTime? fromDate, DateTime? toDate)
        {
            var query = _context.EnterGates.AsQueryable();
            if (fromDate.HasValue) query = query.Where(e => e.EnterDate >= fromDate.Value);
            if (toDate.HasValue) query = query.Where(e => e.EnterDate < toDate.Value.AddDays(1));
            return await query.CountAsync();
        }

        public async Task<GateOperation?> GetByIdAsync(int id)
        {
            var e = await _context.EnterGates.FindAsync(id);
            if (e == null) return null;
            return new GateOperation { Id = e.Id, RefId = e.Id };
        }

        public async Task<EnterGate> InsertEnterAsync(EnterGate gate)
        {
            var entity = new EnterGateEntity { CarLogId = gate.CarLogId, AgencyId = gate.AgencyId, EnterDate = gate.EnterDate, Pelak = gate.Pelak, Description = gate.Description, IsActive = true };
            _context.EnterGates.Add(entity);
            await _context.SaveChangesAsync();
            gate.Id = entity.Id;
            return gate;
        }

        public async Task<ExitGate> InsertExitAsync(ExitGate gate)
        {
            var entity = new ExitGateEntity { CarLogId = gate.CarLogId, AgencyId = gate.AgencyId, ExitDate = gate.ExitDate, Pelak = gate.Pelak, Description = gate.Description, IsActive = true };
            _context.ExitGates.Add(entity);
            await _context.SaveChangesAsync();
            gate.Id = entity.Id;
            return gate;
        }

        public async Task<RelapseGate> InsertRelapseAsync(RelapseGate gate)
        {
            var entity = new RelapseGateOperationEntity { CarLogId = 0, ExitGateId = null, RelapseDate = DateTime.Now, Reason = null, Description = null, IsActive = true };
            _context.RelapseGateOperations.Add(entity);
            await _context.SaveChangesAsync();
            gate.Id = entity.Id;
            return gate;
        }

        public async Task<bool> IsChassisInUseAsync(string chassisNumber, GateDirection direction) => false;
        public async Task<EnterGate?> GetLastEnterByChassisAsync(string chassisNumber) => null;
        public async Task<ExitGate?> GetLastExitByChassisAsync(string chassisNumber) => null;
    }
}
