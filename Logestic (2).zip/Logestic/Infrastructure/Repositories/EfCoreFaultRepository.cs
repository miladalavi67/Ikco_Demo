using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Faults;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCoreFaultRepository : IFaultRepository
    {
        private readonly AfterSalesDbContext _context;
        public EfCoreFaultRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetCountAsync(string? chassis, FaultLevel? level, bool? resolved, DateTime? fromDate, DateTime? toDate)
        {
            var query = _context.Faults.AsQueryable();
            if (resolved.HasValue) query = query.Where(f => f.IsResolved == resolved.Value);
            if (fromDate.HasValue) query = query.Where(f => f.FaultDate >= fromDate.Value);
            if (toDate.HasValue) query = query.Where(f => f.FaultDate < toDate.Value.AddDays(1));
            return await query.CountAsync();
        }
        public async Task<Fault?> GetByIdAsync(int id) { var e = await _context.Faults.FindAsync(id); return e == null ? null : MapFault(e); }
        public async Task<Fault> InsertAsync(Fault fault) { var entity = new FaultEntity { CarLogId = fault.CarLogId, FaultBodyId = fault.FaultBodyId, FaultLevelId = fault.FaultLevelId, FaultSourceId = fault.FaultSourceId, FaultDate = fault.FaultDate, Description = fault.Description, UserId = fault.UserId, IsResolved = fault.IsResolved }; _context.Faults.Add(entity); await _context.SaveChangesAsync(); fault.Id = entity.Id; return fault; }
        public async Task<FaultBody?> GetBodyByIdAsync(int id) { var e = await _context.FaultBodies.FindAsync(id); return e == null ? null : new FaultBody { Id = e.Id, BodyName = e.BodyName, Code = e.Code, IsActive = e.IsActive }; }
        public async Task<FaultBody> InsertBodyAsync(FaultBody body) { var entity = new FaultBodyEntity { BodyName = body.BodyName, Code = body.Code, IsActive = body.IsActive }; _context.FaultBodies.Add(entity); await _context.SaveChangesAsync(); body.Id = entity.Id; return body; }
        public async Task<FaultLevel?> GetLevelByIdAsync(int id) { var e = await _context.FaultLevels.FindAsync(id); return e == null ? null : new FaultLevel { Id = e.Id, LevelName = e.LevelName, Code = e.Code, Severity = e.Severity, IsActive = e.IsActive }; }
        public async Task<FaultLevel> InsertLevelAsync(FaultLevel level) { var entity = new FaultLevelEntity { LevelName = level.LevelName, Code = level.Code, Severity = level.Severity, IsActive = level.IsActive }; _context.FaultLevels.Add(entity); await _context.SaveChangesAsync(); level.Id = entity.Id; return level; }
        public async Task<FaultPart?> GetPartByIdAsync(int id) { var e = await _context.FaultParts.FindAsync(id); return e == null ? null : new FaultPart { Id = e.Id, FaultId = e.FaultId, PartCode = e.PartCode, PartName = e.PartName, Quantity = e.Quantity, Description = e.Description }; }
        public async Task<FaultPart> InsertPartAsync(FaultPart part) { var entity = new FaultPartEntity { FaultId = part.FaultId, PartCode = part.PartCode, PartName = part.PartName, Quantity = part.Quantity, Description = part.Description }; _context.FaultParts.Add(entity); await _context.SaveChangesAsync(); part.Id = entity.Id; return part; }
        public async Task<FaultSource?> GetSourceByIdAsync(int id) { var e = await _context.FaultSources.FindAsync(id); return e == null ? null : new FaultSource { Id = e.Id, SourceName = e.SourceName, Code = e.Code, IsActive = e.IsActive }; }
        public async Task<FaultSource> InsertSourceAsync(FaultSource source) { var entity = new FaultSourceEntity { SourceName = source.SourceName, Code = source.Code, IsActive = source.IsActive }; _context.FaultSources.Add(entity); await _context.SaveChangesAsync(); source.Id = entity.Id; return source; }

        private static Fault MapFault(FaultEntity e) => new() { Id = e.Id, CarLogId = e.CarLogId, FaultBodyId = e.FaultBodyId, FaultLevelId = e.FaultLevelId, FaultSourceId = e.FaultSourceId, FaultDate = e.FaultDate, Description = e.Description, UserId = e.UserId, IsResolved = e.IsResolved };
    }
}
