using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.RelapseGateBuffers;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCoreRelapseGateBufferRepository : IRelapseGateBufferRepository
    {
        private readonly AfterSalesDbContext _context;
        public EfCoreRelapseGateBufferRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<List<RelapseBufferOperation>> GetListAsync(string? search = null, int skip = 0, int take = 20)
        {
            var query = _context.RelapseBufferOperations.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search)) query = query.Where(b => b.Reason != null && b.Reason.Contains(search));
            var entities = await query.OrderByDescending(b => b.OperationDate).Skip(skip).Take(take).ToListAsync();
            return entities.ConvertAll(MapToDomain);
        }

        public async Task<RelapseBufferOperation?> GetByIdAsync(int id)
        {
            var e = await _context.RelapseBufferOperations.FindAsync(id);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<RelapseBufferOperation> InsertAsync(RelapseBufferOperation entity)
        {
            var e = MapToEntity(entity);
            _context.RelapseBufferOperations.Add(e);
            await _context.SaveChangesAsync();
            entity.Id = e.Id;
            return entity;
        }

        public async Task UpdateAsync(RelapseBufferOperation entity)
        {
            var e = await _context.RelapseBufferOperations.FindAsync(entity.Id);
            if (e != null)
            {
                e.CarLogId = entity.CarLogId;
                e.ExitGateId = entity.ExitGateId;
                e.OperationDate = entity.OperationDate;
                e.OperationType = entity.OperationType;
                e.Reason = entity.Reason;
                e.Description = entity.Description;
                e.IsProcessed = entity.IsProcessed;
                await _context.SaveChangesAsync();
            }
        }

        public async Task DeleteAsync(int id)
        {
            var e = await _context.RelapseBufferOperations.FindAsync(id);
            if (e != null) { _context.RelapseBufferOperations.Remove(e); await _context.SaveChangesAsync(); }
        }

        private static RelapseBufferOperation MapToDomain(RelapseBufferOperationEntity e) => new()
        {
            Id = e.Id, CarLogId = e.CarLogId, ExitGateId = e.ExitGateId, OperationDate = e.OperationDate,
            OperationType = e.OperationType, Reason = e.Reason, Description = e.Description,
            UserId = e.UserId, IsProcessed = e.IsProcessed
        };

        private static RelapseBufferOperationEntity MapToEntity(RelapseBufferOperation b) => new()
        {
            Id = b.Id, CarLogId = b.CarLogId, ExitGateId = b.ExitGateId, OperationDate = b.OperationDate,
            OperationType = b.OperationType, Reason = b.Reason, Description = b.Description,
            UserId = b.UserId, IsProcessed = b.IsProcessed
        };
    }
}
