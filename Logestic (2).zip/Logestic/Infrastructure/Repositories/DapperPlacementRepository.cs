using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Placements;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperPlacementRepository : IPlacementRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperPlacementRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetZoneCountAsync(string? search, bool? onlyActive)
        {
            var query = _context.Zones.AsQueryable();
            if (onlyActive == true) query = query.Where(z => z.IsActive);
            return await query.CountAsync();
        }
        public async Task<Zone?> GetZoneByIdAsync(int id) { var e = await _context.Zones.FindAsync(id); return e == null ? null : new Zone { Id = e.Id, ZoneName = e.ZoneName, Code = e.Code, AgencyId = e.AgencyId, IsActive = e.IsActive }; }
        public async Task<Zone> InsertZoneAsync(Zone zone) { var entity = new ZoneEntity { ZoneName = zone.ZoneName, Code = zone.Code, AgencyId = zone.AgencyId, IsActive = zone.IsActive }; _context.Zones.Add(entity); await _context.SaveChangesAsync(); zone.Id = entity.Id; return zone; }
        public async Task<Partition?> GetPartitionByIdAsync(int id) { var e = await _context.Partitions.FindAsync(id); return e == null ? null : new Partition { Id = e.Id, ZoneId = e.ZoneId, PartitionName = e.PartitionName, Code = e.Code, IsActive = e.IsActive }; }
        public async Task<Partition> InsertPartitionAsync(Partition partition) { var entity = new PartitionEntity { ZoneId = partition.ZoneId, PartitionName = partition.PartitionName, Code = partition.Code, IsActive = partition.IsActive }; _context.Partitions.Add(entity); await _context.SaveChangesAsync(); partition.Id = entity.Id; return partition; }
        public async Task<int> GetCellCountAsync(int? partitionId, CellState? state, string? search) => await _context.Cells.CountAsync();
        public async Task<Cell?> GetCellByIdAsync(int id) { var e = await _context.Cells.FindAsync(id); return e == null ? null : MapCell(e); }
        public async Task<Cell?> GetCellByChassisAsync(string chassisNumber) => null;
        public async Task<Cell> InsertCellAsync(Cell cell) { var entity = new CellEntity { ZoneId = cell.ZoneId, PartitionId = cell.PartitionId, CellName = cell.CellName, Code = cell.Code, Capacity = cell.Capacity, Occupied = cell.Occupied, IsActive = cell.IsActive }; _context.Cells.Add(entity); await _context.SaveChangesAsync(); cell.Id = entity.Id; return cell; }
        public async Task<bool> IsCellInUseAsync(int id) => false;
        public async Task<CellInOut> InsertCellInOutAsync(CellInOut cellInOut) { var entity = new CellInOutEntity { CellId = cellInOut.CellId, CarLogId = cellInOut.CarLogId, InDate = cellInOut.InDate, OutDate = cellInOut.OutDate, Description = cellInOut.Description, UserId = cellInOut.UserId }; _context.CellInOuts.Add(entity); await _context.SaveChangesAsync(); cellInOut.Id = entity.Id; return cellInOut; }
        public async Task<CellReplace> InsertCellReplaceAsync(CellReplace cellReplace) { var entity = new CellReplaceEntity { CarLogId = cellReplace.CarLogId, FromCellId = cellReplace.FromCellId, ToCellId = cellReplace.ToCellId, ReplaceDate = cellReplace.ReplaceDate, Description = cellReplace.Description, UserId = cellReplace.UserId }; _context.CellReplaces.Add(entity); await _context.SaveChangesAsync(); cellReplace.Id = entity.Id; return cellReplace; }
        public async Task<LogesticZonePayment> InsertPaymentAsync(LogesticZonePayment payment) { var entity = new LogesticZonePaymentEntity { ZoneId = payment.ZoneId, CarLogId = payment.CarLogId, PaymentDate = payment.PaymentDate, Amount = payment.Amount, Description = payment.Description, UserId = payment.UserId }; _context.LogesticZonePayments.Add(entity); await _context.SaveChangesAsync(); payment.Id = entity.Id; return payment; }
        public async Task<ParkingService> InsertServiceAsync(ParkingService service) { service.Id = 0; return service; }

        private static Cell MapCell(CellEntity e) => new() { Id = e.Id, ZoneId = e.ZoneId, PartitionId = e.PartitionId, CellName = e.CellName, Code = e.Code, Capacity = e.Capacity, Occupied = e.Occupied, IsActive = e.IsActive };
    }
}
