using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain;
using Logestic.Domain.ServiceRequests;

namespace Logestic.Infrastructure.Repositories
{
    /// <summary>
    /// پیاده‌سازی ریپازیتوری ردیف‌های قطعات درخواست سرویس.
    /// منطق مدیریت موجودی (کاهش/افزایش انبار) در اینجا پیاده‌سازی شده
    /// و از رویه‌های usp_ServiceRequestPart_Add و usp_ServiceRequestPart_Delete گرفته شده.
    /// </summary>
    public class EfCoreServiceRequestPartRepository : IServiceRequestPartRepository
    {
        private readonly AfterSalesDbContext _context;

        public EfCoreServiceRequestPartRepository(AfterSalesDbContext context)
        {
            _context = context;
        }

        public async Task<List<ServiceRequestPart>> GetByRequestAsync(int requestId)
        {
            var query = from srp in _context.ServiceRequestParts
                        join p in _context.Parts on srp.PartId equals p.Id
                        where srp.RequestId == requestId
                        orderby srp.Id
                        select new
                        {
                            srp.Id, srp.RequestId, srp.PartId,
                            p.PartCode, p.PartName,
                            srp.Quantity, srp.UnitPrice
                        };

            var rows = await query.ToListAsync();

            return rows.Select(r => new ServiceRequestPart
            {
                Id = r.Id,
                RequestId = r.RequestId,
                PartId = r.PartId,
                Quantity = r.Quantity,
                UnitPrice = r.UnitPrice
            }).ToList();
        }

        /// <summary>
        /// افزودن قطعه به درخواست. موجودی انبار را کاهش می‌دهد و ردیف را درج می‌کند.
        /// این منطق از رویه usp_ServiceRequestPart_Add گرفته شده.
        /// توجه: محاسبه مجدد مجموع‌ها در ServiceRequestRepository.RecalculateAsync انجام می‌شود.
        /// </summary>
        public async Task<(int LineId, decimal UnitPrice)> AddAsync(int requestId, int partId, int quantity)
        {
            if (quantity <= 0)
                throw new AfterSalesException(AfterSalesErrorCodes.InvalidQuantity, "تعداد باید بزرگ‌تر از صفر باشد.");

            var strategy = _context.Database.CreateExecutionStrategy();

            return await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await _context.Database.BeginTransactionAsync();

                try
                {
                    // بررسی موجودی قطعه
                    var part = await _context.Parts.FindAsync(partId)
                        ?? throw new AfterSalesException(AfterSalesErrorCodes.PartNotFound, "قطعه یافت نشد.");

                    if (part.StockQty < quantity)
                        throw new AfterSalesException(AfterSalesErrorCodes.InsufficientStock, "موجودی انبار کافی نیست.");

                    // کاهش موجودی
                    part.StockQty -= quantity;

                    // درج ردیف
                    var entity = new ServiceRequestPartEntity
                    {
                        RequestId = requestId,
                        PartId = partId,
                        Quantity = quantity,
                        UnitPrice = part.UnitPrice
                    };

                    _context.ServiceRequestParts.Add(entity);
                    await _context.SaveChangesAsync();

                    await transaction.CommitAsync();

                    return (entity.Id, part.UnitPrice);
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            });
        }

        /// <summary>
        /// حذف ردیف قطعه. موجودی انبار را برمی‌گرداند.
        /// این منطق از رویه usp_ServiceRequestPart_Delete گرفته شده.
        /// </summary>
        public async Task DeleteAsync(int lineId)
        {
            var strategy = _context.Database.CreateExecutionStrategy();

            await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await _context.Database.BeginTransactionAsync();

                try
                {
                    var line = await _context.ServiceRequestParts.FindAsync(lineId)
                        ?? throw new AfterSalesException(AfterSalesErrorCodes.RequestPartNotFound, "ردیف قطعه یافت نشد.");

                    // برگرداندن موجودی
                    var part = await _context.Parts.FindAsync(line.PartId);
                    if (part != null)
                    {
                        part.StockQty += line.Quantity;
                    }

                    _context.ServiceRequestParts.Remove(line);
                    await _context.SaveChangesAsync();

                    await transaction.CommitAsync();
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            });
        }
    }
}
