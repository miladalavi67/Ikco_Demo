using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Transitions;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCoreTransitionRepository : ITransitionRepository
    {
        private readonly AfterSalesDbContext _context;
        public EfCoreTransitionRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<Flow?> GetFlowByIdAsync(int id)
        {
            var e = await _context.Flows.FindAsync(id);
            return e == null ? null : MapFlow(e);
        }

        public async Task<Flow> InsertFlowAsync(Flow flow)
        {
            var entity = MapFlowEntity(flow);
            _context.Flows.Add(entity);
            await _context.SaveChangesAsync();
            flow.Id = entity.Id;
            return flow;
        }

        public async Task<Step?> GetStepByIdAsync(int id)
        {
            var e = await _context.Steps.FindAsync(id);
            return e == null ? null : MapStep(e);
        }

        public async Task<Step> InsertStepAsync(Step step)
        {
            var entity = MapStepEntity(step);
            _context.Steps.Add(entity);
            await _context.SaveChangesAsync();
            step.Id = entity.Id;
            return step;
        }

        public async Task<Transition> InsertTransitionAsync(Transition transition)
        {
            var entity = MapTransitionEntity(transition);
            _context.Transitions.Add(entity);
            await _context.SaveChangesAsync();
            transition.Id = entity.Id;
            return transition;
        }

        public async Task<bool> CanTransitionAsync(int fromStepId, int toStepId)
            => await _context.Transitions.AnyAsync(t => t.FromStepId == fromStepId && t.ToStepId == toStepId && t.IsActive);

        public async Task<FlowTypeTransition> InsertFlowTypeTransitionAsync(FlowTypeTransition transition)
        {
            var entity = MapFlowTypeTransitionEntity(transition);
            _context.FlowTypeTransitions.Add(entity);
            await _context.SaveChangesAsync();
            transition.Id = entity.Id;
            return transition;
        }

        public async Task<bool> HasUserFlowTypeAsync(int userId, int flowId)
            => await _context.UserFlowTypes.AnyAsync(u => u.UserId == userId && u.FlowTypeId == flowId && u.HasAccess);

        private static Flow MapFlow(FlowEntity e) => new()
        {
            Id = e.Id, FlowName = e.FlowName, Code = e.Code, FlowTypeId = e.FlowTypeId, IsActive = e.IsActive
        };

        private static FlowEntity MapFlowEntity(Flow f) => new()
        {
            Id = f.Id, FlowName = f.FlowName, Code = f.Code, FlowTypeId = f.FlowTypeId, IsActive = f.IsActive
        };

        private static Step MapStep(StepEntity e) => new()
        {
            Id = e.Id, StepName = e.StepName, Code = e.Code, FlowId = e.FlowId, OrderNo = e.OrderNo,
            IsFinal = e.IsFinal, IsActive = e.IsActive
        };

        private static StepEntity MapStepEntity(Step s) => new()
        {
            Id = s.Id, StepName = s.StepName, Code = s.Code, FlowId = s.FlowId, OrderNo = s.OrderNo,
            IsFinal = s.IsFinal, IsActive = s.IsActive
        };

        private static TransitionEntity MapTransitionEntity(Transition t) => new()
        {
            Id = t.Id, FromStepId = t.FromStepId, ToStepId = t.ToStepId,
            TransitionName = t.TransitionName, Description = t.Description, IsActive = t.IsActive
        };

        private static FlowTypeTransitionEntity MapFlowTypeTransitionEntity(FlowTypeTransition t) => new()
        {
            Id = t.Id, FlowId = t.FlowId, TransitionId = t.TransitionId, IsActive = t.IsActive
        };
    }
}
