using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Users;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCoreUserRepository : IUserRepository
    {
        private readonly AfterSalesDbContext _context;
        public EfCoreUserRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetCountAsync(string? search = null, bool? onlyActive = null)
        {
            var query = _context.Users.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search)) query = query.Where(u => u.UserName.Contains(search) || u.FullName.Contains(search));
            if (onlyActive == true) query = query.Where(u => u.IsActive);
            return await query.CountAsync();
        }

        public async Task<User?> GetByIdAsync(int id)
        {
            var e = await _context.Users.FindAsync(id);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<User?> GetByUserNameAsync(string userName)
        {
            var e = await _context.Users.FirstOrDefaultAsync(u => u.UserName == userName);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<User> InsertAsync(User user)
        {
            var entity = MapToEntity(user);
            _context.Users.Add(entity);
            await _context.SaveChangesAsync();
            user.Id = entity.Id;
            return user;
        }

        public async Task<bool> HasDuplicateUserNameAsync(string userName, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.Users.AnyAsync(u => u.UserName == userName && u.Id != excludeId.Value)
                : await _context.Users.AnyAsync(u => u.UserName == userName);
        }

        private static User MapToDomain(UserEntity e) => new()
        {
            Id = e.Id, UserName = e.UserName, FullName = e.FullName, NationalCode = e.NationalCode,
            Mobile = e.Mobile, Email = e.Email, AgencyId = e.AgencyId, IsActive = e.IsActive,
            LastLoginDate = e.LastLoginDate
        };

        private static UserEntity MapToEntity(User u) => new()
        {
            Id = u.Id, UserName = u.UserName, FullName = u.FullName, NationalCode = u.NationalCode,
            Mobile = u.Mobile, Email = u.Email, AgencyId = u.AgencyId, IsActive = u.IsActive,
            LastLoginDate = u.LastLoginDate
        };
    }
}
