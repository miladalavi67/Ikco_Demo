using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Receipts;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperReceiptRepository : IReceiptRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperReceiptRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetCountAsync(string? search = null, string? receiptType = null, string? chassis = null, DateTime? fromDate = null, DateTime? toDate = null)
        {
            var query = _context.Receipts.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search)) query = query.Where(r => r.ReceiptNo.Contains(search));
            if (fromDate.HasValue) query = query.Where(r => r.ReceiptDate >= fromDate.Value);
            if (toDate.HasValue) query = query.Where(r => r.ReceiptDate < toDate.Value.AddDays(1));
            return await query.CountAsync();
        }

        public async Task<ReceiptOperation?> GetByIdAsync(int id)
        {
            var e = await _context.Receipts.FindAsync(id);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<ReceiptOperation?> GetByReceiptNumberAsync(string receiptNumber)
        {
            var e = await _context.Receipts.FirstOrDefaultAsync(r => r.ReceiptNo == receiptNumber);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<ReceiptOperation> InsertAsync(ReceiptOperation receipt)
        {
            var entity = new ReceiptEntity
            {
                CarLogId = receipt.RefId, ReceiptNo = string.Empty, ReceiptDate = DateTime.Now, IsActive = true
            };
            _context.Receipts.Add(entity);
            await _context.SaveChangesAsync();
            receipt.Id = entity.Id;
            receipt.RefId = entity.CarLogId;
            return receipt;
        }

        public async Task<bool> HasDuplicateReceiptNumberAsync(string receiptNumber, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.Receipts.AnyAsync(r => r.ReceiptNo == receiptNumber && r.Id != excludeId.Value)
                : await _context.Receipts.AnyAsync(r => r.ReceiptNo == receiptNumber);
        }

        private static ReceiptOperation MapToDomain(ReceiptEntity e) => new() { Id = e.Id, RefId = e.CarLogId };
    }
}
