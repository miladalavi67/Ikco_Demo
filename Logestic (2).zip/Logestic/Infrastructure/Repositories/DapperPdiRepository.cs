using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Pdis;

namespace Logestic.Infrastructure.Repositories
{
    public class DapperPdiRepository : IPdiRepository
    {
        private readonly AfterSalesDbContext _context;
        public DapperPdiRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetCountAsync(string? search, DateTime? fromDate, DateTime? toDate, bool? onlyApproved)
        {
            var query = _context.Pdis.AsQueryable();
            if (fromDate.HasValue) query = query.Where(p => p.PdiDate >= fromDate.Value);
            if (toDate.HasValue) query = query.Where(p => p.PdiDate < toDate.Value.AddDays(1));
            return await query.CountAsync();
        }
        public async Task<Pdi?> GetByIdAsync(int id) { var e = await _context.Pdis.FindAsync(id); return e == null ? null : MapPdi(e); }
        public async Task<Pdi?> GetByChassisAsync(string chassisNumber) => null;
        public async Task<Pdi> InsertAsync(Pdi pdi) { var entity = new PdiEntity { CarLogId = pdi.CarLogId, PdiDate = pdi.PdiDate, AgencyId = pdi.AgencyId, IsPassed = pdi.IsPassed, Description = pdi.Description, UserId = pdi.UserId }; _context.Pdis.Add(entity); await _context.SaveChangesAsync(); pdi.Id = entity.Id; return pdi; }
        public async Task<bool> IsFinalAsync(int id) { var e = await _context.Pdis.FindAsync(id); return e?.IsPassed ?? false; }
        public async Task<PdiDetail> InsertDetailAsync(PdiDetail detail) { var entity = new PdiDetailEntity { PdiId = detail.PdiId, CheckItem = detail.CheckItem, IsOk = detail.IsOk, Description = detail.Description }; _context.PdiDetails.Add(entity); await _context.SaveChangesAsync(); detail.Id = entity.Id; return detail; }

        private static Pdi MapPdi(PdiEntity e) => new() { Id = e.Id, CarLogId = e.CarLogId, PdiDate = e.PdiDate, AgencyId = e.AgencyId, IsPassed = e.IsPassed, Description = e.Description, UserId = e.UserId };
    }
}
