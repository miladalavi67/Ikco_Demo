using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Domain.Parts;
using Logestic.Data;
using Logestic.Data.Entities;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCorePartRepository : IPartRepository
    {
        private readonly AfterSalesDbContext _context;

        public EfCorePartRepository(AfterSalesDbContext context)
        {
            _context = context;
        }

        public async Task<List<Part>> GetListAsync(string? search = null, bool? onlyLowStock = null, int skip = 0, int take = 20)
        {
            var query = _context.Parts.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(p => p.PartCode.Contains(search) || p.PartName.Contains(search));

            if (onlyLowStock == true)
                query = query.Where(p => p.StockQty <= p.MinStockQty);

            var entities = await query.OrderBy(p => p.PartCode).Skip(skip).Take(take).ToListAsync();
            return entities.ConvertAll(MapToDomain);
        }

        public async Task<int> GetCountAsync(string? search = null, bool? onlyLowStock = null)
        {
            var query = _context.Parts.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(p => p.PartCode.Contains(search) || p.PartName.Contains(search));

            if (onlyLowStock == true)
                query = query.Where(p => p.StockQty <= p.MinStockQty);

            return await query.CountAsync();
        }

        public async Task<Part?> GetByIdAsync(int id)
        {
            var entity = await _context.Parts.FindAsync(id);
            return entity == null ? null : MapToDomain(entity);
        }

        public async Task<List<Part>> GetActiveLookupAsync()
        {
            var entities = await _context.Parts.Where(p => p.IsActive).OrderBy(p => p.PartCode).ToListAsync();
            return entities.ConvertAll(MapToDomain);
        }

        public async Task<Part> InsertAsync(Part part)
        {
            var entity = MapToEntity(part);
            _context.Parts.Add(entity);
            await _context.SaveChangesAsync();
            return MapToDomain(entity);
        }

        public async Task UpdateAsync(Part part)
        {
            var entity = MapToEntity(part);
            _context.Parts.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await _context.Parts.FindAsync(id);
            if (entity != null)
            {
                _context.Parts.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        private static Part MapToDomain(PartEntity entity) => new Part
        {
            Id = entity.Id,
            PartCode = entity.PartCode,
            PartName = entity.PartName,
            UnitPrice = entity.UnitPrice,
            StockQty = entity.StockQty,
            MinStockQty = entity.MinStockQty,
            IsActive = entity.IsActive
        };

        private static PartEntity MapToEntity(Part part) => new PartEntity
        {
            Id = part.Id,
            PartCode = part.PartCode,
            PartName = part.PartName,
            UnitPrice = part.UnitPrice,
            StockQty = part.StockQty,
            MinStockQty = part.MinStockQty,
            IsActive = part.IsActive
        };
    }
}
