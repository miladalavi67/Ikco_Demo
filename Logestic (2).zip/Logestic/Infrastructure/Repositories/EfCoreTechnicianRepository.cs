using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain;
using Logestic.Domain.Technicians;

namespace Logestic.Infrastructure.Repositories
{
    /// <summary>
    /// پیاده‌سازی ریپازیتوری تعمیرکار با EF Core / LINQ.
    /// </summary>
    public class EfCoreTechnicianRepository : ITechnicianRepository
    {
        private readonly AfterSalesDbContext _context;

        public EfCoreTechnicianRepository(AfterSalesDbContext context)
        {
            _context = context;
        }

        public async Task<List<Technician>> GetListAsync(string? search = null, bool? onlyActive = null, int skip = 0, int take = 20)
        {
            var query = _context.Technicians.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(t => t.FullName.Contains(search) || t.PersonnelCode.StartsWith(search));

            if (onlyActive == true)
                query = query.Where(t => t.IsActive);

            var entities = await query.OrderBy(t => t.FullName).Skip(skip).Take(take).ToListAsync();
            return entities.ConvertAll(MapToDomain);
        }

        public async Task<int> GetCountAsync(string? search = null, bool? onlyActive = null)
        {
            var query = _context.Technicians.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(t => t.FullName.Contains(search) || t.PersonnelCode.StartsWith(search));

            if (onlyActive == true)
                query = query.Where(t => t.IsActive);

            return await query.CountAsync();
        }

        public async Task<Technician?> GetByIdAsync(int id)
        {
            var entity = await _context.Technicians.FindAsync(id);
            return entity == null ? null : MapToDomain(entity);
        }

        public async Task<List<Technician>> GetActiveLookupAsync()
        {
            var entities = await _context.Technicians
                .Where(t => t.IsActive)
                .OrderBy(t => t.FullName)
                .ToListAsync();
            return entities.ConvertAll(MapToDomain);
        }

        public async Task<Technician> InsertAsync(Technician technician)
        {
            var entity = MapToEntity(technician);
            _context.Technicians.Add(entity);
            await _context.SaveChangesAsync();
            technician.Id = entity.Id;
            return technician;
        }

        public async Task UpdateAsync(Technician technician)
        {
            var entity = await _context.Technicians.FindAsync(technician.Id)
                ?? throw new AfterSalesException("AfterSales:TechnicianNotFound", "تعمیرکار یافت نشد.");

            entity.FullName = technician.FullName;
            entity.PersonnelCode = technician.PersonnelCode;
            entity.Specialty = technician.Specialty;
            entity.HourlyRate = technician.HourlyRate;
            entity.IsActive = technician.IsActive;

            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await _context.Technicians.FindAsync(id);
            if (entity != null)
            {
                _context.Technicians.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> IsInUseAsync(int id)
        {
            return await _context.ServiceRequests.AnyAsync(r => r.TechnicianId == id);
        }

        public async Task<bool> HasDuplicatePersonnelCodeAsync(string personnelCode, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.Technicians.AnyAsync(t => t.PersonnelCode == personnelCode && t.Id != excludeId.Value)
                : await _context.Technicians.AnyAsync(t => t.PersonnelCode == personnelCode);
        }

        // --- نگاشت ---

        private static Technician MapToDomain(TechnicianEntity e) => new()
        {
            Id = e.Id,
            FullName = e.FullName,
            PersonnelCode = e.PersonnelCode,
            Specialty = e.Specialty,
            HourlyRate = e.HourlyRate,
            IsActive = e.IsActive
        };

        private static TechnicianEntity MapToEntity(Technician t) => new()
        {
            Id = t.Id,
            FullName = t.FullName,
            PersonnelCode = t.PersonnelCode,
            Specialty = t.Specialty,
            HourlyRate = t.HourlyRate,
            IsActive = t.IsActive
        };
    }
}
