using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logestic.Data;
using Logestic.Data.Entities;
using Logestic.Domain.Agencies;

namespace Logestic.Infrastructure.Repositories
{
    public class EfCoreAgencyRepository : IAgencyRepository
    {
        private readonly AfterSalesDbContext _context;
        public EfCoreAgencyRepository(AfterSalesDbContext context) { _context = context; }

        public async Task<int> GetCountAsync(string? search = null, AgencyType? type = null, string? province = null, bool? onlyActive = null)
        {
            var query = _context.Agencies.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search)) query = query.Where(a => a.AgencyName.Contains(search) || (a.Code != null && a.Code.Contains(search)));
            if (onlyActive == true) query = query.Where(a => a.IsActive);
            return await query.CountAsync();
        }

        public async Task<Agency?> GetByIdAsync(int id)
        {
            var e = await _context.Agencies.FindAsync(id);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<Agency?> GetByCodeAsync(string agencyCode)
        {
            var e = await _context.Agencies.FirstOrDefaultAsync(a => a.Code == agencyCode);
            return e == null ? null : MapToDomain(e);
        }

        public async Task<Agency> InsertAsync(Agency agency)
        {
            var entity = MapToEntity(agency);
            _context.Agencies.Add(entity);
            await _context.SaveChangesAsync();
            agency.Id = entity.Id;
            return agency;
        }

        public async Task<bool> HasDuplicateCodeAsync(string agencyCode, int? excludeId = null)
        {
            return excludeId.HasValue
                ? await _context.Agencies.AnyAsync(a => a.Code == agencyCode && a.Id != excludeId.Value)
                : await _context.Agencies.AnyAsync(a => a.Code == agencyCode);
        }

        public async Task<TehranAgencyLocation?> GetTehranLocationByIdAsync(int id)
        {
            var e = await _context.TehranAgencyLocations.FindAsync(id);
            return e == null ? null : MapToLocation(e);
        }

        public async Task<TehranAgencyLocation> InsertTehranLocationAsync(TehranAgencyLocation location)
        {
            var entity = MapToLocationEntity(location);
            _context.TehranAgencyLocations.Add(entity);
            await _context.SaveChangesAsync();
            location.Id = entity.Id;
            return location;
        }

        private static Agency MapToDomain(AgencyEntity e) => new()
        {
            Id = e.Id, AgencyName = e.AgencyName, Code = e.Code,
            Address = e.Address, Phone = e.Phone, IsActive = e.IsActive
        };

        private static AgencyEntity MapToEntity(Agency a) => new()
        {
            Id = a.Id, AgencyName = a.AgencyName, Code = a.Code,
            Address = a.Address, Phone = a.Phone, IsActive = a.IsActive
        };

        private static TehranAgencyLocation MapToLocation(TehranAgencyLocationEntity e) => new()
        {
            Id = e.Id, LocationName = e.LocationName, Code = e.Code,
            Address = e.Address, Latitude = e.Latitude, Longitude = e.Longitude, IsActive = e.IsActive
        };

        private static TehranAgencyLocationEntity MapToLocationEntity(TehranAgencyLocation l) => new()
        {
            Id = l.Id, LocationName = l.LocationName, Code = l.Code,
            Address = l.Address, Latitude = l.Latitude, Longitude = l.Longitude, IsActive = l.IsActive
        };
    }
}
