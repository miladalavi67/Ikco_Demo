using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Users;

namespace Logestic.Domain.Users
{
    public interface IUserRepository
    {
        Task<int> GetCountAsync(string? search = null, bool? onlyActive = null);
        Task<User?> GetByIdAsync(int id);
        Task<User?> GetByUserNameAsync(string userName);
        Task<User> InsertAsync(User user);
        Task<bool> HasDuplicateUserNameAsync(string userName, int? excludeId = null);
    }
}