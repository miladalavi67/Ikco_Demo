using System;

namespace Logestic.Domain.Users
{
    public class User : FullAuditedEntity<int>
    {
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string? NationalCode { get; set; }
        public string? Mobile { get; set; }
        public string? Email { get; set; }
        public int? AgencyId { get; set; }
        public bool IsActive { get; set; }
        public DateTime? LastLoginDate { get; set; }
    }

}