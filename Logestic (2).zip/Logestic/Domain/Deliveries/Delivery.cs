using System;

namespace Logestic.Domain.Deliveries
{
    /// <summary>
    /// نام مستعار برای DeliveryTransportHeader.
    /// </summary>
    public class Delivery : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
