using System;

namespace Logestic.Domain.Deliveries
{
    /// <summary>
    /// نام مستعار برای DeliveryTransportHeader — برای سازگاری با کد موجود.
    /// </summary>
    public class DeliveryTransport : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
