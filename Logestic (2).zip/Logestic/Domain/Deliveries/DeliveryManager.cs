using System.Threading.Tasks;

namespace Logestic.Domain.Deliveries
{
    /// <summary>
    /// سرویس دامنه Deliveries.
    /// </summary>
    public class DeliveryManager
    {
        public DeliveryManager() { }
    }
}
