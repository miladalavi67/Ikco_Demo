namespace Logestic.Domain.Deliveries
{
    public enum DeliveryState
    {
        Pending,
        InProgress,
        Completed,
        Cancelled,
    }
}
