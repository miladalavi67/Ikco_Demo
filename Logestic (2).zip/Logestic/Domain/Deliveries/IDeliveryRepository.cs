using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Deliveries;

namespace Logestic.Domain.Deliveries
{
    public interface IDeliveryRepository
    {
        Task<ListForExit?> GetListForExitByIdAsync(int id);
        Task<ListForExit> InsertListForExitAsync(ListForExit listForExit);
        Task<Bijak?> GetBijakByIdAsync(int id);
        Task<Bijak> InsertBijakAsync(Bijak bijak);
        Task<bool> HasDuplicateBijakNumberAsync(string bijakNumber, int? excludeId = null);
        Task<BlockDelivery?> GetBlockDeliveryByIdAsync(int id);
        Task<BlockDelivery?> GetActiveBlockByChassisAsync(string chassisNumber);
        Task<BlockDelivery> InsertBlockDeliveryAsync(BlockDelivery blockDelivery);
        Task<DeliveryTransport?> GetTransportByIdAsync(int id);
        Task<DeliveryTransport> InsertTransportAsync(DeliveryTransport transport);
    }
}