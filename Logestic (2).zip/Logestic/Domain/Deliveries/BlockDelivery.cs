using System;

namespace Logestic.Domain.Deliveries
{
    /// <summary>
    /// نام مستعار برای SltBlockDelivery — برای سازگاری با کد موجود.
    /// </summary>
    public class BlockDelivery : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
