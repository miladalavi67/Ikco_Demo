using System;

namespace Logestic.Domain.Deliveries
{
    /// <summary>
    /// بیجک - ثبت بیجک تحویل خودرو
    /// </summary>
    public class BatchBodyView : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public string? BodyNo { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// شماره ردیف بدنه تحویل - شماره ردیف تحویل بدنه خودرو
    /// </summary>
    public class Bijak : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public string BijakNo { get; set; }
        public DateTime BijakDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// شماره ردیف پالیسی تحویل - شماره ردیف تحویل پالیسی خودرو
    /// </summary>
    public class DeliveryRowNoBody : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int RowNo { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// جزئیات حمل تحویل - جزئیات حمل و نقل تحویل خودرو
    /// </summary>
    public class DeliveryRowNoPolicy : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int RowNo { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// سربرگ حمل تحویل - سربرگ حمل و نقل تحویل خودرو
    /// </summary>
    public class DeliveryTransportDetail : FullAuditedEntity<int>
    {
        public int DeliveryTransportHeaderId { get; set; }
        public int CarLogId { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// تحویل مقصد - تحویل خودرو به مقصد نهایی
    /// </summary>
    public class DeliveryTransportHeader : FullAuditedEntity<int>
    {
        public string TransportNo { get; set; }
        public DateTime TransportDate { get; set; }
        public int? DriverId { get; set; }
        public int? AgencyId { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// لیست خروج - لیست خودروهای آماده خروج از لجستیک
    /// </summary>
    public class DestDelivery : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// لاگ لیست خروج - سوابق لیست‌های خروج
    /// </summary>
    public class ListForExit : FullAuditedEntity<int>
    {
        public string ListNo { get; set; }
        public DateTime ListDate { get; set; }
        public int? AgencyId { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// بلاک تحویل Slt - بلاک‌های تحویلی ویژه
    /// </summary>
    public class ListForExitLog : FullAuditedEntity<int>
    {
        public int ListForExitId { get; set; }
        public int CarLogId { get; set; }
        public DateTime ActionDate { get; set; }
        public string? ActionType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    public class SltBlockDelivery : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public string BlockNo { get; set; }
        public DateTime BlockDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

}