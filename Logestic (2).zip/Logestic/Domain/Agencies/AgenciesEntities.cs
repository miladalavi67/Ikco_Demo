using System;

namespace Logestic.Domain.Agencies
{
    /// <summary>
    /// نمایندگی خودرو - اطلاعات نمایندگی‌های خودرو
    /// </summary>
    public class Agency : FullAuditedEntity<int>
    {
        public string AgencyName { get; set; }
        public string? Code { get; set; }
        public int? TehranAgencyLocationId { get; set; }
        public string? Address { get; set; }
        public string? Phone { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// موقعیت نمایندگی تهران - موقعیت مکانی نمایندگی‌های تهران
    /// </summary>
    public class TCarAgency : FullAuditedEntity<int>
    {
        public string AgencyCode { get; set; }
        public string AgencyName { get; set; }
        public int? TehranAgencyLocationId { get; set; }
        public string? Address { get; set; }
        public string? Phone { get; set; }
        public bool IsActive { get; set; }
    }

    public class TehranAgencyLocation : FullAuditedEntity<int>
    {
        public string LocationName { get; set; }
        public string? Code { get; set; }
        public string? Address { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public bool IsActive { get; set; }
    }

}