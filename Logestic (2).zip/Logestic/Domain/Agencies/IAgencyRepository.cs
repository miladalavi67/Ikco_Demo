using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Agencies;

namespace Logestic.Domain.Agencies
{
    public interface IAgencyRepository
    {
        Task<int> GetCountAsync(string? search = null, AgencyType? type = null, string? province = null, bool? onlyActive = null);
        Task<Agency?> GetByIdAsync(int id);
        Task<Agency?> GetByCodeAsync(string agencyCode);
        Task<Agency> InsertAsync(Agency agency);
        Task<bool> HasDuplicateCodeAsync(string agencyCode, int? excludeId = null);
        Task<TehranAgencyLocation?> GetTehranLocationByIdAsync(int id);
        Task<TehranAgencyLocation> InsertTehranLocationAsync(TehranAgencyLocation location);
    }
}