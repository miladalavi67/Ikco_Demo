namespace Logestic.Domain.Agencies
{
    public enum AgencyType
    {
        Main,
        Branch,
        Representative,
    }
}
