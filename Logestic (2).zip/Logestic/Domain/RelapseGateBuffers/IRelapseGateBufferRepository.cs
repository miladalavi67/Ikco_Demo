using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Logestic.Domain.RelapseGateBuffers
{
    public interface IRelapseGateBufferRepository
    {
        Task<List<RelapseBufferOperation>> GetListAsync(string? search = null, int skip = 0, int take = 20);
        Task<RelapseBufferOperation?> GetByIdAsync(int id);
        Task<RelapseBufferOperation> InsertAsync(RelapseBufferOperation entity);
        Task UpdateAsync(RelapseBufferOperation entity);
        Task DeleteAsync(int id);
    }
}
