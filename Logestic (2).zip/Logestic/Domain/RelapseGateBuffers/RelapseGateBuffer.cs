using System;

namespace Logestic.Domain.RelapseGateBuffers
{
    /// <summary>
    /// نام مستعار برای RelapseBufferOperation.
    /// </summary>
    public class RelapseGateBuffer : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
