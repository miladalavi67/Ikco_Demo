using System;

namespace Logestic.Domain.RelapseGateBuffers
{
    public class RelapseBufferOperation : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int? ExitGateId { get; set; }
        public DateTime OperationDate { get; set; }
        public string? OperationType { get; set; }
        public string? Reason { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsProcessed { get; set; }
    }

}