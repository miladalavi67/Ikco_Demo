using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.RelapseGateBuffers;

namespace Logestic.Domain.RelapseGateBuffers
{
    public interface IRelapseBufferRepository
    {
        Task<int> GetCountAsync(string? chassis = null, bool? processed = null, DateTime? fromDate = null, DateTime? toDate = null);
        Task<RelapseBufferOperation?> GetByIdAsync(int id);
        Task<RelapseBufferOperation> InsertAsync(RelapseBufferOperation operation);
    }
}