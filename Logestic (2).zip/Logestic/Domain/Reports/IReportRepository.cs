using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Logestic.Domain.Reports
{
    /// <summary>
    /// دسترسی به داده‌های گزارش‌ها.
    /// </summary>
    public interface IReportRepository
    {
        Task<List<TechnicianPerformanceRow>> GetTechnicianPerformanceAsync(DateTime? fromDate, DateTime? toDate);
        Task<List<RevenueByMonthRow>> GetRevenueByMonthAsync(int year);
        Task<List<LowStockPartRow>> GetLowStockPartsAsync();
    }

    public record TechnicianPerformanceRow(int TechnicianId, string FullName, string? Specialty, int RequestCount, decimal TotalHours, decimal TotalRevenue);
    public record RevenueByMonthRow(int MonthNo, int RequestCount, decimal LaborSum, decimal PartsSum, decimal TotalSum);
    public record LowStockPartRow(int PartId, string PartCode, string PartName, decimal UnitPrice, int StockQty, int MinStockQty);
}
