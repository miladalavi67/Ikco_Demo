using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.ServiceRequests;

namespace Logestic.Domain.ServiceRequests
{
    public interface IServiceRequestRepository
    {
        Task<int> GetCountAsync( string? search = null, int? statusId = null, DateTime? fromDate = null, DateTime? toDate = null);
        Task<ServiceRequest?> GetByIdAsync(int id);
        Task<(int RequestId, string RequestNo)> InsertAsync( int vehicleId, int? technicianId, DateTime requestDate, string? description, decimal laborHours, decimal discountAmount);
        Task<bool> IsFinalAsync(int requestId);
        Task DeleteAsync(int requestId);
    }
}