namespace Logestic.Domain.ServiceRequests
{
    public class ServiceStatus : Entity<int>
    {
        public string StatusName { get; set; } = string.Empty;
        public bool IsFinal { get; set; }
    }
}
