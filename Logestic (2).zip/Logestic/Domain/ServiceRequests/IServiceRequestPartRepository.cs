using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.ServiceRequests;

namespace Logestic.Domain.ServiceRequests
{
    public interface IServiceRequestPartRepository
    {
        Task<(int LineId, decimal UnitPrice)> AddAsync(int requestId, int partId, int quantity);
        Task<List<ServiceRequestPart>> GetByRequestAsync(int requestId);
        Task DeleteAsync(int lineId);
    }
}