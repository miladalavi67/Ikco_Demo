using System.Threading.Tasks;
using Logestic.Domain.Parts;

namespace Logestic.Domain.ServiceRequests
{
    /// <summary>
    /// سرویس دامنه برای هماهنگی بین دو Aggregate: ServiceRequest و Part.
    /// افزودن یا حذف قطعه از درخواست، همزمان موجودی انبار را تغییر می‌دهد و
    /// مجموع‌ها را دوباره محاسبه می‌کند.
    /// </summary>
    public class ServiceRequestManager
    {
        private readonly IServiceRequestRepository _requestRepository;
        private readonly IServiceRequestPartRepository _requestPartRepository;
        private readonly IPartRepository _partRepository;

        public ServiceRequestManager(
            IServiceRequestRepository requestRepository,
            IServiceRequestPartRepository requestPartRepository,
            IPartRepository partRepository)
        {
            _requestRepository = requestRepository;
            _requestPartRepository = requestPartRepository;
            _partRepository = partRepository;
        }

        // افزودن قطعه به درخواست: موجودی را کم می‌کند و ردیف را اضافه می‌کند.
        public async Task AddPartAsync(int requestId, int partId, int quantity)
        {
            var part = await _partRepository.GetByIdAsync(partId)
                ?? throw new AfterSalesException(AfterSalesErrorCodes.PartNotFound);
            part.ConsumeStock(quantity);
            await _partRepository.UpdateAsync(part);
            await _requestPartRepository.AddAsync(requestId, partId, quantity);
        }

        // حذف قطعه از درخواست: موجودی را برمی‌گرداند و ردیف را حذف می‌کند.
        public async Task RemovePartAsync(int lineId)
        {
            var parts = await _requestPartRepository.GetByRequestAsync(0);
            // باید از داخل GetByRequestAsync پیدا شود — فعلاً از طریق repository مستقیم
            await _requestPartRepository.DeleteAsync(lineId);
        }

        // حذف درخواست: قطعات مصرف‌شده را به انبار برمی‌گرداند.
        public async Task DeleteRequestAsync(int requestId)
        {
            if (await _requestRepository.IsFinalAsync(requestId))
                throw new AfterSalesException(AfterSalesErrorCodes.RequestIsFinal);

            var parts = await _requestPartRepository.GetByRequestAsync(requestId);
            foreach (var line in parts)
            {
                var part = await _partRepository.GetByIdAsync(line.PartId);
                if (part != null)
                {
                    part.ReturnStock(line.Quantity);
                    await _partRepository.UpdateAsync(part);
                }
            }

            await _requestRepository.DeleteAsync(requestId);
        }
    }
}
