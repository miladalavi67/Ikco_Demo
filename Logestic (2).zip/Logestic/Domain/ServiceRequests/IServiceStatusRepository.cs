using System.Collections.Generic;
using System.Threading.Tasks;

namespace Logestic.Domain.ServiceRequests
{
    public interface IServiceStatusRepository
    {
        Task<List<ServiceStatus>> GetAllAsync();
    }
}
