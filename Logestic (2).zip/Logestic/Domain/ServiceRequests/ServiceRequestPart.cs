namespace Logestic.Domain.ServiceRequests
{
    public class ServiceRequestPart : FullAuditedEntity<int>
    {
        public int RequestId { get; set; }
        public int PartId { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal LineTotal => Quantity * UnitPrice;
    }
}
