using System;
using System.Collections.Generic;
using System.Linq;

namespace Logestic.Domain.ServiceRequests
{
    public class ServiceRequest : FullAuditedEntity<int>
    {
        public string RequestNo { get; set; } = string.Empty;
        public int VehicleId { get; set; }
        public int CustomerId { get; set; }
        public int? TechnicianId { get; set; }
        public int StatusId { get; set; }
        public bool IsFinal { get; set; }
        public DateTime RequestDate { get; set; }
        public string? Description { get; set; }
        public decimal LaborHours { get; set; }
        public decimal LaborCost { get; set; }
        public decimal PartsCost { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal TotalCost { get; set; }
        public DateTime? CompletedDate { get; set; }

        // مجموعه ردیف‌های قطعه‌ای این درخواست (setter برای EF Core)
        public List<ServiceRequestPart> Parts { get; set; } = new();

        // درخواست به وضعیت پایانی (نهایی) رسیده است
        public bool IsTerminal => IsFinal;

        /// <summary>
        /// افزودن قطعه به درخواست: یک ردیف جدید می‌سازد و مجموع‌ها را دوباره محاسبه می‌کند.
        /// </summary>
        public void AddPart(int partId, int quantity, decimal unitPrice)
        {
            // ساخت ردیف قطعه جدید
            var line = new ServiceRequestPart
            {
                RequestId = Id,
                PartId = partId,
                Quantity = quantity,
                UnitPrice = unitPrice
            };

            Parts.Add(line);
            RecalculateTotals();
        }

        /// <summary>
        /// حذف ردیف قطعه از درخواست بر اساس شناسه ردیف و محاسبه دوباره مجموع‌ها.
        /// </summary>
        public void RemovePart(int lineId)
        {
            // یافتن ردیف مورد نظر
            var line = Parts.FirstOrDefault(p => p.Id == lineId);
            if (line == null)
                throw new AfterSalesException(
                    AfterSalesErrorCodes.RequestPartNotFound,
                    "ردیف قطعه یافت نشد");

            Parts.Remove(line);
            RecalculateTotals();
        }

        /// <summary>
        /// تغییر وضعیت درخواست. اگر وضعیت تکمیل‌شده (5) باشد، تاریخ تکمیل ثبت می‌شود.
        /// </summary>
        public void ChangeStatus(int statusId, bool isFinal)
        {
            StatusId = statusId;
            IsFinal = isFinal;

            // اگر وضعیت تکمیل‌شده باشد، تاریخ تکمیل را ثبت کن
            if (statusId == 5)
                CompletedDate = DateTime.Now;
            else
                CompletedDate = null;
        }

        /// <summary>
        /// محاسبه دوباره مجموع‌ها: هزینه قطعات و هزینه کل.
        /// </summary>
        private void RecalculateTotals()
        {
            // مجموع هزینه قطعات بر اساس LineTotal هر ردیف
            PartsCost = Parts.Sum(p => p.LineTotal);

            // هزینه کل = قطعات + دستمزد - تخفیف
            TotalCost = PartsCost + LaborCost - DiscountAmount;
        }
    }
}
