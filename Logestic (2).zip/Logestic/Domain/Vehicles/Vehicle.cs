using System;

namespace Logestic.Domain.Vehicles
{
    public class Vehicle : FullAuditedEntity<int>
    {
        public int CustomerId { get; set; }
        public string PlateNumber { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int ProductionYear { get; set; }
        public string? VIN { get; set; }
        public int Mileage { get; set; }

        public string DisplayTitle => $"{PlateNumber} - {Model}";
    }
}
