using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Vehicles;

namespace Logestic.Domain.Vehicles
{
    public interface IVehicleRepository
    {
        Task<int> GetCountAsync(string? search = null, int? customerId = null);
        Task<Vehicle?> GetByIdAsync(int id);
        Task<Vehicle> InsertAsync(Vehicle vehicle);
        Task<bool> IsInUseAsync(int id);
        Task<bool> HasDuplicatePlateAsync(string plateNumber, int? excludeId = null);
    }
}