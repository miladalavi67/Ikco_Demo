using System;

namespace Logestic.Domain
{
    public abstract class Entity<TId>
        where TId : notnull
    {
        public TId Id { get; set; } = default!;
    }

    public abstract class FullAuditedEntity<TId> : Entity<TId>
        where TId : notnull
    {
        public DateTime CreatedTime { get; set; }
        public DateTime? LastModificationTime { get; set; }
        public int? LastModifierId { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? DeletionTime { get; set; }
        public int? CreatorId { get; set; }
    }
}
