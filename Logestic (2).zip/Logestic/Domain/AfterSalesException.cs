using System;

namespace Logestic.Domain
{
    public class AfterSalesException : Exception
    {
        public string ErrorCode { get; }

        public AfterSalesException(string errorCode, string message) : base(message)
        {
            ErrorCode = errorCode;
        }

        // overload برای مواقعی که فقط کد خطا مشخص است؛ پیام پیش‌فرض همان کد خطا
        public AfterSalesException(string errorCode) : base(errorCode)
        {
            ErrorCode = errorCode;
        }
    }
}
