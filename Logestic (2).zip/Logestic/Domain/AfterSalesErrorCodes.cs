namespace Logestic.Domain
{
    public static class AfterSalesErrorCodes
    {
        public const string DuplicateNationalCode = "AfterSales:DuplicateNationalCode";
        public const string CustomerNotFound = "AfterSales:CustomerNotFound";
        public const string CustomerHasRequests = "AfterSales:CustomerHasRequests";
        public const string DuplicatePartCode = "AfterSales:DuplicatePartCode";
        public const string PartInUse = "AfterSales:PartInUse";
        public const string RequestIsFinal = "AfterSales:RequestIsFinal";
        public const string InvalidStatus = "AfterSales:InvalidStatus";
        public const string InvalidQuantity = "AfterSales:InvalidQuantity";
        public const string PartNotFound = "AfterSales:PartNotFound";
        public const string InsufficientStock = "AfterSales:InsufficientStock";
        public const string RequestPartNotFound = "AfterSales:RequestPartNotFound";

        // --- Gate ---
        public const string GateChassisAlreadyEntered = "AfterSales:GateChassisAlreadyEntered";
        public const string GateEnterNotFound = "AfterSales:GateEnterNotFound";
        public const string GateAlreadyExited = "AfterSales:GateAlreadyExited";
        public const string GateExitNotFound = "AfterSales:GateExitNotFound";
        public const string GateNotFound = "AfterSales:GateNotFound";
        public const string GateAlreadyConfirmed = "AfterSales:GateAlreadyConfirmed";
        public const string GateConfirmedCannotDelete = "AfterSales:GateConfirmedCannotDelete";

        // --- Placement ---
        public const string CellNotFound = "AfterSales:CellNotFound";
        public const string CellOccupied = "AfterSales:CellOccupied";
        public const string CellEmpty = "AfterSales:CellEmpty";

        // --- Technician ---
        public const string DuplicatePersonnelCode = "AfterSales:DuplicatePersonnelCode";
        public const string TechnicianNotFound = "AfterSales:TechnicianNotFound";
        public const string TechnicianInUse = "AfterSales:TechnicianInUse";

        // --- Vehicle ---
        public const string DuplicatePlate = "AfterSales:DuplicatePlate";
        public const string VehicleNotFound = "AfterSales:VehicleNotFound";
        public const string VehicleHasRequests = "AfterSales:VehicleHasRequests";

        // --- Pelak ---
        public const string PelakNotFound = "AfterSales:PelakNotFound";
        public const string PelakNotAvailable = "AfterSales:PelakNotAvailable";
        public const string PelakNotInstalled = "AfterSales:PelakNotInstalled";
        public const string PelakFaultNotFound = "AfterSales:PelakFaultNotFound";
        public const string PelakNoAccess = "AfterSales:PelakNoAccess";
        public const string DuplicatePlateNumber = "AfterSales:DuplicatePlateNumber";

        // --- PDI ---
        public const string PdiNotFound = "AfterSales:PdiNotFound";
        public const string PdiAlreadyExists = "AfterSales:PdiAlreadyExists";
        public const string PdiAlreadyApproved = "AfterSales:PdiAlreadyApproved";
        public const string PdiNoDetails = "AfterSales:PdiNoDetails";
        public const string PdiApprovedCannotDelete = "AfterSales:PdiApprovedCannotDelete";

        // --- Fault ---
        public const string FaultNotFound = "AfterSales:FaultNotFound";
        public const string FaultAlreadyResolved = "AfterSales:FaultAlreadyResolved";
        public const string FaultResolvedCannotDelete = "AfterSales:FaultResolvedCannotDelete";

        // --- Repair ---
        public const string RepairNotFound = "AfterSales:RepairNotFound";
        public const string RepairAlreadyCompleted = "AfterSales:RepairAlreadyCompleted";

        // --- Receipt ---
        public const string ReceiptNotFound = "AfterSales:ReceiptNotFound";
        public const string DuplicateReceiptNumber = "AfterSales:DuplicateReceiptNumber";

        // --- RegisterRequest ---
        public const string RegisterRequestNotFound = "AfterSales:RegisterRequestNotFound";
        public const string DuplicateRequestNumber = "AfterSales:DuplicateRequestNumber";

        // --- RelapseGateBuffer ---
        public const string RelapseBufferNotFound = "AfterSales:RelapseBufferNotFound";
        public const string RelapseBufferAlreadyProcessed = "AfterSales:RelapseBufferAlreadyProcessed";

        // --- Delivery ---
        public const string DeliveryBlocked = "AfterSales:DeliveryBlocked";
        public const string DeliveryAlreadyBlocked = "AfterSales:DeliveryAlreadyBlocked";
        public const string DeliveryAlreadyUnblocked = "AfterSales:DeliveryAlreadyUnblocked";
        public const string DeliveryBlockNotFound = "AfterSales:DeliveryBlockNotFound";
        public const string DuplicateBijakNumber = "AfterSales:DuplicateBijakNumber";

        // --- Sale ---
        public const string SaleAlreadyExists = "AfterSales:SaleAlreadyExists";
        public const string SaleAlreadyReserved = "AfterSales:SaleAlreadyReserved";
        public const string SaleAlreadyCancelled = "AfterSales:SaleAlreadyCancelled";
        public const string SaleReserveNotFound = "AfterSales:SaleReserveNotFound";
        public const string DuplicateSaleNumber = "AfterSales:DuplicateSaleNumber";
        public const string DuplicateFactorNumber = "AfterSales:DuplicateFactorNumber";
        public const string DuplicateContractNumber = "AfterSales:DuplicateContractNumber";

        // --- Agency ---
        public const string AgencyNotFound = "AfterSales:AgencyNotFound";
        public const string DuplicateAgencyCode = "AfterSales:DuplicateAgencyCode";

        // --- User ---
        public const string UserNotFound = "AfterSales:UserNotFound";
        public const string DuplicateUserName = "AfterSales:DuplicateUserName";

        // --- Driver ---
        public const string DriverNotFound = "AfterSales:DriverNotFound";
        public const string DriverInUse = "AfterSales:DriverInUse";
        public const string DuplicateDriverCode = "AfterSales:DuplicateDriverCode";

        // --- CarType ---
        public const string CarTypeNotFound = "AfterSales:CarTypeNotFound";
        public const string CarTypeInUse = "AfterSales:CarTypeInUse";
    }
}
