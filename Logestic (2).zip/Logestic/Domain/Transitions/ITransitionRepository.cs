using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Transitions;

namespace Logestic.Domain.Transitions
{
    public interface ITransitionRepository
    {
        Task<Flow?> GetFlowByIdAsync(int id);
        Task<Flow> InsertFlowAsync(Flow flow);
        Task<Step?> GetStepByIdAsync(int id);
        Task<Step> InsertStepAsync(Step step);
        Task<Transition> InsertTransitionAsync(Transition transition);
        Task<bool> CanTransitionAsync(int fromStepId, int toStepId);
        Task<FlowTypeTransition> InsertFlowTypeTransitionAsync(FlowTypeTransition transition);
        Task<bool> HasUserFlowTypeAsync(int userId, int flowId);
    }
}