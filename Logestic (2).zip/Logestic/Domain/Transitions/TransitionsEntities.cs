using System;

namespace Logestic.Domain.Transitions
{
    /// <summary>
    /// جریان نوع گذار - ارتباط نوع گذار با جریان
    /// </summary>
    public class Flow : FullAuditedEntity<int>
    {
        public string FlowName { get; set; }
        public string? Code { get; set; }
        public int? FlowTypeId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// مرحله - مراحل جریان کاری لجستیک
    /// </summary>
    public class FlowTypeTransition : FullAuditedEntity<int>
    {
        public int FlowId { get; set; }
        public int TransitionId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// گذار - گذارهای بین مراحل جریان کاری
    /// </summary>
    public class Step : FullAuditedEntity<int>
    {
        public string StepName { get; set; }
        public string? Code { get; set; }
        public int? FlowId { get; set; }
        public int OrderNo { get; set; }
        public bool IsFinal { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// نوع جریان کاربر - نوع جریان‌های اختصاصی کاربر
    /// </summary>
    public class Transition : FullAuditedEntity<int>
    {
        public int FromStepId { get; set; }
        public int ToStepId { get; set; }
        public string? TransitionName { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// نوع جریان - انواع جریان‌های کاری لجستیک
    /// </summary>
    public class UserFlowType : FullAuditedEntity<int>
    {
        public int UserId { get; set; }
        public int FlowTypeId { get; set; }
        public bool HasAccess { get; set; }
    }

    public class FlowType : FullAuditedEntity<int>
    {
        public string TypeName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

}