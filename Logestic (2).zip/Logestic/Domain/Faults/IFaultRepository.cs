using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Faults;

namespace Logestic.Domain.Faults
{
    public interface IFaultRepository
    {
        Task<int> GetCountAsync(string? chassis = null, FaultLevel? level = null, bool? resolved = null, DateTime? fromDate = null, DateTime? toDate = null);
        Task<Fault?> GetByIdAsync(int id);
        Task<Fault> InsertAsync(Fault fault);
        Task<FaultBody?> GetBodyByIdAsync(int id);
        Task<FaultBody> InsertBodyAsync(FaultBody body);
        Task<FaultLevel?> GetLevelByIdAsync(int id);
        Task<FaultLevel> InsertLevelAsync(FaultLevel level);
        Task<FaultPart?> GetPartByIdAsync(int id);
        Task<FaultPart> InsertPartAsync(FaultPart part);
        Task<FaultSource?> GetSourceByIdAsync(int id);
        Task<FaultSource> InsertSourceAsync(FaultSource source);
    }
}