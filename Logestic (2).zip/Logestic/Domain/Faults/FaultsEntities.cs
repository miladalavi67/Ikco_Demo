using System;

namespace Logestic.Domain.Faults
{
    /// <summary>
    /// بدنه خرابی - دسته‌بندی خرابی‌های خودرو
    /// </summary>
    public class Fault : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int? FaultBodyId { get; set; }
        public int? FaultLevelId { get; set; }
        public int? FaultSourceId { get; set; }
        public DateTime FaultDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsResolved { get; set; }
    }

    /// <summary>
    /// سطح تشخیص خرابی - سطح تشخیص خرابی خودرو
    /// </summary>
    public class FaultBody : FullAuditedEntity<int>
    {
        public string BodyName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// سطح خرابی - شدت و سطح خرابی خودرو
    /// </summary>
    public class FaultDetectLevel : FullAuditedEntity<int>
    {
        public string LevelName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// قطعه خرابی - قطعات مرتبط با خرابی خودرو
    /// </summary>
    public class FaultLevel : FullAuditedEntity<int>
    {
        public string LevelName { get; set; }
        public string? Code { get; set; }
        public int Severity { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// منبع خرابی - منبع ایجاد خرابی خودرو
    /// </summary>
    public class FaultPart : FullAuditedEntity<int>
    {
        public int FaultId { get; set; }
        public string PartCode { get; set; }
        public string PartName { get; set; }
        public int Quantity { get; set; }
        public string? Description { get; set; }
    }

    public class FaultSource : FullAuditedEntity<int>
    {
        public string SourceName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

}