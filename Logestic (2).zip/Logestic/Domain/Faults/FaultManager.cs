using System.Threading.Tasks;

namespace Logestic.Domain.Faults
{
    /// <summary>
    /// سرویس دامنه Faults.
    /// </summary>
    public class FaultManager
    {
        public FaultManager() { }
    }
}
