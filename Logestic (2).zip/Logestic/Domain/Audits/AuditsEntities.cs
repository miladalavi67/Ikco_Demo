using System;

namespace Logestic.Domain.Audits
{
    /// <summary>
    /// نوع بازرسی - انواع بازرسی‌های خودرو در لجستیک
    /// </summary>
    public class AuditDetail : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int? AuditTypeId { get; set; }
        public DateTime AuditDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsPassed { get; set; }
    }

    public class AuditType : FullAuditedEntity<int>
    {
        public string TypeName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

}