using System;

namespace Logestic.Domain.Audits
{
    /// <summary>
    /// نام مستعار برای AuditDetail.
    /// </summary>
    public class AuditLog : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
