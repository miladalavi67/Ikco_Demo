using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Audits;

namespace Logestic.Domain.Audits
{
    public interface IAuditRepository
    {
        Task<AuditDetail?> GetDetailByIdAsync(int id);
        Task<AuditDetail> InsertDetailAsync(AuditDetail detail);
        Task<AuditType?> GetTypeByIdAsync(int id);
        Task<AuditType> InsertTypeAsync(AuditType type);
    }
}