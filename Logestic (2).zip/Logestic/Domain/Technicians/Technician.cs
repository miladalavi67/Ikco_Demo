namespace Logestic.Domain.Technicians
{
    public class Technician : FullAuditedEntity<int>
    {
        public string FullName { get; set; } = string.Empty;
        public string PersonnelCode { get; set; } = string.Empty;
        public string? Specialty { get; set; }
        public decimal HourlyRate { get; set; }
        public bool IsActive { get; set; }
    }
}
