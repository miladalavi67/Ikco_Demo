using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Technicians;

namespace Logestic.Domain.Technicians
{
    public interface ITechnicianRepository
    {
        Task<int> GetCountAsync(string? search = null, bool? onlyActive = null);
        Task<Technician?> GetByIdAsync(int id);
        Task<Technician> InsertAsync(Technician technician);
        Task<bool> IsInUseAsync(int id);
        Task<bool> HasDuplicatePersonnelCodeAsync(string personnelCode, int? excludeId = null);
    }
}