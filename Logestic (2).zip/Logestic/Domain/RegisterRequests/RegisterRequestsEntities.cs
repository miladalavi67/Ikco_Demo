using System;

namespace Logestic.Domain.RegisterRequests
{
    /// <summary>
    /// درخواست مدیریتی - درخواست‌های مدیریتی در لجستیک
    /// </summary>
    public class RegisterRequest : FullAuditedEntity<int>
    {
        public string RequestNo { get; set; }
        public int CarLogId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime RequestDate { get; set; }
        public string? RequestType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsApproved { get; set; }
    }

    public class ManagementRequest : FullAuditedEntity<int>
    {
        public string RequestNo { get; set; }
        public int CarLogId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime RequestDate { get; set; }
        public string? RequestType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsApproved { get; set; }
    }

}