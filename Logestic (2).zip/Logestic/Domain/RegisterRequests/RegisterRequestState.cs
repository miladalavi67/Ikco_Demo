namespace Logestic.Domain.RegisterRequests
{
    public enum RegisterRequestState
    {
        Draft,
        Submitted,
        Approved,
        Rejected,
        Completed,
    }
}
