using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.RegisterRequests;

namespace Logestic.Domain.RegisterRequests
{
    public interface IRegisterRequestRepository
    {
        Task<int> GetCountAsync(string? search = null, RegisterRequestState? state = null, string? chassis = null, DateTime? fromDate = null, DateTime? toDate = null);
        Task<RegisterRequest?> GetByIdAsync(int id);
        Task<RegisterRequest?> GetByRequestNumberAsync(string requestNumber);
        Task<RegisterRequest> InsertAsync(RegisterRequest request);
        Task<bool> HasDuplicateRequestNumberAsync(string requestNumber, int? excludeId = null);
        Task<ManagementRequest?> GetManagementByIdAsync(int id);
        Task<ManagementRequest> InsertManagementAsync(ManagementRequest request);
    }
}