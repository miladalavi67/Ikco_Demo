using System.Threading.Tasks;

namespace Logestic.Domain.RegisterRequests
{
    /// <summary>
    /// سرویس دامنه RegisterRequests.
    /// </summary>
    public class RegisterRequestManager
    {
        public RegisterRequestManager() { }
    }
}
