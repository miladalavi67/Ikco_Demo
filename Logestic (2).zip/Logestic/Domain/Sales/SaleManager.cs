using System.Threading.Tasks;

namespace Logestic.Domain.Sales
{
    /// <summary>
    /// سرویس دامنه Sales.
    /// </summary>
    public class SaleManager
    {
        public SaleManager() { }
    }
}
