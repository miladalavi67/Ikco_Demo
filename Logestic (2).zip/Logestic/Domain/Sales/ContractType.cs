namespace Logestic.Domain.Sales
{
    public enum ContractType
    {
        Cash,
        Installment,
        Lease,
    }
}
