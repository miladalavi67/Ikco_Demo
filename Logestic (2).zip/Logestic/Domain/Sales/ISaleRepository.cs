using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Sales;

namespace Logestic.Domain.Sales
{
    public interface ISaleRepository
    {
        Task<CarSale?> GetSaleByIdAsync(int id);
        Task<CarSale?> GetSaleByChassisAsync(string chassisNumber);
        Task<CarSale> InsertSaleAsync(CarSale sale);
        Task<bool> HasDuplicateSaleNumberAsync(string saleNumber, int? excludeId = null);
        Task<CarLog> InsertLogAsync(CarLog log);
        Task<FactorHeader?> GetFactorByIdAsync(int id);
        Task<FactorHeader> InsertFactorAsync(FactorHeader factor);
        Task<ContractHeader?> GetContractByIdAsync(int id);
        Task<ContractHeader> InsertContractAsync(ContractHeader contract);
        Task<ContractDetail> InsertContractDetailAsync(ContractDetail detail);
        Task<CarReserveAgencyLog?> GetActiveReserveByChassisAsync(string chassisNumber);
        Task<CarReserveAgencyLog> InsertReserveLogAsync(CarReserveAgencyLog log);
    }
}