using System;

namespace Logestic.Domain.Sales
{
    /// <summary>
    /// لاگ رزرو نمایندگی خودرو - سوابق رزرو خودرو برای نمایندگی‌ها
    /// </summary>
    public class CarLog : FullAuditedEntity<int>
    {
        public string? Pelak { get; set; }
        public string? VIN { get; set; }
        public int? CarTypeId { get; set; }
        public int? CarSaleId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime? EnterDate { get; set; }
        public DateTime? ExitDate { get; set; }
        public int? CurrentCellId { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// فروش خودرو - اطلاعات فروش خودرو
    /// </summary>
    public class CarReserveAgencyLog : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int AgencyId { get; set; }
        public DateTime ReserveDate { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// جزئیات قرارداد - جزئیات قرارداد فروش خودرو
    /// </summary>
    public class CarSale : FullAuditedEntity<int>
    {
        public string SaleNo { get; set; }
        public DateTime SaleDate { get; set; }
        public int? ContractHeaderId { get; set; }
        public int? FactorHeaderId { get; set; }
        public int? CustomerId { get; set; }
        public int? AgencyId { get; set; }
        public decimal SaleAmount { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// سربرگ قرارداد - سربرگ قرارداد فروش خودرو
    /// </summary>
    public class ContractDetail : FullAuditedEntity<int>
    {
        public int ContractHeaderId { get; set; }
        public string ItemName { get; set; }
        public decimal Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// سربرگ فاکتور - فاکتور فروش خودرو
    /// </summary>
    public class ContractHeader : FullAuditedEntity<int>
    {
        public string ContractNo { get; set; }
        public DateTime ContractDate { get; set; }
        public int? CustomerId { get; set; }
        public int? AgencyId { get; set; }
        public decimal TotalAmount { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// وضعیت فروش - وضعیت‌های فروش خودرو
    /// </summary>
    public class FactorHeader : FullAuditedEntity<int>
    {
        public string FactorNo { get; set; }
        public DateTime FactorDate { get; set; }
        public int? ContractHeaderId { get; set; }
        public int? CustomerId { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal FinalAmount { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    public class SaleState : FullAuditedEntity<int>
    {
        public string StateName { get; set; }
        public string? Code { get; set; }
        public bool IsFinal { get; set; }
        public bool IsActive { get; set; }
    }

}