namespace Logestic.Domain.Sales
{
    public enum SaleStateType
    {
        Pending,
        Confirmed,
        Cancelled,
        Completed,
    }
}
