namespace Logestic.Domain.Gates
{
    public enum GateMethod
    {
        Manual,
        Automatic,
        Remote,
    }
}
