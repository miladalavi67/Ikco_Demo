using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Gates;

namespace Logestic.Domain.Gates
{
    public interface IGateOperationRepository
    {
        Task<int> GetCountAsync( string? search = null, GateDirection? direction = null, GateType? gateType = null, GateMethod? gateMethod = null, DateTime? fromDate = null, DateTime? toDate = null);
        Task<GateOperation?> GetByIdAsync(int id);
        Task<EnterGate> InsertEnterAsync(EnterGate gate);
        Task<ExitGate> InsertExitAsync(ExitGate gate);
        Task<RelapseGate> InsertRelapseAsync(RelapseGate gate);
        Task<bool> IsChassisInUseAsync(string chassisNumber, GateDirection direction);
        Task<EnterGate?> GetLastEnterByChassisAsync(string chassisNumber);
        Task<ExitGate?> GetLastExitByChassisAsync(string chassisNumber);
    }
}