using System;

namespace Logestic.Domain.Gates
{
    /// <summary>
    /// نام مستعار برای RelapseGateOperation — برای سازگاری با کد موجود.
    /// </summary>
    public class GateOperation : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
