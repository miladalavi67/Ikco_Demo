namespace Logestic.Domain.Gates
{
    public enum GateDirection
    {
        Enter,
        Exit,
        Relapse,
    }
}
