using System;

namespace Logestic.Domain.Gates
{
    /// <summary>
    /// خروج خودرو از گیت - عملیات خروج از گات لجستیک
    /// </summary>
    public class EnterGate : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime EnterDate { get; set; }
        public string? DriverName { get; set; }
        public string? Pelak { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// عملیات بازگشت به گیت - بازگشت خودرو از خروج به گات
    /// </summary>
    public class ExitGate : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime ExitDate { get; set; }
        public string? DriverName { get; set; }
        public string? Pelak { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsActive { get; set; }
    }

    public class RelapseGateOperation : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int? ExitGateId { get; set; }
        public DateTime RelapseDate { get; set; }
        public string? Reason { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsActive { get; set; }
    }

}