namespace Logestic.Domain.Gates
{
    public enum GateType
    {
        Normal,
        Express,
        Special,
    }
}
