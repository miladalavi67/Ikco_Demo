using System;

namespace Logestic.Domain.BaseInfo
{
    /// <summary>
    /// راننده - راننده‌های حامل خودرو در لجستیک
    /// </summary>
    public class CarType : FullAuditedEntity<int>
    {
        public string TypeName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// شغل راننده - عناوین شغلی راننده‌ها
    /// </summary>
    public class Driver : FullAuditedEntity<int>
    {
        public string FullName { get; set; }
        public string? NationalCode { get; set; }
        public string? Mobile { get; set; }
        public int? DriverJobId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// دسترسی راننده به مرحله - سطح دسترسی راننده به مراحل جریان
    /// </summary>
    public class DriverJob : FullAuditedEntity<int>
    {
        public string JobName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// دسترسی کاربر به جریان - سطح دسترسی کاربر به جریان‌های لجستیک
    /// </summary>
    public class DriverStepAccess : FullAuditedEntity<int>
    {
        public int DriverId { get; set; }
        public int StepId { get; set; }
        public bool HasAccess { get; set; }
    }

    /// <summary>
    /// دسترسی کاربر به منطقه - سطح دسترسی کاربر به مناطق لجستیک
    /// </summary>
    public class UserFlowAccess : FullAuditedEntity<int>
    {
        public int UserId { get; set; }
        public int FlowId { get; set; }
        public bool HasAccess { get; set; }
    }

    /// <summary>
    /// وضعیت بدنه - وضعیت بدنه خودرو در لجستیک
    /// </summary>
    public class UserZoneAccess : FullAuditedEntity<int>
    {
        public int UserId { get; set; }
        public int ZoneId { get; set; }
        public bool HasAccess { get; set; }
    }

    /// <summary>
    /// تولید خودرو - اطلاعات تولید خودرو ایران‌خودرو
    /// </summary>
    public class BodyState : FullAuditedEntity<int>
    {
        public string StateName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// گزینه‌های شرکت عملیاتی (Opco) - تنظیمات شرکت‌های عملیاتی
    /// </summary>
    public class TCarProd : FullAuditedEntity<int>
    {
        public string ProdCode { get; set; }
        public string ProdName { get; set; }
        public int? CarTypeId { get; set; }
        public DateTime? ProdDate { get; set; }
        public bool IsActive { get; set; }
    }

    public class OpcoOption : FullAuditedEntity<int>
    {
        public string OptionName { get; set; }
        public string? OptionValue { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

}