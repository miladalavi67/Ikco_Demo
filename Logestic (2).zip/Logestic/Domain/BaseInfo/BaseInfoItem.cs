using System;

namespace Logestic.Domain.BaseInfo
{
    /// <summary>
    /// نام مستعار برای CarType.
    /// </summary>
    public class BaseInfoItem : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
