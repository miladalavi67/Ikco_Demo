using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.BaseInfo;

namespace Logestic.Domain.BaseInfo
{
    public interface IBaseInfoRepository
    {
        Task<int> GetDriverCountAsync(string? search = null, DriverJobType? jobType = null, bool? onlyActive = null);
        Task<Driver?> GetDriverByIdAsync(int id);
        Task<Driver> InsertDriverAsync(Driver driver);
        Task<bool> IsDriverInUseAsync(int id);
        Task<bool> HasDuplicateDriverCodeAsync(string personnelCode, int? excludeId = null);
        Task<DriverJob?> GetDriverJobByIdAsync(int id);
        Task<DriverJob> InsertDriverJobAsync(DriverJob job);
        Task<bool> HasDriverStepAccessAsync(int driverId, int stepId);
        Task<CarType?> GetCarTypeByIdAsync(int id);
        Task<CarType> InsertCarTypeAsync(CarType carType);
        Task<bool> HasUserFlowAccessAsync(int userId, int flowId);
        Task<bool> HasUserZoneAccessAsync(int userId, int zoneId);
    }
}