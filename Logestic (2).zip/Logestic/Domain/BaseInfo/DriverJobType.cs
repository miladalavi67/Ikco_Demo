namespace Logestic.Domain.BaseInfo
{
    public enum DriverJobType
    {
        Driver,
        Assistant,
        Other,
    }
}
