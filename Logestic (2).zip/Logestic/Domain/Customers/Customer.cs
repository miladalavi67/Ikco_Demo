using System;

namespace Logestic.Domain.Customers
{
    public class Customer : FullAuditedEntity<int>
    {
        public string FullName { get; set; } = string.Empty;
        public string NationalCode { get; set; } = string.Empty;
        public string Mobile { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string? City { get; set; }
        public string? Address { get; set; }
        public bool IsActive { get; set; }
    }
}
