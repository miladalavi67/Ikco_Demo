using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Customers;

namespace Logestic.Domain.Customers
{
    public interface ICustomerRepository
    {
        Task<int> GetCountAsync(string? search = null, bool? onlyActive = null);
        Task<Customer?> GetByIdAsync(int id);
        Task<int> GetVehicleCountAsync(int customerId);
        Task<Customer> InsertAsync(Customer customer);
        Task<bool> IsInUseAsync(int id);
        Task<bool> HasDuplicateNationalCodeAsync(string nationalCode, int? excludeId = null);
        Task<int> GetCompletedRequestCountAsync(int customerId);
    }
}