using System.Threading.Tasks;

namespace Logestic.Domain.Customers
{
    /// <summary>
    /// منطق دامنه برای حذف مشتری. مشتری‌ای که خودرو ثبت شده قابل حذف نیست.
    /// </summary>
    public class CustomerManager
    {
        // بررسی می‌کند که آیا مشتری قابل حذف است.
        public void CheckCanDelete(bool hasVehicles)
        {
            if (hasVehicles)
                throw new AfterSalesException(AfterSalesErrorCodes.CustomerHasRequests);
        }
    }
}
