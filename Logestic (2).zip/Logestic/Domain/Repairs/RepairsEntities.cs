using System;

namespace Logestic.Domain.Repairs
{
    /// <summary>
    /// جزئیات تعمیر - جزئیات قطعات و عملیات تعمیر خودرو
    /// </summary>
    public class Repair : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public DateTime RepairDate { get; set; }
        public string? RepairType { get; set; }
        public string? Description { get; set; }
        public decimal? Cost { get; set; }
        public int? TechnicianId { get; set; }
        public int? UserId { get; set; }
        public bool IsCompleted { get; set; }
    }

    public class RepairDetail : FullAuditedEntity<int>
    {
        public int RepairId { get; set; }
        public string? PartCode { get; set; }
        public string? PartName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string? Description { get; set; }
    }

}