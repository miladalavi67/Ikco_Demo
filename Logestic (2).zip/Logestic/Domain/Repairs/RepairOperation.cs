using System;

namespace Logestic.Domain.Repairs
{
    /// <summary>
    /// نام مستعار برای RepairDetail — برای سازگاری با کد موجود.
    /// </summary>
    public class RepairOperation : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
