using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Repairs;

namespace Logestic.Domain.Repairs
{
    public interface IRepairRepository
    {
        Task<int> GetCountAsync(string? chassis = null, bool? completed = null, DateTime? fromDate = null, DateTime? toDate = null);
        Task<RepairOperation?> GetByIdAsync(int id);
        Task<RepairOperation> InsertAsync(RepairOperation repair);
    }
}