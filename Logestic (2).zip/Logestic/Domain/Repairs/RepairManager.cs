using System.Threading.Tasks;

namespace Logestic.Domain.Repairs
{
    /// <summary>
    /// سرویس دامنه Repairs.
    /// </summary>
    public class RepairManager
    {
        public RepairManager() { }
    }
}
