using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Pdis;

namespace Logestic.Domain.Pdis
{
    public interface IPdiRepository
    {
        Task<int> GetCountAsync(string? search = null, DateTime? fromDate = null, DateTime? toDate = null, bool? onlyApproved = null);
        Task<Pdi?> GetByIdAsync(int id);
        Task<Pdi?> GetByChassisAsync(string chassisNumber);
        Task<Pdi> InsertAsync(Pdi pdi);
        Task<bool> IsFinalAsync(int id);
        Task<PdiDetail> InsertDetailAsync(PdiDetail detail);
    }
}