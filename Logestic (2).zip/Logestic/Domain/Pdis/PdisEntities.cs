using System;

namespace Logestic.Domain.Pdis
{
    /// <summary>
    /// جزئیات تست تحویل خودرو - آیتم‌های بررسی شده در PDI
    /// </summary>
    public class Pdi : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public DateTime PdiDate { get; set; }
        public int? AgencyId { get; set; }
        public bool IsPassed { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    public class PdiDetail : FullAuditedEntity<int>
    {
        public int PdiId { get; set; }
        public string CheckItem { get; set; }
        public bool IsOk { get; set; }
        public string? Description { get; set; }
    }

}