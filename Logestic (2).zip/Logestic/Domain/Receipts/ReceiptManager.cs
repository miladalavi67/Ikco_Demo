using System.Threading.Tasks;

namespace Logestic.Domain.Receipts
{
    /// <summary>
    /// سرویس دامنه Receipts.
    /// </summary>
    public class ReceiptManager
    {
        public ReceiptManager() { }
    }
}
