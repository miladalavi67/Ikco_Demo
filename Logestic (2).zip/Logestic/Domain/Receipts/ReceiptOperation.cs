using System;

namespace Logestic.Domain.Receipts
{
    /// <summary>
    /// نام مستعار برای ReceiptDetail — برای سازگاری با کد موجود.
    /// </summary>
    public class ReceiptOperation : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
