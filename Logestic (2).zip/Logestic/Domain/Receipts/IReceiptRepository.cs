using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Receipts;

namespace Logestic.Domain.Receipts
{
    public interface IReceiptRepository
    {
        Task<int> GetCountAsync(string? search = null, string? receiptType = null, string? chassis = null, DateTime? fromDate = null, DateTime? toDate = null);
        Task<ReceiptOperation?> GetByIdAsync(int id);
        Task<ReceiptOperation?> GetByReceiptNumberAsync(string receiptNumber);
        Task<ReceiptOperation> InsertAsync(ReceiptOperation receipt);
        Task<bool> HasDuplicateReceiptNumberAsync(string receiptNumber, int? excludeId = null);
    }
}