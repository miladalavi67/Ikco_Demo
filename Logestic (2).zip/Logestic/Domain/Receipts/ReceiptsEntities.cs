using System;

namespace Logestic.Domain.Receipts
{
    /// <summary>
    /// جزئیات رسید - جزئیات اقلام رسید
    /// </summary>
    public class Receipt : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public string ReceiptNo { get; set; }
        public DateTime ReceiptDate { get; set; }
        public string? ReceiptType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsActive { get; set; }
    }

    public class ReceiptDetail : FullAuditedEntity<int>
    {
        public int ReceiptId { get; set; }
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public string? Description { get; set; }
    }

}