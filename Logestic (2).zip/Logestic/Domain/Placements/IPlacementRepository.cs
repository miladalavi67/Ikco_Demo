using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Placements;

namespace Logestic.Domain.Placements
{
    public interface IPlacementRepository
    {
        Task<int> GetZoneCountAsync(string? search = null, bool? onlyActive = null);
        Task<Zone?> GetZoneByIdAsync(int id);
        Task<Zone> InsertZoneAsync(Zone zone);
        Task<Partition?> GetPartitionByIdAsync(int id);
        Task<Partition> InsertPartitionAsync(Partition partition);
        Task<int> GetCellCountAsync(int? partitionId = null, CellState? state = null, string? search = null);
        Task<Cell?> GetCellByIdAsync(int id);
        Task<Cell?> GetCellByChassisAsync(string chassisNumber);
        Task<Cell> InsertCellAsync(Cell cell);
        Task<bool> IsCellInUseAsync(int id);
        Task<CellInOut> InsertCellInOutAsync(CellInOut cellInOut);
        Task<CellReplace> InsertCellReplaceAsync(CellReplace cellReplace);
        Task<LogesticZonePayment> InsertPaymentAsync(LogesticZonePayment payment);
        Task<ParkingService> InsertServiceAsync(ParkingService service);
    }
}