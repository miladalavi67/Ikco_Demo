using System;

namespace Logestic.Domain.Placements
{
    /// <summary>
    /// نام مستعار برای LogesticZonePayment — برای سازگاری با کد موجود.
    /// </summary>
    public class ParkingService : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
