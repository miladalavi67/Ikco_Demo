using System;

namespace Logestic.Domain.Placements
{
    /// <summary>
    /// ورود و خروج خودرو به/از سلول - سابقه جابجایی خودرو در سلول
    /// </summary>
    public class Cell : FullAuditedEntity<int>
    {
        public int ZoneId { get; set; }
        public int? PartitionId { get; set; }
        public string CellName { get; set; }
        public string? Code { get; set; }
        public int Capacity { get; set; }
        public int Occupied { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// جایگزینی خودرو در سلول - انتقال خودرو بین سلول‌ها
    /// </summary>
    public class CellInOut : FullAuditedEntity<int>
    {
        public int CellId { get; set; }
        public int CarLogId { get; set; }
        public DateTime InDate { get; set; }
        public DateTime? OutDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// تاریخچه سلول - سوابق جایگذاری خودروها در سلول‌ها
    /// </summary>
    public class CellReplace : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int FromCellId { get; set; }
        public int ToCellId { get; set; }
        public DateTime ReplaceDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// پرداخت منطقه لجستیک - پرداخت‌های مربوط به مناطق لجستیک
    /// </summary>
    public class HistoryCell : FullAuditedEntity<int>
    {
        public int CellId { get; set; }
        public int CarLogId { get; set; }
        public DateTime ActionDate { get; set; }
        public string? ActionType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// پارتیشن - بخش‌بندی داخلی منطقه لجستیک
    /// </summary>
    public class LogesticZonePayment : FullAuditedEntity<int>
    {
        public int ZoneId { get; set; }
        public int CarLogId { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// منطقه لجستیک - منطقه اصلی لجستیک شامل سلول‌ها و پارتیشن‌ها
    /// </summary>
    public class Partition : FullAuditedEntity<int>
    {
        public int ZoneId { get; set; }
        public string PartitionName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    public class Zone : FullAuditedEntity<int>
    {
        public string ZoneName { get; set; }
        public string? Code { get; set; }
        public int? AgencyId { get; set; }
        public bool IsActive { get; set; }
    }

}