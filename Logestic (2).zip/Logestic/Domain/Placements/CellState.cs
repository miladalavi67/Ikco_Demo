namespace Logestic.Domain.Placements
{
    public enum CellState
    {
        Empty,
        Occupied,
        Reserved,
        Inactive,
    }
}
