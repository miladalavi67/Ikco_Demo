using System;

namespace Logestic.Domain.Pelaks
{
    /// <summary>
    /// نام مستعار برای PelakPlaceStock — برای سازگاری با کد موجود.
    /// </summary>
    public class PelakPlace : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
