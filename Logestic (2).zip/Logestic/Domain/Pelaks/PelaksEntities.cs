using System;

namespace Logestic.Domain.Pelaks
{
    /// <summary>
    /// وضعیت جایگذاری پلاک - وضعیت فعلی پلاک خودرو
    /// </summary>
    public class PelakPlaceLog : FullAuditedEntity<int>
    {
        public int CarLogId { get; set; }
        public int PelakPlaceStateId { get; set; }
        public int? PelakPlaceStockId { get; set; }
        public DateTime ActionDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// انبار پلاک - موجودی و محل نگهداری پلاک‌ها
    /// </summary>
    public class PelakPlaceState : FullAuditedEntity<int>
    {
        public string StateName { get; set; }
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// دسترسی کاربر به انبار پلاک - سطح دسترسی کاربران به انبارهای پلاک
    /// </summary>
    public class PelakPlaceStock : FullAuditedEntity<int>
    {
        public string StockName { get; set; }
        public string? Code { get; set; }
        public int? AgencyId { get; set; }
        public bool IsActive { get; set; }
    }

    public class PelakStockUserAccess : FullAuditedEntity<int>
    {
        public int UserId { get; set; }
        public int PelakPlaceStockId { get; set; }
        public bool HasAccess { get; set; }
    }

}