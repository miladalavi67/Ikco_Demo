using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain;
using Logestic.Domain.Pelaks;

namespace Logestic.Domain.Pelaks
{
    public interface IPelakRepository
    {
        Task<int> GetPlaceCountAsync(string? search = null, bool? onlyActive = null);
        Task<PelakPlace?> GetPlaceByIdAsync(int id);
        Task<PelakPlace> InsertPlaceAsync(PelakPlace place);
        Task<bool> IsPlaceInUseAsync(int id);
        Task<PelakPlaceStock?> GetStockByIdAsync(int id);
        Task<PelakPlaceStock?> GetStockByPlateAsync(string plateNumber);
        Task<PelakPlaceStock> InsertStockAsync(PelakPlaceStock stock);
        Task<bool> HasDuplicatePlateAsync(string plateNumber, int? excludeId = null);
        Task<PelakPlaceLog> InsertLogAsync(PelakPlaceLog log);
        Task<PelakPlaceState?> GetStateByPlaceAsync(int placeId);
        Task<PelakPlaceState> UpdateStateAsync(PelakPlaceState state);
        Task<bool> HasUserAccessAsync(int userId, int placeId);
        Task<CarNumberingFault> InsertFaultAsync(CarNumberingFault fault);
    }
}