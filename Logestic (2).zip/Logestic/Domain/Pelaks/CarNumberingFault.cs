using System;

namespace Logestic.Domain.Pelaks
{
    /// <summary>
    /// نام مستعار برای PelakPlaceLog — برای سازگاری با کد موجود.
    /// </summary>
    public class CarNumberingFault : FullAuditedEntity<int>
    {
        public int RefId { get; set; }
    }
}
