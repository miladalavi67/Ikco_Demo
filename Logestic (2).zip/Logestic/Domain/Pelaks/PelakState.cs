namespace Logestic.Domain.Pelaks
{
    public enum PelakState
    {
        Available,
        Assigned,
        Returned,
        Lost,
    }
}
