namespace Logestic.Domain.Parts
{
    /// <summary>
    /// منطق دامنه برای حذف قطعه. حذف قطعه‌ای که در درخواست‌ها استفاده شده، مجاز نیست.
    /// </summary>
    public class PartManager
    {
        // بررسی می‌کند که آیا قطعه‌ای قابل حذف است یا در درخواست‌های سرویس استفاده شده است.
        public void CheckCanDelete(bool isInUse)
        {
            if (isInUse)
                throw new AfterSalesException(AfterSalesErrorCodes.PartInUse);
        }
    }
}
