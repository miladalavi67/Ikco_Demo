using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Logestic.Domain.Parts;

namespace Logestic.Domain.Parts
{
    public interface IPartRepository
    {
        Task<int> GetCountAsync(string? search = null, bool? onlyLowStock = null);
        Task<Part?> GetByIdAsync(int id);
        Task<Part> InsertAsync(Part part);
        Task UpdateAsync(Part part);
        Task DeleteAsync(int id);
        Task<List<Part>> GetActiveLookupAsync();
        Task<List<Part>> GetListAsync(string? search = null, bool? onlyLowStock = null, int skip = 0, int take = 20);
    }
}