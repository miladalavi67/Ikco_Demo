using System;

namespace Logestic.Domain.Parts
{
    public class Part : FullAuditedEntity<int>
    {
        public string PartCode { get; set; } = string.Empty;
        public string PartName { get; set; } = string.Empty;
        public decimal UnitPrice { get; set; }
        public int StockQty { get; set; }
        public int MinStockQty { get; set; }
        public bool IsActive { get; set; }

        public bool IsLowStock => StockQty <= MinStockQty;

        /// <summary>
        /// مصرف موجودی انبار. تعداد نامعتبر یا بیشتر از موجودی مجاز نیست.
        /// </summary>
        public void ConsumeStock(int quantity)
        {
            // اعتبارسنجی تعداد ورودی
            if (quantity <= 0)
                throw new AfterSalesException(
                    AfterSalesErrorCodes.InvalidQuantity,
                    "تعداد باید بزرگ‌تر از صفر باشد");

            // بررسی کفایت موجودی انبار
            if (StockQty < quantity)
                throw new AfterSalesException(
                    AfterSalesErrorCodes.InsufficientStock,
                    "موجودی انبار کافی نیست");

            // کسر از موجودی
            StockQty -= quantity;
        }

        /// <summary>
        /// بازگرداندن موجودی به انبار (مثلاً پس از حذف ردیف یا درخواست).
        /// </summary>
        public void ReturnStock(int quantity)
        {
            // فقط مقدار مثبت معتبر است
            if (quantity <= 0)
                throw new AfterSalesException(
                    AfterSalesErrorCodes.InvalidQuantity,
                    "تعداد باید بزرگ‌تر از صفر باشد");

            // اضافه کردن به موجودی
            StockQty += quantity;
        }
    }
}
