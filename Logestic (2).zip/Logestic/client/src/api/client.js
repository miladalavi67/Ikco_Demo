const API_BASE = '/api'

async function request(path, options = {}) {
  const url = `${API_BASE}${path}`
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })
  if (!response.ok) {
    const text = await response.text()
    throw new Error(text || response.statusText)
  }
  return response.status === 204 ? null : response.json()
}

//通用 CRUD factory
export function crud(endpoint) {
  return {
    list: (params = {}) => {
      const qs = new URLSearchParams(
        Object.entries(params).filter(([, v]) => v != null && v !== '')
      ).toString()
      return request(`/${endpoint}${qs ? '?' + qs : ''}`)
    },
    get: (id) => request(`/${endpoint}/${id}`),
    create: (data) => request(`/${endpoint}`, { method: 'POST', body: JSON.stringify(data) }),
    update: (id, data) => request(`/${endpoint}/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    remove: (id) => request(`/${endpoint}/${id}`, { method: 'DELETE' }),
  }
}

//各模块
export const gates = crud('gate')
export const placements = crud('placement')
export const pelaks = crud('pelak')
export const pdis = crud('pdi')
export const faults = crud('fault')
export const audits = crud('audit')
export const baseInfo = crud('baseinfo')
export const repairs = crud('repair')
export const receipts = crud('receipt')
export const registerRequests = crud('registerrequest')
export const relapseGateBuffers = crud('relapsegatebuffer')
export const deliveries = crud('delivery')
export const sales = crud('sale')
export const transitions = crud('transition')
export const users = crud('user')
export const agencies = crud('agency')
export const reports = crud('report')
export const customers = crud('customer')
export const parts = crud('part')
export const vehicles = crud('vehicle')
export const technicians = crud('technician')
export const serviceRequests = crud('servicerequest')
