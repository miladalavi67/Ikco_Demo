import { useState, useEffect } from 'react'

export default function GenericList({ module }) {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const [total, setTotal] = useState(0)
  const [searchTimeout, setSearchTimeout] = useState(null)
  const pageSize = 20

  useEffect(() => {
    loadData()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page])

  useEffect(() => {
    if (searchTimeout) clearTimeout(searchTimeout)
    const t = setTimeout(() => {
      setPage(0)
      loadData()
    }, 500)
    setSearchTimeout(t)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  async function loadData() {
    setLoading(true)
    setError(null)
    try {
      const params = search ? { search } : {}
      const result = await module.crud.list(params)
      if (Array.isArray(result)) {
        setData(result)
        setTotal(result.length)
      } else if (result && result.items) {
        setData(result.items)
        setTotal(result.total || result.items.length)
      } else {
        setData([])
        setTotal(0)
      }
    } catch (err) {
      setError(err.message || 'خطا در ارتباط با سرور')
      setData([])
      setTotal(0)
    } finally {
      setLoading(false)
    }
  }

  async function handleDelete(id) {
    if (!confirm('آیا از حذف مطمئن هستید؟')) return
    try {
      await module.crud.remove(id)
      await loadData()
    } catch (err) {
      alert('خطا در حذف: ' + err.message)
    }
  }

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div>
      <div className="page-header">
        <h2 className="page-title">{module.icon} {module.label}</h2>
      </div>

      <div className="toolbar">
        <input
          type="text"
          className="search-box"
          placeholder="جستجو..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button className="btn btn-primary" onClick={() => loadData()}>
          🔄 بازخوانی
        </button>
      </div>

      {error && (
        <div className="alert alert-error">
          ⚠️ {error}
          <div style={{ marginTop: 8, fontSize: 12, color: '#64748b' }}>
            آیا Backend روی پورت 5000 اجرا شده؟
          </div>
        </div>
      )}

      {loading ? (
        <div className="loading">در حال بارگذاری...</div>
      ) : data.length === 0 ? (
        <div className="empty-state">
          <p style={{ fontSize: 18 }}>📭 داده‌ای یافت نشد</p>
          <p style={{ fontSize: 13, color: '#64748b', marginTop: 8 }}>
            جدول خالی است یا API در دسترس نیست
          </p>
        </div>
      ) : (
        <>
          <table className="table">
            <thead>
              <tr>
                <th>#</th>
                {Object.keys(data[0] || {}).slice(0, 6).map(key => (
                  <th key={key}>{key}</th>
                ))}
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              {data.map((row, idx) => (
                <tr key={row.id || idx}>
                  <td>{idx + 1 + page * pageSize}</td>
                  {Object.values(row).slice(0, 6).map((val, i) => (
                    <td key={i}>
                      {typeof val === 'boolean'
                        ? (val ? '✓' : '✗')
                        : val == null
                          ? '—'
                          : typeof val === 'object'
                            ? JSON.stringify(val).slice(0, 30)
                            : String(val).slice(0, 50)}
                    </td>
                  ))}
                  <td>
                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(row.id)}>
                      🗑
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {totalPages > 1 && (
            <div className="pagination">
              {Array.from({ length: totalPages }, (_, i) => (
                <button
                  key={i}
                  className={i === page ? 'active' : ''}
                  onClick={() => setPage(i)}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}
