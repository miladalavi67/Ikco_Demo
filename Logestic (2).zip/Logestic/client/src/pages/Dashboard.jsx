import { Link } from 'react-router-dom'

export default function Dashboard({ modules }) {
  return (
    <div>
      <h2 className="page-title">داشبورد</h2>
      <p className="page-desc">سامانه مدیریت لجستیک و PDI ایران‌خودرو — {modules.length} ماژول</p>

      <div className="card-grid">
        {modules.map(m => (
          <Link key={m.key} to={`/${m.key}`} className="module-card">
            <div className="module-icon">{m.icon}</div>
            <div className="module-label">{m.label}</div>
          </Link>
        ))}
      </div>
    </div>
  )
}
