import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import GenericList from './pages/GenericList'
import * as api from './api/client'

// ماژول‌های سامانه لجستیک
const modules = [
  { key: 'gate', label: 'گیت', icon: '🚪', crud: api.gates },
  { key: 'placement', label: 'جانمایی و پارکینگ', icon: '🅿️', crud: api.placements },
  { key: 'pelak', label: 'پلاک', icon: '🏷️', crud: api.pelaks },
  { key: 'pdi', label: 'کنترل کیفیت', icon: '✅', crud: api.pdis },
  { key: 'fault', label: 'خرابی', icon: '⚠️', crud: api.faults },
  { key: 'audit', label: 'حسابرسی', icon: '📋', crud: api.audits },
  { key: 'baseinfo', label: 'اطلاعات پایه', icon: '📊', crud: api.baseInfo },
  { key: 'repair', label: 'تعمیر', icon: '🔧', crud: api.repairs },
  { key: 'receipt', label: 'رسید', icon: '🧾', crud: api.receipts },
  { key: 'registerrequest', label: 'درخواست ثبت', icon: '📝', crud: api.registerRequests },
  { key: 'relapsegatebuffer', label: 'بافر عودت', icon: '↩️', crud: api.relapseGateBuffers },
  { key: 'delivery', label: 'تحویل', icon: '🚚', crud: api.deliveries },
  { key: 'sale', label: 'فروش', icon: '💰', crud: api.sales },
  { key: 'transition', label: 'جریان', icon: '🔄', crud: api.transitions },
  { key: 'user', label: 'کاربران', icon: '👥', crud: api.users },
  { key: 'agency', label: 'آژانس', icon: '🏢', crud: api.agencies },
  { key: 'report', label: 'گزارش‌ها', icon: '📈', crud: api.reports },
  { key: 'customer', label: 'مشتریان', icon: '🧑', crud: api.customers },
  { key: 'part', label: 'قطعات', icon: '⚙️', crud: api.parts },
  { key: 'vehicle', label: 'خودروها', icon: '🚗', crud: api.vehicles },
  { key: 'technician', label: 'تعمیرکاران', icon: '👨‍🔧', crud: api.technicians },
  { key: 'servicerequest', label: 'درخواست سرویس', icon: '🎫', crud: api.serviceRequests },
]

function App() {
  return (
    <BrowserRouter>
      <Layout modules={modules}>
        <Routes>
          <Route path="/" element={<Dashboard modules={modules} />} />
          {modules.map(m => (
            <Route
              key={m.key}
              path={`/${m.key}`}
              element={<GenericList module={m} />}
            />
          ))}
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}

export default App
