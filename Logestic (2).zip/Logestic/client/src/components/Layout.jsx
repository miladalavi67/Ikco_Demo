import { Outlet, Link, useLocation, useState } from 'react-router-dom'

export default function Layout({ modules, children }) {
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  return (
    <div className="app">
      {/* هدر */}
      <header className="header">
        <div className="header-inner">
          <button className="menu-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
            ☰
          </button>
          <h1 className="logo">🚗 سامانه لجستیک ایران‌خودرو</h1>
          <div className="header-actions">
            <span className="user-badge">کاربر</span>
          </div>
        </div>
      </header>

      <div className="body">
        {/* نوار کناری */}
        {sidebarOpen && (
          <aside className="sidebar">
            <nav className="sidebar-nav">
              <Link to="/" className={`sidebar-link ${location.pathname === '/' ? 'active' : ''}`}>
                🏠 داشبورد
              </Link>
              <div className="sidebar-section">ماژول‌ها</div>
              {modules.map(m => (
                <Link
                  key={m.key}
                  to={`/${m.key}`}
                  className={`sidebar-link ${location.pathname === `/${m.key}` ? 'active' : ''}`}
                >
                  {m.icon} {m.label}
                </Link>
              ))}
            </nav>
          </aside>
        )}

        {/* محتوا */}
        <main className="main">
          <div className="content">
            {children || <Outlet />}
          </div>
        </main>
      </div>
    </div>
  )
}
