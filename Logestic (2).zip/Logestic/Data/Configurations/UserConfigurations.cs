using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class UserConfiguration : IEntityTypeConfiguration<UserEntity>
    {
        public void Configure(EntityTypeBuilder<UserEntity> builder)
        {
            builder.ToTable("User");
            builder.HasKey(u => u.Id);
            builder.Property(u => u.UserName).IsRequired().HasMaxLength(100);
            builder.Property(u => u.FullName).IsRequired().HasMaxLength(200);
            builder.Property(u => u.NationalCode).HasMaxLength(15);
            builder.Property(u => u.Mobile).HasMaxLength(20);
            builder.Property(u => u.Email).HasMaxLength(100);
            builder.Property(u => u.IsActive).IsRequired();
            builder.Property(u => u.LastLoginDate).HasColumnType("datetime");
        }
    }
}
