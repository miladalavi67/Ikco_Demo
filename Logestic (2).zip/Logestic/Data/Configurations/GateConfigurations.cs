using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class EnterGateConfiguration : IEntityTypeConfiguration<EnterGateEntity>
    {
        public void Configure(EntityTypeBuilder<EnterGateEntity> builder)
        {
            builder.ToTable("EnterGate");
            builder.HasKey(e => e.Id);
            builder.Property(e => e.DriverName).HasMaxLength(200);
            builder.Property(e => e.Pelak).HasMaxLength(50);
            builder.Property(e => e.Description).HasMaxLength(2000);
            builder.Property(e => e.EnterDate).HasColumnType("datetime");
        }
    }

    public class ExitGateConfiguration : IEntityTypeConfiguration<ExitGateEntity>
    {
        public void Configure(EntityTypeBuilder<ExitGateEntity> builder)
        {
            builder.ToTable("ExitGate");
            builder.HasKey(e => e.Id);
            builder.Property(e => e.DriverName).HasMaxLength(200);
            builder.Property(e => e.Pelak).HasMaxLength(50);
            builder.Property(e => e.Description).HasMaxLength(2000);
            builder.Property(e => e.ExitDate).HasColumnType("datetime");
        }
    }

    public class RelapseGateOperationConfiguration : IEntityTypeConfiguration<RelapseGateOperationEntity>
    {
        public void Configure(EntityTypeBuilder<RelapseGateOperationEntity> builder)
        {
            builder.ToTable("RelapseGateOperation");
            builder.HasKey(e => e.Id);
            builder.Property(e => e.Reason).HasMaxLength(500);
            builder.Property(e => e.Description).HasMaxLength(2000);
            builder.Property(e => e.RelapseDate).HasColumnType("datetime");
        }
    }
}
