using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class ReceiptConfiguration : IEntityTypeConfiguration<ReceiptEntity>
    {
        public void Configure(EntityTypeBuilder<ReceiptEntity> builder)
        {
            builder.ToTable("Receipt");
            builder.HasKey(r => r.Id);
            builder.Property(r => r.ReceiptNo).IsRequired().HasMaxLength(50);
            builder.Property(r => r.ReceiptDate).HasColumnType("datetime");
            builder.Property(r => r.ReceiptType).HasMaxLength(200);
            builder.Property(r => r.Description).HasMaxLength(2000);
            builder.Property(r => r.IsActive).IsRequired();
        }
    }

    public class ReceiptDetailConfiguration : IEntityTypeConfiguration<ReceiptDetailEntity>
    {
        public void Configure(EntityTypeBuilder<ReceiptDetailEntity> builder)
        {
            builder.ToTable("ReceiptDetail");
            builder.HasKey(r => r.Id);
            builder.Property(r => r.ItemName).IsRequired().HasMaxLength(200);
            builder.Property(r => r.Quantity).IsRequired();
            builder.Property(r => r.UnitPrice).HasColumnType("decimal(18,2)");
            builder.Property(r => r.TotalPrice).HasColumnType("decimal(18,2)");
            builder.Property(r => r.Description).HasMaxLength(2000);
        }
    }
}
