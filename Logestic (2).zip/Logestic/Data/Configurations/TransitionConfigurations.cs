using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class FlowConfiguration : IEntityTypeConfiguration<FlowEntity>
    {
        public void Configure(EntityTypeBuilder<FlowEntity> builder)
        {
            builder.ToTable("Flow");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.FlowName).IsRequired().HasMaxLength(200);
            builder.Property(f => f.Code).HasMaxLength(50);
            builder.Property(f => f.IsActive).IsRequired();
        }
    }

    public class FlowTypeTransitionConfiguration : IEntityTypeConfiguration<FlowTypeTransitionEntity>
    {
        public void Configure(EntityTypeBuilder<FlowTypeTransitionEntity> builder)
        {
            builder.ToTable("FlowTypeTransition");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.IsActive).IsRequired();
        }
    }

    public class StepConfiguration : IEntityTypeConfiguration<StepEntity>
    {
        public void Configure(EntityTypeBuilder<StepEntity> builder)
        {
            builder.ToTable("Step");
            builder.HasKey(s => s.Id);
            builder.Property(s => s.StepName).IsRequired().HasMaxLength(200);
            builder.Property(s => s.Code).HasMaxLength(50);
            builder.Property(s => s.OrderNo).IsRequired();
            builder.Property(s => s.IsFinal).IsRequired();
            builder.Property(s => s.IsActive).IsRequired();
        }
    }

    public class TransitionConfiguration : IEntityTypeConfiguration<TransitionEntity>
    {
        public void Configure(EntityTypeBuilder<TransitionEntity> builder)
        {
            builder.ToTable("Transition");
            builder.HasKey(t => t.Id);
            builder.Property(t => t.TransitionName).HasMaxLength(200);
            builder.Property(t => t.Description).HasMaxLength(2000);
            builder.Property(t => t.IsActive).IsRequired();
        }
    }

    public class UserFlowTypeConfiguration : IEntityTypeConfiguration<UserFlowTypeEntity>
    {
        public void Configure(EntityTypeBuilder<UserFlowTypeEntity> builder)
        {
            builder.ToTable("UserFlowType");
            builder.HasKey(u => u.Id);
            builder.Property(u => u.HasAccess).IsRequired();
        }
    }

    public class FlowTypeConfiguration : IEntityTypeConfiguration<FlowTypeEntity>
    {
        public void Configure(EntityTypeBuilder<FlowTypeEntity> builder)
        {
            builder.ToTable("FlowType");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.TypeName).IsRequired().HasMaxLength(200);
            builder.Property(f => f.Code).HasMaxLength(50);
            builder.Property(f => f.IsActive).IsRequired();
        }
    }
}
