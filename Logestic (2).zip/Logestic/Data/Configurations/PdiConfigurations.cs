using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class PdiConfiguration : IEntityTypeConfiguration<PdiEntity>
    {
        public void Configure(EntityTypeBuilder<PdiEntity> builder)
        {
            builder.ToTable("Pdi");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.PdiDate).HasColumnType("datetime");
            builder.Property(p => p.Description).HasMaxLength(2000);
            builder.Property(p => p.IsPassed).IsRequired();
        }
    }

    public class PdiDetailConfiguration : IEntityTypeConfiguration<PdiDetailEntity>
    {
        public void Configure(EntityTypeBuilder<PdiDetailEntity> builder)
        {
            builder.ToTable("PdiDetail");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.CheckItem).IsRequired().HasMaxLength(200);
            builder.Property(p => p.IsOk).IsRequired();
            builder.Property(p => p.Description).HasMaxLength(2000);
        }
    }
}
