using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class RepairConfiguration : IEntityTypeConfiguration<RepairEntity>
    {
        public void Configure(EntityTypeBuilder<RepairEntity> builder)
        {
            builder.ToTable("Repair");
            builder.HasKey(r => r.Id);
            builder.Property(r => r.RepairDate).HasColumnType("datetime");
            builder.Property(r => r.RepairType).HasMaxLength(200);
            builder.Property(r => r.Description).HasMaxLength(2000);
            builder.Property(r => r.Cost).HasColumnType("decimal(18,2)");
            builder.Property(r => r.IsCompleted).IsRequired();
        }
    }

    public class RepairDetailConfiguration : IEntityTypeConfiguration<RepairDetailEntity>
    {
        public void Configure(EntityTypeBuilder<RepairDetailEntity> builder)
        {
            builder.ToTable("RepairDetail");
            builder.HasKey(r => r.Id);
            builder.Property(r => r.PartCode).HasMaxLength(50);
            builder.Property(r => r.PartName).HasMaxLength(200);
            builder.Property(r => r.Quantity).IsRequired();
            builder.Property(r => r.UnitPrice).HasColumnType("decimal(18,2)");
            builder.Property(r => r.Description).HasMaxLength(2000);
        }
    }
}
