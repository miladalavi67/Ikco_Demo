using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class CarTypeConfiguration : IEntityTypeConfiguration<CarTypeEntity>
    {
        public void Configure(EntityTypeBuilder<CarTypeEntity> builder)
        {
            builder.ToTable("CarType");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.TypeName).IsRequired().HasMaxLength(200);
            builder.Property(c => c.Code).HasMaxLength(50);
            builder.Property(c => c.IsActive).IsRequired();
        }
    }

    public class DriverConfiguration : IEntityTypeConfiguration<DriverEntity>
    {
        public void Configure(EntityTypeBuilder<DriverEntity> builder)
        {
            builder.ToTable("Driver");
            builder.HasKey(d => d.Id);
            builder.Property(d => d.FullName).IsRequired().HasMaxLength(200);
            builder.Property(d => d.NationalCode).HasMaxLength(15);
            builder.Property(d => d.Mobile).HasMaxLength(20);
            builder.Property(d => d.IsActive).IsRequired();
        }
    }

    public class DriverJobConfiguration : IEntityTypeConfiguration<DriverJobEntity>
    {
        public void Configure(EntityTypeBuilder<DriverJobEntity> builder)
        {
            builder.ToTable("DriverJob");
            builder.HasKey(d => d.Id);
            builder.Property(d => d.JobName).IsRequired().HasMaxLength(200);
            builder.Property(d => d.Code).HasMaxLength(50);
            builder.Property(d => d.IsActive).IsRequired();
        }
    }

    public class DriverStepAccessConfiguration : IEntityTypeConfiguration<DriverStepAccessEntity>
    {
        public void Configure(EntityTypeBuilder<DriverStepAccessEntity> builder)
        {
            builder.ToTable("DriverStepAccess");
            builder.HasKey(d => d.Id);
            builder.Property(d => d.HasAccess).IsRequired();
        }
    }

    public class UserFlowAccessConfiguration : IEntityTypeConfiguration<UserFlowAccessEntity>
    {
        public void Configure(EntityTypeBuilder<UserFlowAccessEntity> builder)
        {
            builder.ToTable("UserFlowAccess");
            builder.HasKey(u => u.Id);
            builder.Property(u => u.HasAccess).IsRequired();
        }
    }

    public class UserZoneAccessConfiguration : IEntityTypeConfiguration<UserZoneAccessEntity>
    {
        public void Configure(EntityTypeBuilder<UserZoneAccessEntity> builder)
        {
            builder.ToTable("UserZoneAccess");
            builder.HasKey(u => u.Id);
            builder.Property(u => u.HasAccess).IsRequired();
        }
    }

    public class BodyStateConfiguration : IEntityTypeConfiguration<BodyStateEntity>
    {
        public void Configure(EntityTypeBuilder<BodyStateEntity> builder)
        {
            builder.ToTable("BodyState");
            builder.HasKey(b => b.Id);
            builder.Property(b => b.StateName).IsRequired().HasMaxLength(200);
            builder.Property(b => b.Code).HasMaxLength(50);
            builder.Property(b => b.IsActive).IsRequired();
        }
    }

    public class TCarProdConfiguration : IEntityTypeConfiguration<TCarProdEntity>
    {
        public void Configure(EntityTypeBuilder<TCarProdEntity> builder)
        {
            builder.ToTable("TCarProd");
            builder.HasKey(t => t.Id);
            builder.Property(t => t.ProdCode).IsRequired().HasMaxLength(50);
            builder.Property(t => t.ProdName).IsRequired().HasMaxLength(200);
            builder.Property(t => t.ProdDate).HasColumnType("datetime");
            builder.Property(t => t.IsActive).IsRequired();
        }
    }

    public class OpcoOptionConfiguration : IEntityTypeConfiguration<OpcoOptionEntity>
    {
        public void Configure(EntityTypeBuilder<OpcoOptionEntity> builder)
        {
            builder.ToTable("OpcoOption");
            builder.HasKey(o => o.Id);
            builder.Property(o => o.OptionName).IsRequired().HasMaxLength(200);
            builder.Property(o => o.OptionValue).HasMaxLength(1000);
            builder.Property(o => o.Description).HasMaxLength(2000);
            builder.Property(o => o.IsActive).IsRequired();
        }
    }
}
