using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class CellConfiguration : IEntityTypeConfiguration<CellEntity>
    {
        public void Configure(EntityTypeBuilder<CellEntity> builder)
        {
            builder.ToTable("Cell");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.CellName).IsRequired().HasMaxLength(200);
            builder.Property(c => c.Code).HasMaxLength(50);
            builder.Property(c => c.Capacity).IsRequired();
            builder.Property(c => c.Occupied).IsRequired();
            builder.Property(c => c.IsActive).IsRequired();
        }
    }

    public class CellInOutConfiguration : IEntityTypeConfiguration<CellInOutEntity>
    {
        public void Configure(EntityTypeBuilder<CellInOutEntity> builder)
        {
            builder.ToTable("CellInOut");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.InDate).HasColumnType("datetime");
            builder.Property(c => c.OutDate).HasColumnType("datetime");
            builder.Property(c => c.Description).HasMaxLength(2000);
        }
    }

    public class CellReplaceConfiguration : IEntityTypeConfiguration<CellReplaceEntity>
    {
        public void Configure(EntityTypeBuilder<CellReplaceEntity> builder)
        {
            builder.ToTable("CellReplace");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.ReplaceDate).HasColumnType("datetime");
            builder.Property(c => c.Description).HasMaxLength(2000);
        }
    }

    public class HistoryCellConfiguration : IEntityTypeConfiguration<HistoryCellEntity>
    {
        public void Configure(EntityTypeBuilder<HistoryCellEntity> builder)
        {
            builder.ToTable("HistoryCell");
            builder.HasKey(h => h.Id);
            builder.Property(h => h.ActionDate).HasColumnType("datetime");
            builder.Property(h => h.ActionType).HasMaxLength(50);
            builder.Property(h => h.Description).HasMaxLength(2000);
        }
    }

    public class LogesticZonePaymentConfiguration : IEntityTypeConfiguration<LogesticZonePaymentEntity>
    {
        public void Configure(EntityTypeBuilder<LogesticZonePaymentEntity> builder)
        {
            builder.ToTable("LogesticZonePayment");
            builder.HasKey(l => l.Id);
            builder.Property(l => l.PaymentDate).HasColumnType("datetime");
            builder.Property(l => l.Amount).HasColumnType("decimal(18,2)");
            builder.Property(l => l.Description).HasMaxLength(2000);
        }
    }

    public class PartitionConfiguration : IEntityTypeConfiguration<PartitionEntity>
    {
        public void Configure(EntityTypeBuilder<PartitionEntity> builder)
        {
            builder.ToTable("Partition");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.PartitionName).IsRequired().HasMaxLength(200);
            builder.Property(p => p.Code).HasMaxLength(50);
            builder.Property(p => p.IsActive).IsRequired();
        }
    }

    public class ZoneConfiguration : IEntityTypeConfiguration<ZoneEntity>
    {
        public void Configure(EntityTypeBuilder<ZoneEntity> builder)
        {
            builder.ToTable("Zone");
            builder.HasKey(z => z.Id);
            builder.Property(z => z.ZoneName).IsRequired().HasMaxLength(200);
            builder.Property(z => z.Code).HasMaxLength(50);
            builder.Property(z => z.IsActive).IsRequired();
        }
    }
}
