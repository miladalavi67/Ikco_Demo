using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class RelapseBufferOperationConfiguration : IEntityTypeConfiguration<RelapseBufferOperationEntity>
    {
        public void Configure(EntityTypeBuilder<RelapseBufferOperationEntity> builder)
        {
            builder.ToTable("RelapseBufferOperation");
            builder.HasKey(r => r.Id);
            builder.Property(r => r.OperationDate).HasColumnType("datetime");
            builder.Property(r => r.OperationType).HasMaxLength(200);
            builder.Property(r => r.Reason).HasMaxLength(500);
            builder.Property(r => r.Description).HasMaxLength(2000);
            builder.Property(r => r.IsProcessed).IsRequired();
        }
    }
}
