using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class RegisterRequestConfiguration : IEntityTypeConfiguration<RegisterRequestEntity>
    {
        public void Configure(EntityTypeBuilder<RegisterRequestEntity> builder)
        {
            builder.ToTable("RegisterRequest");
            builder.HasKey(r => r.Id);
            builder.Property(r => r.RequestNo).IsRequired().HasMaxLength(50);
            builder.Property(r => r.RequestDate).HasColumnType("datetime");
            builder.Property(r => r.RequestType).HasMaxLength(200);
            builder.Property(r => r.Description).HasMaxLength(2000);
            builder.Property(r => r.IsApproved).IsRequired();
        }
    }

    public class ManagementRequestConfiguration : IEntityTypeConfiguration<ManagementRequestEntity>
    {
        public void Configure(EntityTypeBuilder<ManagementRequestEntity> builder)
        {
            builder.ToTable("ManagementRequest");
            builder.HasKey(m => m.Id);
            builder.Property(m => m.RequestNo).IsRequired().HasMaxLength(50);
            builder.Property(m => m.RequestDate).HasColumnType("datetime");
            builder.Property(m => m.RequestType).HasMaxLength(200);
            builder.Property(m => m.Description).HasMaxLength(2000);
            builder.Property(m => m.IsApproved).IsRequired();
        }
    }
}
