using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class FaultConfiguration : IEntityTypeConfiguration<FaultEntity>
    {
        public void Configure(EntityTypeBuilder<FaultEntity> builder)
        {
            builder.ToTable("Fault");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.FaultDate).HasColumnType("datetime");
            builder.Property(f => f.Description).HasMaxLength(2000);
            builder.Property(f => f.IsResolved).IsRequired();
        }
    }

    public class FaultBodyConfiguration : IEntityTypeConfiguration<FaultBodyEntity>
    {
        public void Configure(EntityTypeBuilder<FaultBodyEntity> builder)
        {
            builder.ToTable("FaultBody");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.BodyName).IsRequired().HasMaxLength(200);
            builder.Property(f => f.Code).HasMaxLength(50);
            builder.Property(f => f.IsActive).IsRequired();
        }
    }

    public class FaultDetectLevelConfiguration : IEntityTypeConfiguration<FaultDetectLevelEntity>
    {
        public void Configure(EntityTypeBuilder<FaultDetectLevelEntity> builder)
        {
            builder.ToTable("FaultDetectLevel");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.LevelName).IsRequired().HasMaxLength(200);
            builder.Property(f => f.Code).HasMaxLength(50);
            builder.Property(f => f.IsActive).IsRequired();
        }
    }

    public class FaultLevelConfiguration : IEntityTypeConfiguration<FaultLevelEntity>
    {
        public void Configure(EntityTypeBuilder<FaultLevelEntity> builder)
        {
            builder.ToTable("FaultLevel");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.LevelName).IsRequired().HasMaxLength(200);
            builder.Property(f => f.Code).HasMaxLength(50);
            builder.Property(f => f.Severity).IsRequired();
            builder.Property(f => f.IsActive).IsRequired();
        }
    }

    public class FaultPartConfiguration : IEntityTypeConfiguration<FaultPartEntity>
    {
        public void Configure(EntityTypeBuilder<FaultPartEntity> builder)
        {
            builder.ToTable("FaultPart");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.PartCode).IsRequired().HasMaxLength(50);
            builder.Property(f => f.PartName).IsRequired().HasMaxLength(200);
            builder.Property(f => f.Quantity).IsRequired();
            builder.Property(f => f.Description).HasMaxLength(2000);
        }
    }

    public class FaultSourceConfiguration : IEntityTypeConfiguration<FaultSourceEntity>
    {
        public void Configure(EntityTypeBuilder<FaultSourceEntity> builder)
        {
            builder.ToTable("FaultSource");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.SourceName).IsRequired().HasMaxLength(200);
            builder.Property(f => f.Code).HasMaxLength(50);
            builder.Property(f => f.IsActive).IsRequired();
        }
    }
}
