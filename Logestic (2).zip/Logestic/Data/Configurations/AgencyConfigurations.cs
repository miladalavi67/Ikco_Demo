using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class AgencyConfiguration : IEntityTypeConfiguration<AgencyEntity>
    {
        public void Configure(EntityTypeBuilder<AgencyEntity> builder)
        {
            builder.ToTable("Agency");
            builder.HasKey(a => a.Id);
            builder.Property(a => a.AgencyName).IsRequired().HasMaxLength(200);
            builder.Property(a => a.Code).HasMaxLength(50);
            builder.Property(a => a.Address).HasMaxLength(500);
            builder.Property(a => a.Phone).HasMaxLength(20);
            builder.Property(a => a.IsActive).IsRequired();
        }
    }

    public class TCarAgencyConfiguration : IEntityTypeConfiguration<TCarAgencyEntity>
    {
        public void Configure(EntityTypeBuilder<TCarAgencyEntity> builder)
        {
            builder.ToTable("TCarAgency");
            builder.HasKey(a => a.Id);
            builder.Property(a => a.AgencyCode).IsRequired().HasMaxLength(50);
            builder.Property(a => a.AgencyName).IsRequired().HasMaxLength(200);
            builder.Property(a => a.Address).HasMaxLength(500);
            builder.Property(a => a.Phone).HasMaxLength(20);
            builder.Property(a => a.IsActive).IsRequired();
        }
    }

    public class TehranAgencyLocationConfiguration : IEntityTypeConfiguration<TehranAgencyLocationEntity>
    {
        public void Configure(EntityTypeBuilder<TehranAgencyLocationEntity> builder)
        {
            builder.ToTable("TehranAgencyLocation");
            builder.HasKey(t => t.Id);
            builder.Property(t => t.LocationName).IsRequired().HasMaxLength(200);
            builder.Property(t => t.Code).HasMaxLength(50);
            builder.Property(t => t.Address).HasMaxLength(500);
            builder.Property(t => t.Latitude).HasColumnType("decimal(18,6)");
            builder.Property(t => t.Longitude).HasColumnType("decimal(18,6)");
            builder.Property(t => t.IsActive).IsRequired();
        }
    }
}
