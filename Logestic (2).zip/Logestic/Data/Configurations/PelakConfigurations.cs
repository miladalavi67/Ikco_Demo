using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class PelakPlaceLogConfiguration : IEntityTypeConfiguration<PelakPlaceLogEntity>
    {
        public void Configure(EntityTypeBuilder<PelakPlaceLogEntity> builder)
        {
            builder.ToTable("PelakPlaceLog");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.ActionDate).HasColumnType("datetime");
            builder.Property(p => p.Description).HasMaxLength(2000);
        }
    }

    public class PelakPlaceStateConfiguration : IEntityTypeConfiguration<PelakPlaceStateEntity>
    {
        public void Configure(EntityTypeBuilder<PelakPlaceStateEntity> builder)
        {
            builder.ToTable("PelakPlaceState");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.StateName).IsRequired().HasMaxLength(200);
            builder.Property(p => p.Code).HasMaxLength(50);
            builder.Property(p => p.IsActive).IsRequired();
        }
    }

    public class PelakPlaceStockConfiguration : IEntityTypeConfiguration<PelakPlaceStockEntity>
    {
        public void Configure(EntityTypeBuilder<PelakPlaceStockEntity> builder)
        {
            builder.ToTable("PelakPlaceStock");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.StockName).IsRequired().HasMaxLength(200);
            builder.Property(p => p.Code).HasMaxLength(50);
            builder.Property(p => p.IsActive).IsRequired();
        }
    }

    public class PelakStockUserAccessConfiguration : IEntityTypeConfiguration<PelakStockUserAccessEntity>
    {
        public void Configure(EntityTypeBuilder<PelakStockUserAccessEntity> builder)
        {
            builder.ToTable("PelakStockUserAccess");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.HasAccess).IsRequired();
        }
    }
}
