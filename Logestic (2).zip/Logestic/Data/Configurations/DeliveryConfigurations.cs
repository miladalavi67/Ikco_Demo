using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class BatchBodyViewConfiguration : IEntityTypeConfiguration<BatchBodyViewEntity>
    {
        public void Configure(EntityTypeBuilder<BatchBodyViewEntity> builder)
        {
            builder.ToTable("BatchBodyView");
            builder.HasKey(b => b.Id);
            builder.Property(b => b.BodyNo).HasMaxLength(50);
            builder.Property(b => b.Description).HasMaxLength(2000);
        }
    }

    public class BijakConfiguration : IEntityTypeConfiguration<BijakEntity>
    {
        public void Configure(EntityTypeBuilder<BijakEntity> builder)
        {
            builder.ToTable("Bijak");
            builder.HasKey(b => b.Id);
            builder.Property(b => b.BijakNo).IsRequired().HasMaxLength(50);
            builder.Property(b => b.BijakDate).HasColumnType("datetime");
            builder.Property(b => b.Description).HasMaxLength(2000);
        }
    }

    public class DeliveryRowNoBodyConfiguration : IEntityTypeConfiguration<DeliveryRowNoBodyEntity>
    {
        public void Configure(EntityTypeBuilder<DeliveryRowNoBodyEntity> builder)
        {
            builder.ToTable("DeliveryRowNoBody");
            builder.HasKey(d => d.Id);
            builder.Property(d => d.RowNo).IsRequired();
            builder.Property(d => d.Description).HasMaxLength(2000);
        }
    }

    public class DeliveryRowNoPolicyConfiguration : IEntityTypeConfiguration<DeliveryRowNoPolicyEntity>
    {
        public void Configure(EntityTypeBuilder<DeliveryRowNoPolicyEntity> builder)
        {
            builder.ToTable("DeliveryRowNoPolicy");
            builder.HasKey(d => d.Id);
            builder.Property(d => d.RowNo).IsRequired();
            builder.Property(d => d.Description).HasMaxLength(2000);
        }
    }

    public class DeliveryTransportDetailConfiguration : IEntityTypeConfiguration<DeliveryTransportDetailEntity>
    {
        public void Configure(EntityTypeBuilder<DeliveryTransportDetailEntity> builder)
        {
            builder.ToTable("DeliveryTransportDetail");
            builder.HasKey(d => d.Id);
            builder.Property(d => d.Description).HasMaxLength(2000);
        }
    }

    public class DeliveryTransportHeaderConfiguration : IEntityTypeConfiguration<DeliveryTransportHeaderEntity>
    {
        public void Configure(EntityTypeBuilder<DeliveryTransportHeaderEntity> builder)
        {
            builder.ToTable("DeliveryTransportHeader");
            builder.HasKey(d => d.Id);
            builder.Property(d => d.TransportNo).IsRequired().HasMaxLength(50);
            builder.Property(d => d.TransportDate).HasColumnType("datetime");
            builder.Property(d => d.Description).HasMaxLength(2000);
        }
    }

    public class DestDeliveryConfiguration : IEntityTypeConfiguration<DestDeliveryEntity>
    {
        public void Configure(EntityTypeBuilder<DestDeliveryEntity> builder)
        {
            builder.ToTable("DestDelivery");
            builder.HasKey(d => d.Id);
            builder.Property(d => d.DeliveryDate).HasColumnType("datetime");
            builder.Property(d => d.Description).HasMaxLength(2000);
        }
    }

    public class ListForExitConfiguration : IEntityTypeConfiguration<ListForExitEntity>
    {
        public void Configure(EntityTypeBuilder<ListForExitEntity> builder)
        {
            builder.ToTable("ListForExit");
            builder.HasKey(l => l.Id);
            builder.Property(l => l.ListNo).IsRequired().HasMaxLength(50);
            builder.Property(l => l.ListDate).HasColumnType("datetime");
            builder.Property(l => l.Description).HasMaxLength(2000);
            builder.Property(l => l.IsActive).IsRequired();
        }
    }

    public class ListForExitLogConfiguration : IEntityTypeConfiguration<ListForExitLogEntity>
    {
        public void Configure(EntityTypeBuilder<ListForExitLogEntity> builder)
        {
            builder.ToTable("ListForExitLog");
            builder.HasKey(l => l.Id);
            builder.Property(l => l.ActionDate).HasColumnType("datetime");
            builder.Property(l => l.ActionType).HasMaxLength(50);
            builder.Property(l => l.Description).HasMaxLength(2000);
        }
    }

    public class SltBlockDeliveryConfiguration : IEntityTypeConfiguration<SltBlockDeliveryEntity>
    {
        public void Configure(EntityTypeBuilder<SltBlockDeliveryEntity> builder)
        {
            builder.ToTable("SltBlockDelivery");
            builder.HasKey(s => s.Id);
            builder.Property(s => s.BlockNo).IsRequired().HasMaxLength(50);
            builder.Property(s => s.BlockDate).HasColumnType("datetime");
            builder.Property(s => s.Description).HasMaxLength(2000);
        }
    }
}
