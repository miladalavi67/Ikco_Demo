using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class PartConfiguration : IEntityTypeConfiguration<PartEntity>
    {
        public void Configure(EntityTypeBuilder<PartEntity> builder)
        {
            builder.ToTable("Parts");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.PartCode).IsRequired().HasMaxLength(50);
            builder.Property(p => p.PartName).IsRequired().HasMaxLength(200);
            builder.Property(p => p.UnitPrice).IsRequired().HasColumnType("decimal(18,2)");
            builder.Property(p => p.StockQty).IsRequired();
            builder.Property(p => p.MinStockQty).IsRequired();
            builder.Property(p => p.IsActive).IsRequired();
        }
    }

    public class CustomerConfiguration : IEntityTypeConfiguration<CustomerEntity>
    {
        public void Configure(EntityTypeBuilder<CustomerEntity> builder)
        {
            builder.ToTable("Customers");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.FullName).IsRequired().HasMaxLength(200);
            builder.Property(c => c.NationalCode).IsRequired().HasMaxLength(15);
            builder.Property(c => c.Mobile).IsRequired().HasMaxLength(20);
            builder.Property(c => c.Email).HasMaxLength(100);
            builder.Property(c => c.City).HasMaxLength(100);
            builder.Property(c => c.Address).HasMaxLength(500);
            builder.Property(c => c.IsActive).IsRequired();
        }
    }

    public class VehicleConfiguration : IEntityTypeConfiguration<VehicleEntity>
    {
        public void Configure(EntityTypeBuilder<VehicleEntity> builder)
        {
            builder.ToTable("Vehicles");
            builder.HasKey(v => v.Id);
            builder.Property(v => v.PlateNumber).IsRequired().HasMaxLength(20);
            builder.Property(v => v.Model).IsRequired().HasMaxLength(100);
            builder.Property(v => v.VIN).HasMaxLength(50);
        }
    }

    public class TechnicianConfiguration : IEntityTypeConfiguration<TechnicianEntity>
    {
        public void Configure(EntityTypeBuilder<TechnicianEntity> builder)
        {
            builder.ToTable("Technicians");
            builder.HasKey(t => t.Id);
            builder.Property(t => t.FullName).IsRequired().HasMaxLength(200);
            builder.Property(t => t.PersonnelCode).IsRequired().HasMaxLength(50);
            builder.Property(t => t.Specialty).HasMaxLength(100);
            builder.Property(t => t.HourlyRate).HasColumnType("decimal(18,2)");
            builder.Property(t => t.IsActive).IsRequired();
        }
    }

    public class ServiceRequestConfiguration : IEntityTypeConfiguration<ServiceRequestEntity>
    {
        public void Configure(EntityTypeBuilder<ServiceRequestEntity> builder)
        {
            builder.ToTable("ServiceRequests");
            builder.HasKey(sr => sr.Id);
            builder.Property(sr => sr.RequestNo).IsRequired().HasMaxLength(20);
            builder.Property(sr => sr.Description).HasMaxLength(2000);
            builder.Property(sr => sr.LaborHours).HasColumnType("decimal(18,2)");
            builder.Property(sr => sr.LaborCost).HasColumnType("decimal(18,2)");
            builder.Property(sr => sr.PartsCost).HasColumnType("decimal(18,2)");
            builder.Property(sr => sr.DiscountAmount).HasColumnType("decimal(18,2)");
            builder.Property(sr => sr.TotalCost).HasColumnType("decimal(18,2)");
        }
    }

    public class ServiceRequestPartConfiguration : IEntityTypeConfiguration<ServiceRequestPartEntity>
    {
        public void Configure(EntityTypeBuilder<ServiceRequestPartEntity> builder)
        {
            builder.ToTable("ServiceRequestParts");
            builder.HasKey(srp => srp.Id);
            builder.Property(srp => srp.Quantity).IsRequired();
            builder.Property(srp => srp.UnitPrice).HasColumnType("decimal(18,2)");
        }
    }

    public class ServiceStatusConfiguration : IEntityTypeConfiguration<ServiceStatusEntity>
    {
        public void Configure(EntityTypeBuilder<ServiceStatusEntity> builder)
        {
            builder.ToTable("ServiceStatuses");
            builder.HasKey(ss => ss.Id);
            builder.Property(ss => ss.StatusName).IsRequired().HasMaxLength(50);
        }
    }
}
