using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class BazdidStatusConfiguration : IEntityTypeConfiguration<BazdidStatusEntity>
    {
        public void Configure(EntityTypeBuilder<BazdidStatusEntity> builder)
        {
            builder.ToTable("BazdidStatus");
            builder.HasKey(b => b.Id);
            builder.Property(b => b.StatusName).IsRequired().HasMaxLength(200);
            builder.Property(b => b.Code).HasMaxLength(50);
            builder.Property(b => b.IsFinal).IsRequired();
            builder.Property(b => b.IsActive).IsRequired();
        }
    }

    public class NajiServiceConfiguration : IEntityTypeConfiguration<NajiServiceEntity>
    {
        public void Configure(EntityTypeBuilder<NajiServiceEntity> builder)
        {
            builder.ToTable("NajiService");
            builder.HasKey(n => n.Id);
            builder.Property(n => n.ServiceDate).HasColumnType("datetime");
            builder.Property(n => n.ServiceType).HasMaxLength(200);
            builder.Property(n => n.Description).HasMaxLength(2000);
            builder.Property(n => n.Cost).HasColumnType("decimal(18,2)");
        }
    }

    public class VisitTransactionConfiguration : IEntityTypeConfiguration<VisitTransactionEntity>
    {
        public void Configure(EntityTypeBuilder<VisitTransactionEntity> builder)
        {
            builder.ToTable("VisitTransaction");
            builder.HasKey(v => v.Id);
            builder.Property(v => v.TransactionDate).HasColumnType("datetime");
            builder.Property(v => v.Amount).HasColumnType("decimal(18,2)");
            builder.Property(v => v.Description).HasMaxLength(2000);
        }
    }
}
