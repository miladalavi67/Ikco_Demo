using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class CarLogConfiguration : IEntityTypeConfiguration<CarLogEntity>
    {
        public void Configure(EntityTypeBuilder<CarLogEntity> builder)
        {
            builder.ToTable("CarLog");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.Pelak).HasMaxLength(50);
            builder.Property(c => c.VIN).HasMaxLength(50);
            builder.Property(c => c.EnterDate).HasColumnType("datetime");
            builder.Property(c => c.ExitDate).HasColumnType("datetime");
            builder.Property(c => c.Description).HasMaxLength(2000);
            builder.Property(c => c.IsActive).IsRequired();
        }
    }

    public class CarReserveAgencyLogConfiguration : IEntityTypeConfiguration<CarReserveAgencyLogEntity>
    {
        public void Configure(EntityTypeBuilder<CarReserveAgencyLogEntity> builder)
        {
            builder.ToTable("CarReserveAgencyLog");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.ReserveDate).HasColumnType("datetime");
            builder.Property(c => c.ReleaseDate).HasColumnType("datetime");
            builder.Property(c => c.Description).HasMaxLength(2000);
        }
    }

    public class CarSaleConfiguration : IEntityTypeConfiguration<CarSaleEntity>
    {
        public void Configure(EntityTypeBuilder<CarSaleEntity> builder)
        {
            builder.ToTable("CarSale");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.SaleNo).IsRequired().HasMaxLength(50);
            builder.Property(c => c.SaleDate).HasColumnType("datetime");
            builder.Property(c => c.SaleAmount).HasColumnType("decimal(18,2)");
            builder.Property(c => c.Description).HasMaxLength(2000);
            builder.Property(c => c.IsActive).IsRequired();
        }
    }

    public class ContractDetailConfiguration : IEntityTypeConfiguration<ContractDetailEntity>
    {
        public void Configure(EntityTypeBuilder<ContractDetailEntity> builder)
        {
            builder.ToTable("ContractDetail");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.ItemName).IsRequired().HasMaxLength(200);
            builder.Property(c => c.Quantity).HasColumnType("decimal(18,2)");
            builder.Property(c => c.UnitPrice).HasColumnType("decimal(18,2)");
            builder.Property(c => c.TotalPrice).HasColumnType("decimal(18,2)");
            builder.Property(c => c.Description).HasMaxLength(2000);
        }
    }

    public class ContractHeaderConfiguration : IEntityTypeConfiguration<ContractHeaderEntity>
    {
        public void Configure(EntityTypeBuilder<ContractHeaderEntity> builder)
        {
            builder.ToTable("ContractHeader");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.ContractNo).IsRequired().HasMaxLength(50);
            builder.Property(c => c.ContractDate).HasColumnType("datetime");
            builder.Property(c => c.TotalAmount).HasColumnType("decimal(18,2)");
            builder.Property(c => c.Description).HasMaxLength(2000);
            builder.Property(c => c.IsActive).IsRequired();
        }
    }

    public class FactorHeaderConfiguration : IEntityTypeConfiguration<FactorHeaderEntity>
    {
        public void Configure(EntityTypeBuilder<FactorHeaderEntity> builder)
        {
            builder.ToTable("FactorHeader");
            builder.HasKey(f => f.Id);
            builder.Property(f => f.FactorNo).IsRequired().HasMaxLength(50);
            builder.Property(f => f.FactorDate).HasColumnType("datetime");
            builder.Property(f => f.TotalAmount).HasColumnType("decimal(18,2)");
            builder.Property(f => f.DiscountAmount).HasColumnType("decimal(18,2)");
            builder.Property(f => f.FinalAmount).HasColumnType("decimal(18,2)");
            builder.Property(f => f.Description).HasMaxLength(2000);
            builder.Property(f => f.IsActive).IsRequired();
        }
    }

    public class SaleStateConfiguration : IEntityTypeConfiguration<SaleStateEntity>
    {
        public void Configure(EntityTypeBuilder<SaleStateEntity> builder)
        {
            builder.ToTable("SaleState");
            builder.HasKey(s => s.Id);
            builder.Property(s => s.StateName).IsRequired().HasMaxLength(200);
            builder.Property(s => s.Code).HasMaxLength(50);
            builder.Property(s => s.IsFinal).IsRequired();
            builder.Property(s => s.IsActive).IsRequired();
        }
    }
}
