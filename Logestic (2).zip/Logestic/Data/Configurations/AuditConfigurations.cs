using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Logestic.Data.Entities;

namespace Logestic.Data.Configurations
{
    public class AuditDetailConfiguration : IEntityTypeConfiguration<AuditDetailEntity>
    {
        public void Configure(EntityTypeBuilder<AuditDetailEntity> builder)
        {
            builder.ToTable("AuditDetail");
            builder.HasKey(a => a.Id);
            builder.Property(a => a.AuditDate).HasColumnType("datetime");
            builder.Property(a => a.Description).HasMaxLength(2000);
            builder.Property(a => a.IsPassed).IsRequired();
        }
    }

    public class AuditTypeConfiguration : IEntityTypeConfiguration<AuditTypeEntity>
    {
        public void Configure(EntityTypeBuilder<AuditTypeEntity> builder)
        {
            builder.ToTable("AuditType");
            builder.HasKey(a => a.Id);
            builder.Property(a => a.TypeName).IsRequired().HasMaxLength(200);
            builder.Property(a => a.Code).HasMaxLength(50);
            builder.Property(a => a.IsActive).IsRequired();
        }
    }
}
