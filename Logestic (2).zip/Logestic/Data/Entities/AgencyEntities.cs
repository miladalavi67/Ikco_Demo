using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// نمایندگی - نمایندگی‌های ایران‌خودرو
    /// </summary>
    public class AgencyEntity
    {
        public int Id { get; set; }
        public string AgencyName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public int? TehranAgencyLocationId { get; set; }
        public string? Address { get; set; }
        public string? Phone { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// نمایندگی خودرو - اطلاعات نمایندگی‌های خودرو
    /// </summary>
    public class TCarAgencyEntity
    {
        public int Id { get; set; }
        public string AgencyCode { get; set; } = string.Empty;
        public string AgencyName { get; set; } = string.Empty;
        public int? TehranAgencyLocationId { get; set; }
        public string? Address { get; set; }
        public string? Phone { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// موقعیت نمایندگی تهران - موقعیت مکانی نمایندگی‌های تهران
    /// </summary>
    public class TehranAgencyLocationEntity
    {
        public int Id { get; set; }
        public string LocationName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public string? Address { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public bool IsActive { get; set; }
    }
}
