using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// نوع خودرو - انواع خودروهای موجود در سیستم لجستیک
    /// </summary>
    public class CarTypeEntity
    {
        public int Id { get; set; }
        public string TypeName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// راننده - راننده‌های حامل خودرو در لجستیک
    /// </summary>
    public class DriverEntity
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string? NationalCode { get; set; }
        public string? Mobile { get; set; }
        public int? DriverJobId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// شغل راننده - عناوین شغلی راننده‌ها
    /// </summary>
    public class DriverJobEntity
    {
        public int Id { get; set; }
        public string JobName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// دسترسی راننده به مرحله - سطح دسترسی راننده به مراحل جریان
    /// </summary>
    public class DriverStepAccessEntity
    {
        public int Id { get; set; }
        public int DriverId { get; set; }
        public int StepId { get; set; }
        public bool HasAccess { get; set; }
    }

    /// <summary>
    /// دسترسی کاربر به جریان - سطح دسترسی کاربر به جریان‌های لجستیک
    /// </summary>
    public class UserFlowAccessEntity
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int FlowId { get; set; }
        public bool HasAccess { get; set; }
    }

    /// <summary>
    /// دسترسی کاربر به منطقه - سطح دسترسی کاربر به مناطق لجستیک
    /// </summary>
    public class UserZoneAccessEntity
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int ZoneId { get; set; }
        public bool HasAccess { get; set; }
    }

    /// <summary>
    /// وضعیت بدنه - وضعیت بدنه خودرو در لجستیک
    /// </summary>
    public class BodyStateEntity
    {
        public int Id { get; set; }
        public string StateName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// تولید خودرو - اطلاعات تولید خودرو ایران‌خودرو
    /// </summary>
    public class TCarProdEntity
    {
        public int Id { get; set; }
        public string ProdCode { get; set; } = string.Empty;
        public string ProdName { get; set; } = string.Empty;
        public int? CarTypeId { get; set; }
        public DateTime? ProdDate { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// گزینه‌های شرکت عملیاتی (Opco) - تنظیمات شرکت‌های عملیاتی
    /// </summary>
    public class OpcoOptionEntity
    {
        public int Id { get; set; }
        public string OptionName { get; set; } = string.Empty;
        public string? OptionValue { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }
}
