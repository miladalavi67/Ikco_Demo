using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// جزئیات بازرسی - جزئیات بازرسی خودرو در سیستم لجستیک
    /// </summary>
    public class AuditDetailEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int? AuditTypeId { get; set; }
        public DateTime AuditDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsPassed { get; set; }
    }

    /// <summary>
    /// نوع بازرسی - انواع بازرسی‌های خودرو در لجستیک
    /// </summary>
    public class AuditTypeEntity
    {
        public int Id { get; set; }
        public string TypeName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }
}
