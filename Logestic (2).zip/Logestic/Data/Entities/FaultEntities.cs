using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// خرابی خودرو - ثبت خرابی‌های خودرو در سیستم لجستیک
    /// </summary>
    public class FaultEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int? FaultBodyId { get; set; }
        public int? FaultLevelId { get; set; }
        public int? FaultSourceId { get; set; }
        public DateTime FaultDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsResolved { get; set; }
    }

    /// <summary>
    /// بدنه خرابی - دسته‌بندی خرابی‌های خودرو
    /// </summary>
    public class FaultBodyEntity
    {
        public int Id { get; set; }
        public string BodyName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// سطح تشخیص خرابی - سطح تشخیص خرابی خودرو
    /// </summary>
    public class FaultDetectLevelEntity
    {
        public int Id { get; set; }
        public string LevelName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// سطح خرابی - شدت و سطح خرابی خودرو
    /// </summary>
    public class FaultLevelEntity
    {
        public int Id { get; set; }
        public string LevelName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public int Severity { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// قطعه خرابی - قطعات مرتبط با خرابی خودرو
    /// </summary>
    public class FaultPartEntity
    {
        public int Id { get; set; }
        public int FaultId { get; set; }
        public string PartCode { get; set; } = string.Empty;
        public string PartName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// منبع خرابی - منبع ایجاد خرابی خودرو
    /// </summary>
    public class FaultSourceEntity
    {
        public int Id { get; set; }
        public string SourceName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }
}
