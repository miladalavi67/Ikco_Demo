using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// سلول جایگذاری - محل قرارگیری خودرو در پارکینگ لجستیک
    /// </summary>
    public class CellEntity
    {
        public int Id { get; set; }
        public int ZoneId { get; set; }
        public int? PartitionId { get; set; }
        public string CellName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public int Capacity { get; set; }
        public int Occupied { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// ورود و خروج خودرو به/از سلول - سابقه جابجایی خودرو در سلول
    /// </summary>
    public class CellInOutEntity
    {
        public int Id { get; set; }
        public int CellId { get; set; }
        public int CarLogId { get; set; }
        public DateTime InDate { get; set; }
        public DateTime? OutDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// جایگزینی خودرو در سلول - انتقال خودرو بین سلول‌ها
    /// </summary>
    public class CellReplaceEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int FromCellId { get; set; }
        public int ToCellId { get; set; }
        public DateTime ReplaceDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// تاریخچه سلول - سوابق جایگذاری خودروها در سلول‌ها
    /// </summary>
    public class HistoryCellEntity
    {
        public int Id { get; set; }
        public int CellId { get; set; }
        public int CarLogId { get; set; }
        public DateTime ActionDate { get; set; }
        public string? ActionType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// پرداخت منطقه لجستیک - پرداخت‌های مربوط به مناطق لجستیک
    /// </summary>
    public class LogesticZonePaymentEntity
    {
        public int Id { get; set; }
        public int ZoneId { get; set; }
        public int CarLogId { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// پارتیشن - بخش‌بندی داخلی منطقه لجستیک
    /// </summary>
    public class PartitionEntity
    {
        public int Id { get; set; }
        public int ZoneId { get; set; }
        public string PartitionName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// منطقه لجستیک - منطقه اصلی لجستیک شامل سلول‌ها و پارتیشن‌ها
    /// </summary>
    public class ZoneEntity
    {
        public int Id { get; set; }
        public string ZoneName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public int? AgencyId { get; set; }
        public bool IsActive { get; set; }
    }
}
