using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// تست تحویل خودرو (PDI) - ثبت تست‌های قبل از تحویل خودرو
    /// </summary>
    public class PdiEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public DateTime PdiDate { get; set; }
        public int? AgencyId { get; set; }
        public bool IsPassed { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// جزئیات تست تحویل خودرو - آیتم‌های بررسی شده در PDI
    /// </summary>
    public class PdiDetailEntity
    {
        public int Id { get; set; }
        public int PdiId { get; set; }
        public string CheckItem { get; set; } = string.Empty;
        public bool IsOk { get; set; }
        public string? Description { get; set; }
    }
}
