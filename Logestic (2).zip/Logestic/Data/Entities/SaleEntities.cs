using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// لاگ خودرو - سوابق حرکت خودرو در سیستم لجستیک
    /// </summary>
    public class CarLogEntity
    {
        public int Id { get; set; }
        public string? Pelak { get; set; }
        public string? VIN { get; set; }
        public int? CarTypeId { get; set; }
        public int? CarSaleId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime? EnterDate { get; set; }
        public DateTime? ExitDate { get; set; }
        public int? CurrentCellId { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// لاگ رزرو نمایندگی خودرو - سوابق رزرو خودرو برای نمایندگی‌ها
    /// </summary>
    public class CarReserveAgencyLogEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int AgencyId { get; set; }
        public DateTime ReserveDate { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// فروش خودرو - اطلاعات فروش خودرو
    /// </summary>
    public class CarSaleEntity
    {
        public int Id { get; set; }
        public string SaleNo { get; set; } = string.Empty;
        public DateTime SaleDate { get; set; }
        public int? ContractHeaderId { get; set; }
        public int? FactorHeaderId { get; set; }
        public int? CustomerId { get; set; }
        public int? AgencyId { get; set; }
        public decimal SaleAmount { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// جزئیات قرارداد - جزئیات قرارداد فروش خودرو
    /// </summary>
    public class ContractDetailEntity
    {
        public int Id { get; set; }
        public int ContractHeaderId { get; set; }
        public string ItemName { get; set; } = string.Empty;
        public decimal Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// سربرگ قرارداد - سربرگ قرارداد فروش خودرو
    /// </summary>
    public class ContractHeaderEntity
    {
        public int Id { get; set; }
        public string ContractNo { get; set; } = string.Empty;
        public DateTime ContractDate { get; set; }
        public int? CustomerId { get; set; }
        public int? AgencyId { get; set; }
        public decimal TotalAmount { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// سربرگ فاکتور - فاکتور فروش خودرو
    /// </summary>
    public class FactorHeaderEntity
    {
        public int Id { get; set; }
        public string FactorNo { get; set; } = string.Empty;
        public DateTime FactorDate { get; set; }
        public int? ContractHeaderId { get; set; }
        public int? CustomerId { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal FinalAmount { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// وضعیت فروش - وضعیت‌های فروش خودرو
    /// </summary>
    public class SaleStateEntity
    {
        public int Id { get; set; }
        public string StateName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsFinal { get; set; }
        public bool IsActive { get; set; }
    }
}
