using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// رسید - رسید تحویل و دریافت خودرو در لجستیک
    /// </summary>
    public class ReceiptEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public string ReceiptNo { get; set; } = string.Empty;
        public DateTime ReceiptDate { get; set; }
        public string? ReceiptType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// جزئیات رسید - جزئیات اقلام رسید
    /// </summary>
    public class ReceiptDetailEntity
    {
        public int Id { get; set; }
        public int ReceiptId { get; set; }
        public string ItemName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public string? Description { get; set; }
    }
}
