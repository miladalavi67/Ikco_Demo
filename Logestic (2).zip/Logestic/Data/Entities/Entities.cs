using System;

namespace Logestic.Data.Entities
{
    public class PartEntity
    {
        public int Id { get; set; }
        public string PartCode { get; set; } = string.Empty;
        public string PartName { get; set; } = string.Empty;
        public decimal UnitPrice { get; set; }
        public int StockQty { get; set; }
        public int MinStockQty { get; set; }
        public bool IsActive { get; set; }
    }

    public class CustomerEntity
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string NationalCode { get; set; } = string.Empty;
        public string Mobile { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string? City { get; set; }
        public string? Address { get; set; }
        public bool IsActive { get; set; }
    }

    public class VehicleEntity
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public string PlateNumber { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int ProductionYear { get; set; }
        public string? VIN { get; set; }
        public int Mileage { get; set; }
    }

    public class TechnicianEntity
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string PersonnelCode { get; set; } = string.Empty;
        public string? Specialty { get; set; }
        public decimal HourlyRate { get; set; }
        public bool IsActive { get; set; }
    }

    public class ServiceRequestEntity
    {
        public int Id { get; set; }
        public string RequestNo { get; set; } = string.Empty;
        public int VehicleId { get; set; }
        public int CustomerId { get; set; }
        public int? TechnicianId { get; set; }
        public int StatusId { get; set; }
        public bool IsFinal { get; set; }
        public DateTime RequestDate { get; set; }
        public string? Description { get; set; }
        public decimal LaborHours { get; set; }
        public decimal LaborCost { get; set; }
        public decimal PartsCost { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal TotalCost { get; set; }
        public DateTime? CompletedDate { get; set; }
    }

    public class ServiceRequestPartEntity
    {
        public int Id { get; set; }
        public int RequestId { get; set; }
        public int PartId { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
    }

    public class ServiceStatusEntity
    {
        public int Id { get; set; }
        public string StatusName { get; set; } = string.Empty;
        public bool IsFinal { get; set; }
    }
}
