using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// درخواست ثبت - درخواست ثبت خودرو در سیستم لجستیک
    /// </summary>
    public class RegisterRequestEntity
    {
        public int Id { get; set; }
        public string RequestNo { get; set; } = string.Empty;
        public int CarLogId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime RequestDate { get; set; }
        public string? RequestType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsApproved { get; set; }
    }

    /// <summary>
    /// درخواست مدیریتی - درخواست‌های مدیریتی در لجستیک
    /// </summary>
    public class ManagementRequestEntity
    {
        public int Id { get; set; }
        public string RequestNo { get; set; } = string.Empty;
        public int CarLogId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime RequestDate { get; set; }
        public string? RequestType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsApproved { get; set; }
    }
}
