using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// عملیات بافر بازگشت گیت - عملیات موقت بازگشت خودرو به گیت
    /// </summary>
    public class RelapseBufferOperationEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int? ExitGateId { get; set; }
        public DateTime OperationDate { get; set; }
        public string? OperationType { get; set; }
        public string? Reason { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsProcessed { get; set; }
    }
}
