using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// لاگ جایگذاری پلاک - سوابق جابجایی پلاک خودرو
    /// </summary>
    public class PelakPlaceLogEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int PelakPlaceStateId { get; set; }
        public int? PelakPlaceStockId { get; set; }
        public DateTime ActionDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// وضعیت جایگذاری پلاک - وضعیت فعلی پلاک خودرو
    /// </summary>
    public class PelakPlaceStateEntity
    {
        public int Id { get; set; }
        public string StateName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// انبار پلاک - موجودی و محل نگهداری پلاک‌ها
    /// </summary>
    public class PelakPlaceStockEntity
    {
        public int Id { get; set; }
        public string StockName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public int? AgencyId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// دسترسی کاربر به انبار پلاک - سطح دسترسی کاربران به انبارهای پلاک
    /// </summary>
    public class PelakStockUserAccessEntity
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int PelakPlaceStockId { get; set; }
        public bool HasAccess { get; set; }
    }
}
