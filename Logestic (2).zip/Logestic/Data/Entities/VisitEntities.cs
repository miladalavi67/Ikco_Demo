using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// وضعیت بازدید - وضعیت‌های بازدید خودرو در لجستیک
    /// </summary>
    public class BazdidStatusEntity
    {
        public int Id { get; set; }
        public string StatusName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsFinal { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// خدمات ناجی - خدمات ارائه‌شده توسط ناجی در لجستیک
    /// </summary>
    public class NajiServiceEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public DateTime ServiceDate { get; set; }
        public string? ServiceType { get; set; }
        public string? Description { get; set; }
        public decimal? Cost { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// تراکنش بازدید - تراکنش‌های مالی بازدید خودرو
    /// </summary>
    public class VisitTransactionEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int BazdidStatusId { get; set; }
        public DateTime TransactionDate { get; set; }
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }
}
