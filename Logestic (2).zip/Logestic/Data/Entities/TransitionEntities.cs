using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// جریان - جریان‌های کاری لجستیک
    /// </summary>
    public class FlowEntity
    {
        public int Id { get; set; }
        public string FlowName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public int? FlowTypeId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// جریان نوع گذار - ارتباط نوع گذار با جریان
    /// </summary>
    public class FlowTypeTransitionEntity
    {
        public int Id { get; set; }
        public int FlowId { get; set; }
        public int TransitionId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// مرحله - مراحل جریان کاری لجستیک
    /// </summary>
    public class StepEntity
    {
        public int Id { get; set; }
        public string StepName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public int? FlowId { get; set; }
        public int OrderNo { get; set; }
        public bool IsFinal { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// گذار - گذارهای بین مراحل جریان کاری
    /// </summary>
    public class TransitionEntity
    {
        public int Id { get; set; }
        public int FromStepId { get; set; }
        public int ToStepId { get; set; }
        public string? TransitionName { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// نوع جریان کاربر - نوع جریان‌های اختصاصی کاربر
    /// </summary>
    public class UserFlowTypeEntity
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int FlowTypeId { get; set; }
        public bool HasAccess { get; set; }
    }

    /// <summary>
    /// نوع جریان - انواع جریان‌های کاری لجستیک
    /// </summary>
    public class FlowTypeEntity
    {
        public int Id { get; set; }
        public string TypeName { get; set; } = string.Empty;
        public string? Code { get; set; }
        public bool IsActive { get; set; }
    }
}
