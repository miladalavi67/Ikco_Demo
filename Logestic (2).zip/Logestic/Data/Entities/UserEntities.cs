using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// کاربر - کاربران سیستم لجستیک
    /// </summary>
    public class UserEntity
    {
        public int Id { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string? NationalCode { get; set; }
        public string? Mobile { get; set; }
        public string? Email { get; set; }
        public int? AgencyId { get; set; }
        public bool IsActive { get; set; }
        public DateTime? LastLoginDate { get; set; }
    }
}
