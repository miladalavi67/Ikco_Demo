using System;

namespace Logestic.Data.Entities
{
    /// <summary>
    /// ویووی بدنه بیچ - نمای بدنه‌های تحویلی
    /// </summary>
    public class BatchBodyViewEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public string? BodyNo { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// بیجک - ثبت بیجک تحویل خودرو
    /// </summary>
    public class BijakEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public string BijakNo { get; set; } = string.Empty;
        public DateTime BijakDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// شماره ردیف بدنه تحویل - شماره ردیف تحویل بدنه خودرو
    /// </summary>
    public class DeliveryRowNoBodyEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int RowNo { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// شماره ردیف پالیسی تحویل - شماره ردیف تحویل پالیسی خودرو
    /// </summary>
    public class DeliveryRowNoPolicyEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int RowNo { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// جزئیات حمل تحویل - جزئیات حمل و نقل تحویل خودرو
    /// </summary>
    public class DeliveryTransportDetailEntity
    {
        public int Id { get; set; }
        public int DeliveryTransportHeaderId { get; set; }
        public int CarLogId { get; set; }
        public string? Description { get; set; }
    }

    /// <summary>
    /// سربرگ حمل تحویل - سربرگ حمل و نقل تحویل خودرو
    /// </summary>
    public class DeliveryTransportHeaderEntity
    {
        public int Id { get; set; }
        public string TransportNo { get; set; } = string.Empty;
        public DateTime TransportDate { get; set; }
        public int? DriverId { get; set; }
        public int? AgencyId { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// تحویل مقصد - تحویل خودرو به مقصد نهایی
    /// </summary>
    public class DestDeliveryEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public int? AgencyId { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// لیست خروج - لیست خودروهای آماده خروج از لجستیک
    /// </summary>
    public class ListForExitEntity
    {
        public int Id { get; set; }
        public string ListNo { get; set; } = string.Empty;
        public DateTime ListDate { get; set; }
        public int? AgencyId { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
        public bool IsActive { get; set; }
    }

    /// <summary>
    /// لاگ لیست خروج - سوابق لیست‌های خروج
    /// </summary>
    public class ListForExitLogEntity
    {
        public int Id { get; set; }
        public int ListForExitId { get; set; }
        public int CarLogId { get; set; }
        public DateTime ActionDate { get; set; }
        public string? ActionType { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }

    /// <summary>
    /// بلاک تحویل Slt - بلاک‌های تحویلی ویژه
    /// </summary>
    public class SltBlockDeliveryEntity
    {
        public int Id { get; set; }
        public int CarLogId { get; set; }
        public string BlockNo { get; set; } = string.Empty;
        public DateTime BlockDate { get; set; }
        public string? Description { get; set; }
        public int? UserId { get; set; }
    }
}
