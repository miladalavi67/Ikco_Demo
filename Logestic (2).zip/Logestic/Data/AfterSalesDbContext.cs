using Microsoft.EntityFrameworkCore;
using Logestic.Data.Entities;

namespace Logestic.Data
{
    public class AfterSalesDbContext : DbContext
    {
        public AfterSalesDbContext(DbContextOptions<AfterSalesDbContext> options) : base(options) { }

        public DbSet<PartEntity> Parts => Set<PartEntity>();
        public DbSet<CustomerEntity> Customers => Set<CustomerEntity>();
        public DbSet<VehicleEntity> Vehicles => Set<VehicleEntity>();
        public DbSet<TechnicianEntity> Technicians => Set<TechnicianEntity>();
        public DbSet<ServiceRequestEntity> ServiceRequests => Set<ServiceRequestEntity>();
        public DbSet<ServiceRequestPartEntity> ServiceRequestParts => Set<ServiceRequestPartEntity>();
        public DbSet<ServiceStatusEntity> ServiceStatuses => Set<ServiceStatusEntity>();

        // Gate - گیت لجستیک
        public DbSet<EnterGateEntity> EnterGates => Set<EnterGateEntity>();
        public DbSet<ExitGateEntity> ExitGates => Set<ExitGateEntity>();
        public DbSet<RelapseGateOperationEntity> RelapseGateOperations => Set<RelapseGateOperationEntity>();

        // Placement - جایگذاری
        public DbSet<CellEntity> Cells => Set<CellEntity>();
        public DbSet<CellInOutEntity> CellInOuts => Set<CellInOutEntity>();
        public DbSet<CellReplaceEntity> CellReplaces => Set<CellReplaceEntity>();
        public DbSet<HistoryCellEntity> HistoryCells => Set<HistoryCellEntity>();
        public DbSet<LogesticZonePaymentEntity> LogesticZonePayments => Set<LogesticZonePaymentEntity>();
        public DbSet<PartitionEntity> Partitions => Set<PartitionEntity>();
        public DbSet<ZoneEntity> Zones => Set<ZoneEntity>();

        // Pelak - پلاک
        public DbSet<PelakPlaceLogEntity> PelakPlaceLogs => Set<PelakPlaceLogEntity>();
        public DbSet<PelakPlaceStateEntity> PelakPlaceStates => Set<PelakPlaceStateEntity>();
        public DbSet<PelakPlaceStockEntity> PelakPlaceStocks => Set<PelakPlaceStockEntity>();
        public DbSet<PelakStockUserAccessEntity> PelakStockUserAccesses => Set<PelakStockUserAccessEntity>();

        // Pdi - تست تحویل خودرو
        public DbSet<PdiEntity> Pdis => Set<PdiEntity>();
        public DbSet<PdiDetailEntity> PdiDetails => Set<PdiDetailEntity>();

        // Fault - خرابی
        public DbSet<FaultEntity> Faults => Set<FaultEntity>();
        public DbSet<FaultBodyEntity> FaultBodies => Set<FaultBodyEntity>();
        public DbSet<FaultDetectLevelEntity> FaultDetectLevels => Set<FaultDetectLevelEntity>();
        public DbSet<FaultLevelEntity> FaultLevels => Set<FaultLevelEntity>();
        public DbSet<FaultPartEntity> FaultParts => Set<FaultPartEntity>();
        public DbSet<FaultSourceEntity> FaultSources => Set<FaultSourceEntity>();

        // Audit - بازرسی
        public DbSet<AuditDetailEntity> AuditDetails => Set<AuditDetailEntity>();
        public DbSet<AuditTypeEntity> AuditTypes => Set<AuditTypeEntity>();

        // BaseInfo - اطلاعات پایه
        public DbSet<CarTypeEntity> CarTypes => Set<CarTypeEntity>();
        public DbSet<DriverEntity> Drivers => Set<DriverEntity>();
        public DbSet<DriverJobEntity> DriverJobs => Set<DriverJobEntity>();
        public DbSet<DriverStepAccessEntity> DriverStepAccesses => Set<DriverStepAccessEntity>();
        public DbSet<UserFlowAccessEntity> UserFlowAccesses => Set<UserFlowAccessEntity>();
        public DbSet<UserZoneAccessEntity> UserZoneAccesses => Set<UserZoneAccessEntity>();
        public DbSet<BodyStateEntity> BodyStates => Set<BodyStateEntity>();
        public DbSet<TCarProdEntity> TCarProds => Set<TCarProdEntity>();
        public DbSet<OpcoOptionEntity> OpcoOptions => Set<OpcoOptionEntity>();

        // Delivery - تحویل
        public DbSet<BatchBodyViewEntity> BatchBodyViews => Set<BatchBodyViewEntity>();
        public DbSet<BijakEntity> Bijaks => Set<BijakEntity>();
        public DbSet<DeliveryRowNoBodyEntity> DeliveryRowNoBodies => Set<DeliveryRowNoBodyEntity>();
        public DbSet<DeliveryRowNoPolicyEntity> DeliveryRowNoPolicies => Set<DeliveryRowNoPolicyEntity>();
        public DbSet<DeliveryTransportDetailEntity> DeliveryTransportDetails => Set<DeliveryTransportDetailEntity>();
        public DbSet<DeliveryTransportHeaderEntity> DeliveryTransportHeaders => Set<DeliveryTransportHeaderEntity>();
        public DbSet<DestDeliveryEntity> DestDeliveries => Set<DestDeliveryEntity>();
        public DbSet<ListForExitEntity> ListForExits => Set<ListForExitEntity>();
        public DbSet<ListForExitLogEntity> ListForExitLogs => Set<ListForExitLogEntity>();
        public DbSet<SltBlockDeliveryEntity> SltBlockDeliveries => Set<SltBlockDeliveryEntity>();

        // Sale - فروش
        public DbSet<CarLogEntity> CarLogs => Set<CarLogEntity>();
        public DbSet<CarReserveAgencyLogEntity> CarReserveAgencyLogs => Set<CarReserveAgencyLogEntity>();
        public DbSet<CarSaleEntity> CarSales => Set<CarSaleEntity>();
        public DbSet<ContractDetailEntity> ContractDetails => Set<ContractDetailEntity>();
        public DbSet<ContractHeaderEntity> ContractHeaders => Set<ContractHeaderEntity>();
        public DbSet<FactorHeaderEntity> FactorHeaders => Set<FactorHeaderEntity>();
        public DbSet<SaleStateEntity> SaleStates => Set<SaleStateEntity>();

        // Transition - گذار
        public DbSet<FlowEntity> Flows => Set<FlowEntity>();
        public DbSet<FlowTypeTransitionEntity> FlowTypeTransitions => Set<FlowTypeTransitionEntity>();
        public DbSet<StepEntity> Steps => Set<StepEntity>();
        public DbSet<TransitionEntity> Transitions => Set<TransitionEntity>();
        public DbSet<UserFlowTypeEntity> UserFlowTypes => Set<UserFlowTypeEntity>();
        public DbSet<FlowTypeEntity> FlowTypes => Set<FlowTypeEntity>();

        // User - کاربر
        public DbSet<UserEntity> Users => Set<UserEntity>();

        // Agency - نمایندگی
        public DbSet<AgencyEntity> Agencies => Set<AgencyEntity>();
        public DbSet<TCarAgencyEntity> TCarAgencies => Set<TCarAgencyEntity>();
        public DbSet<TehranAgencyLocationEntity> TehranAgencyLocations => Set<TehranAgencyLocationEntity>();

        // Visit - بازدید
        public DbSet<BazdidStatusEntity> BazdidStatuses => Set<BazdidStatusEntity>();
        public DbSet<NajiServiceEntity> NajiServices => Set<NajiServiceEntity>();
        public DbSet<VisitTransactionEntity> VisitTransactions => Set<VisitTransactionEntity>();

        // Repair - تعمیر
        public DbSet<RepairEntity> Repairs => Set<RepairEntity>();
        public DbSet<RepairDetailEntity> RepairDetails => Set<RepairDetailEntity>();

        // Receipt - رسید
        public DbSet<ReceiptEntity> Receipts => Set<ReceiptEntity>();
        public DbSet<ReceiptDetailEntity> ReceiptDetails => Set<ReceiptDetailEntity>();

        // RegisterRequest - درخواست ثبت
        public DbSet<RegisterRequestEntity> RegisterRequests => Set<RegisterRequestEntity>();
        public DbSet<ManagementRequestEntity> ManagementRequests => Set<ManagementRequestEntity>();

        // RelapseGateBuffer - بافر بازگشت گیت
        public DbSet<RelapseBufferOperationEntity> RelapseBufferOperations => Set<RelapseBufferOperationEntity>();

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.ApplyConfigurationsFromAssembly(typeof(AfterSalesDbContext).Assembly);
        }
    }
}
