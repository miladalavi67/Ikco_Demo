import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Dev mode: /api goes to the ASP.NET Core host, so no CORS in the browser.
      '/api': {
        target: 'http://localhost:44300',
        changeOrigin: true
      }
    }
  },
  build: {
    // Production mode: build straight into the host's wwwroot.
    outDir: '../src/IKCO.AfterSales.Demo/wwwroot',
    emptyOutDir: true
  }
})
