import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import PartsPage from './pages/PartsPage'

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<PartsPage />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}
