import { useCallback, useEffect, useState } from 'react'
import * as partsApi from '../api/parts'
import PartList from '../components/PartList'
import PartEdit from '../components/PartEdit'

const PAGE_SIZE = 10

export default function PartsPage() {
  const [mode, setMode] = useState('list')       // 'list' | 'edit'
  const [editing, setEditing] = useState(null)   // null = creating a new part

  const [items, setItems] = useState([])
  const [totalCount, setTotalCount] = useState(0)
  const [page, setPage] = useState(0)
  const [search, setSearch] = useState('')
  const [onlyLowStock, setOnlyLowStock] = useState(false)

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const result = await partsApi.getList({
        filter: search,
        onlyLowStock,
        skipCount: page * PAGE_SIZE,
        maxResultCount: PAGE_SIZE
      })
      setItems(result.items ?? [])
      setTotalCount(result.totalCount ?? 0)
    } catch (e) {
      setError(e.message)
      setItems([])
      setTotalCount(0)
    } finally {
      setLoading(false)
    }
  }, [search, onlyLowStock, page])

  // Debounce the search box so we don't fire a request per keystroke.
  useEffect(() => {
    const timer = setTimeout(load, 300)
    return () => clearTimeout(timer)
  }, [load])

  function handleSearchChange(value) {
    setPage(0)
    setSearch(value)
  }

  function handleLowStockChange(value) {
    setPage(0)
    setOnlyLowStock(value)
  }

  async function handleDelete(part) {
    if (!window.confirm(`قطعه «${part.partName}» حذف شود؟`)) return
    try {
      await partsApi.deletePart(part.id)
      await load()
    } catch (e) {
      setError(e.message)
    }
  }

  if (mode === 'edit') {
    return (
      <PartEdit
        part={editing}
        onSaved={async () => {
          setMode('list')
          setEditing(null)
          await load()
        }}
        onCancel={() => {
          setMode('list')
          setEditing(null)
        }}
      />
    )
  }

  return (
    <PartList
      items={items}
      totalCount={totalCount}
      page={page}
      pageSize={PAGE_SIZE}
      search={search}
      onlyLowStock={onlyLowStock}
      loading={loading}
      error={error}
      onSearchChange={handleSearchChange}
      onLowStockChange={handleLowStockChange}
      onPageChange={setPage}
      onAdd={() => {
        setEditing(null)
        setMode('edit')
      }}
      onEdit={(part) => {
        setEditing(part)
        setMode('edit')
      }}
      onDelete={handleDelete}
      onRetry={load}
    />
  )
}
