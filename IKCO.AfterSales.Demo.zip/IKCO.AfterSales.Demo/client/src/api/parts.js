const BASE = '/api/parts'

async function request(url, options) {
  const response = await fetch(url, options)

  if (!response.ok) {
    let message = `خطای سرور (${response.status})`
    try {
      const payload = await response.json()
      // ABP error shape: { error: { message, details } }
      message = payload?.error?.message || message
    } catch {
      /* body wasn't JSON */
    }
    throw new Error(message)
  }

  return response.status === 204 ? null : response.json()
}

/** @returns {Promise<{totalCount:number, items:Array}>} */
export function getList({ filter = '', onlyLowStock = false, skipCount = 0, maxResultCount = 10 } = {}) {
  const params = new URLSearchParams()
  if (filter) params.set('Filter', filter)
  if (onlyLowStock) params.set('OnlyLowStock', 'true')
  params.set('SkipCount', String(skipCount))
  params.set('MaxResultCount', String(maxResultCount))

  return request(`${BASE}?${params}`)
}

export function getById(id) {
  return request(`${BASE}/${id}`)
}

export function createPart(data) {
  return request(BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
}

export function updatePart(id, data) {
  return request(`${BASE}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
}

export function deletePart(id) {
  return request(`${BASE}/${id}`, { method: 'DELETE' })
}
