export default function PartList({
  items,
  totalCount,
  page,
  pageSize,
  search,
  onlyLowStock,
  loading,
  error,
  onSearchChange,
  onLowStockChange,
  onPageChange,
  onAdd,
  onEdit,
  onDelete,
  onRetry
}) {
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize))

  return (
    <div className="card">
      <div className="card-header">
        <h2>مدیریت قطعات</h2>
        <button className="btn btn-primary" onClick={onAdd}>+ قطعه جدید</button>
      </div>

      <div className="toolbar">
        <input
          type="text"
          className="search-box"
          placeholder="جستجو بر اساس کد یا نام قطعه..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
        />
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={onlyLowStock}
            onChange={(e) => onLowStockChange(e.target.checked)}
          />
          فقط قطعات کم‌موجودی
        </label>
      </div>

      {error && (
        <div className="alert alert-danger">
          <span>{error}</span>
          <button className="btn btn-secondary" onClick={onRetry}>تلاش دوباره</button>
        </div>
      )}

      {loading ? (
        <p className="muted">در حال بارگذاری...</p>
      ) : (
        <>
          <table className="table">
            <thead>
              <tr>
                <th>کد قطعه</th>
                <th>نام قطعه</th>
                <th>قیمت واحد (ریال)</th>
                <th>موجودی</th>
                <th>حداقل موجودی</th>
                <th>وضعیت</th>
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              {items.length === 0 ? (
                <tr>
                  <td colSpan="7" className="empty">قطعه‌ای یافت نشد</td>
                </tr>
              ) : (
                items.map((part) => (
                  <tr key={part.id}>
                    <td>{part.partCode}</td>
                    <td>{part.partName}</td>
                    <td>{part.unitPrice?.toLocaleString('fa-IR')}</td>
                    <td>
                      <span className={part.isLowStock ? 'badge badge-warning' : 'badge badge-success'}>
                        {part.stockQty?.toLocaleString('fa-IR')}
                      </span>
                    </td>
                    <td>{part.minStockQty?.toLocaleString('fa-IR')}</td>
                    <td>
                      <span className={part.isActive ? 'badge badge-success' : 'badge badge-danger'}>
                        {part.isActive ? 'فعال' : 'غیرفعال'}
                      </span>
                    </td>
                    <td className="actions">
                      <button className="btn btn-secondary" onClick={() => onEdit(part)}>ویرایش</button>
                      <button className="btn btn-danger" onClick={() => onDelete(part)}>حذف</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          <div className="pagination">
            <button
              className="btn btn-secondary"
              disabled={page === 0}
              onClick={() => onPageChange(page - 1)}
            >
              قبلی
            </button>
            <span className="page-info">
              صفحه {(page + 1).toLocaleString('fa-IR')} از {totalPages.toLocaleString('fa-IR')}
              {' · '}
              {totalCount.toLocaleString('fa-IR')} قطعه
            </span>
            <button
              className="btn btn-secondary"
              disabled={page >= totalPages - 1}
              onClick={() => onPageChange(page + 1)}
            >
              بعدی
            </button>
          </div>
        </>
      )}
    </div>
  )
}
