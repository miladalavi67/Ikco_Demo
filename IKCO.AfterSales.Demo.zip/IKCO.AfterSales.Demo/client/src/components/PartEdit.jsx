import { useEffect, useState } from 'react'
import * as partsApi from '../api/parts'

const EMPTY = {
  partCode: '',
  partName: '',
  unitPrice: 0,
  stockQty: 0,
  minStockQty: 0,
  isActive: true
}

function toForm(part) {
  if (!part) return EMPTY
  return {
    partCode: part.partCode ?? '',
    partName: part.partName ?? '',
    unitPrice: part.unitPrice ?? 0,
    stockQty: part.stockQty ?? 0,
    minStockQty: part.minStockQty ?? 0,
    isActive: part.isActive ?? true
  }
}

export default function PartEdit({ part, onSaved, onCancel }) {
  // Lazy initializer: correct on the very first render, no empty flash.
  const [form, setForm] = useState(() => toForm(part))
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    setForm(toForm(part))
  }, [part])

  function handleChange(e) {
    const { name, value, type, checked } = e.target
    setForm((prev) => ({
      ...prev,
      // Number inputs hand back strings; the API expects numbers.
      [name]: type === 'checkbox' ? checked : type === 'number' ? Number(value) : value
    }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setError(null)
    try {
      if (part) {
        await partsApi.updatePart(part.id, form)
      } else {
        await partsApi.createPart(form)
      }
      await onSaved()
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="card">
      <div className="card-header">
        <h2>{part ? 'ویرایش قطعه' : 'افزودن قطعه جدید'}</h2>
        <button className="btn btn-secondary" onClick={onCancel}>بازگشت</button>
      </div>

      {error && <div className="alert alert-danger"><span>{error}</span></div>}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>کد قطعه</label>
          <input type="text" name="partCode" value={form.partCode}
                 onChange={handleChange} required maxLength={20} />
        </div>

        <div className="form-group">
          <label>نام قطعه</label>
          <input type="text" name="partName" value={form.partName}
                 onChange={handleChange} required maxLength={100} />
        </div>

        <div className="form-group">
          <label>قیمت واحد (ریال)</label>
          <input type="number" name="unitPrice" value={form.unitPrice}
                 onChange={handleChange} required min="0" step="1000" />
        </div>

        <div className="form-group">
          <label>موجودی</label>
          <input type="number" name="stockQty" value={form.stockQty}
                 onChange={handleChange} required min="0" />
        </div>

        <div className="form-group">
          <label>حداقل موجودی</label>
          <input type="number" name="minStockQty" value={form.minStockQty}
                 onChange={handleChange} required min="0" />
        </div>

        <div className="form-group">
          <label className="checkbox-label">
            <input type="checkbox" name="isActive" checked={form.isActive} onChange={handleChange} />
            فعال
          </label>
        </div>

        <div className="form-actions">
          <button type="submit" className="btn btn-success" disabled={saving}>
            {saving ? 'در حال ذخیره...' : 'ذخیره'}
          </button>
          <button type="button" className="btn btn-secondary" onClick={onCancel} disabled={saving}>
            انصراف
          </button>
        </div>
      </form>
    </div>
  )
}
