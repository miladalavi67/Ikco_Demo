import { Outlet, Link, useLocation } from 'react-router-dom'

const navItems = [
  { path: '/', label: 'قطعات', icon: '🔧' },
]

export default function Layout({ children }) {
  const location = useLocation()
  
  return (
    <div className="app">
      <header className="header">
        <div className="container">
          <h1 className="logo">سامانه خدمات پس از فروش</h1>
          <nav className="nav">
            {navItems.map(item => (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-link ${location.pathname === item.path ? 'active' : ''}`}
              >
                {item.icon} {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </header>
      <main className="main">
        <div className="container">
          {children}
        </div>
      </main>
    </div>
  )
}
