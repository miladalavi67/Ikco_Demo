# IKCO.AfterSales — نسخهٔ دمو

هدف این نسخه فقط یک چیز است: **بدون دردسر بالا بیاید**. یک پروژه، یک Entity، LocalDB، بدون Migration.

## اجرا — حالت الف: دو ترمینال (توسعه)

```
1) IKCO.AfterSales.Demo.sln را در Visual Studio باز کن → F5
   → http://localhost:44300

2) در ترمینال جدا:
   cd client
   npm install
   npm run dev
   → http://localhost:5173
```

Vite مسیر `/api` را به بک‌اند پروکسی می‌کند، پس مرورگر اصلاً CORS نمی‌بیند. تغییرات ری‌اکت هم hot-reload می‌شوند — برای توسعه این حالت بهتر است.

## اجرا — حالت ب: یک URL (ارائهٔ دمو)

```
cd client
npm install
npm run build      ← خروجی مستقیم داخل wwwroot می‌رود
```

بعد در ویژوال استودیو F5 بزن و فقط `http://localhost:44300` را باز کن. کل UI از همان‌جا سرو می‌شود.

برای ارائه، حالت ب امن‌تر است: یک پنجره، یک آدرس، بدون وابستگی به ترمینال دوم.

## دیتابیس

`(localdb)\MSSQLLocalDB` — همراه ویژوال استودیو نصب است، نیازی به هیچ تنظیمی نیست.

در اولین اجرا:
- `EnsureCreatedAsync()` دیتابیس `IKCO_AfterSales_Demo` و جدول `Parts` را می‌سازد
- `DemoDataSeeder` ده قطعهٔ نمونه با نام فارسی درج می‌کند (چندتایشان عمداً کم‌موجودی‌اند تا badge نارنجی در دمو دیده شود)

هر دو عملیات idempotent هستند. برای ریست کردن دیتا:

```powershell
sqllocaldb stop MSSQLLocalDB
# یا در SSMS: DROP DATABASE IKCO_AfterSales_Demo
```

اگر SQL Server کامل داری و LocalDB نمی‌خواهی، فقط connection string در `appsettings.json` را عوض کن.

> `EnsureCreated` عمداً به‌جای Migration استفاده شده. برای دمو عالی است، برای Production نه — آنجا باید `Add-Migration` بزنی.

## API

| متد | مسیر |
|---|---|
| GET | `/api/parts?Filter=&OnlyLowStock=&SkipCount=0&MaxResultCount=10` |
| GET | `/api/parts/{id}` |
| POST | `/api/parts` |
| PUT | `/api/parts/{id}` |
| DELETE | `/api/parts/{id}` |

برای تست سریع بک‌اند بدون UI، در مرورگر باز کن: `http://localhost:44300/api/parts`

## باگ‌های UI که رفع شد

| مشکل | توضیح |
|---|---|
| `pages/PartList.jsx` خودش را import می‌کرد | حلقهٔ بی‌نهایت؛ به `pages/PartsPage.jsx` تغییر نام یافت و از `components/PartList` import می‌کند |
| دو بار fetch همزمان | صفحه داده را می‌گرفت و prop می‌داد، ولی کامپوننت داخلی prop را نادیده می‌گرفت و خودش دوباره fetch می‌کرد. حالا صفحه state دارد، کامپوننت فقط نمایشی است |
| `part.partId` | بک‌اند `id` برمی‌گرداند، نه `partId` — کلید React و مسیر ویرایش هر دو خراب بودند |
| هر کاراکتر تایپ = یک request | debounce سیصد میلی‌ثانیه‌ای |
| `fixtures/parts.js` | فایل `.js` که محتوایش JSON خام بود (syntax error). حذف شد |
| خطاها فقط در console | حالا بنر قرمز با پیام فارسی و دکمهٔ «تلاش دوباره» |
| ورودی عددی رشته می‌فرستاد | با `Number()` تبدیل می‌شود |
| صفحه‌بندی سمت کلاینت روی دادهٔ ناقص | حالا `SkipCount`/`MaxResultCount` واقعی به سرور می‌رود |

دکمهٔ حذف هم اضافه شد چون بک‌اند داشت ولی UI استفاده نمی‌کرد.

## اگر Build نشد

هنوز نتوانسته‌ام کد را کامپایل کنم (این محیط .NET SDK ندارد). این نسخه عمداً کم‌ریسک نوشته شده — بدون Serilog، بدون Swagger، بدون AutoMapper، بدون localization — ولی اگر خطایی دیدی، خروجی Error List را بفرست.

مشکوک‌ترین خط، این است:

```csharp
app.UseConfiguredEndpoints(endpoints => { endpoints.MapFallbackToFile("index.html"); });
```

اگر ایراد گرفت، به این تغییرش بده و حالت الف (دو ترمینال) را استفاده کن:

```csharp
app.UseConfiguredEndpoints();
```
