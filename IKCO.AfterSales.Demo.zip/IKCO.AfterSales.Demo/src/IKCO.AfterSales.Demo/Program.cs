using System.Threading.Tasks;
using IKCO.AfterSales.Demo;
using Microsoft.AspNetCore.Builder;
using Volo.Abp;

var builder = WebApplication.CreateBuilder(args);

builder.Host.UseAutofac();

await builder.AddApplicationAsync<DemoModule>();

var app = builder.Build();

await app.InitializeApplicationAsync();
await app.RunAsync();
