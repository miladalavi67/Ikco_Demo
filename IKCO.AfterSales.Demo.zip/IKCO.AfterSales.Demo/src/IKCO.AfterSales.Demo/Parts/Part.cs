using System;
using Volo.Abp.Domain.Entities.Auditing;

namespace IKCO.AfterSales.Demo.Parts;

public class Part : AuditedAggregateRoot<Guid>
{
    public string PartCode { get; set; } = string.Empty;
    public string PartName { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public int StockQty { get; set; }
    public int MinStockQty { get; set; }
    public bool IsActive { get; set; } = true;

    protected Part()
    {
    }

    public Part(Guid id) : base(id)
    {
    }
}
