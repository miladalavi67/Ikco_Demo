using System;
using System.Linq;
using System.Threading.Tasks;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;

namespace IKCO.AfterSales.Demo.Parts;

public interface IPartAppService : IApplicationService
{
    Task<PagedResultDto<PartDto>> GetListAsync(GetPartListInput input);
    Task<PartDto> GetAsync(Guid id);
    Task<PartDto> CreateAsync(CreateUpdatePartDto input);
    Task<PartDto> UpdateAsync(Guid id, CreateUpdatePartDto input);
    Task DeleteAsync(Guid id);
}

public class PartAppService : ApplicationService, IPartAppService
{
    private readonly IRepository<Part, Guid> _partRepository;

    public PartAppService(IRepository<Part, Guid> partRepository)
    {
        _partRepository = partRepository;
    }

    public async Task<PagedResultDto<PartDto>> GetListAsync(GetPartListInput input)
    {
        var query = await _partRepository.GetQueryableAsync();

        if (!string.IsNullOrWhiteSpace(input.Filter))
        {
            var filter = input.Filter.Trim();
            query = query.Where(p => p.PartCode.Contains(filter) || p.PartName.Contains(filter));
        }

        if (input.OnlyLowStock == true)
        {
            query = query.Where(p => p.StockQty <= p.MinStockQty);
        }

        var totalCount = await AsyncExecuter.CountAsync(query);

        var items = await AsyncExecuter.ToListAsync(
            query.OrderBy(p => p.PartCode)
                 .Skip(input.SkipCount)
                 .Take(input.MaxResultCount));

        return new PagedResultDto<PartDto>(totalCount, items.Select(MapToDto).ToList());
    }

    public async Task<PartDto> GetAsync(Guid id)
    {
        return MapToDto(await _partRepository.GetAsync(id));
    }

    public async Task<PartDto> CreateAsync(CreateUpdatePartDto input)
    {
        await CheckCodeIsUniqueAsync(input.PartCode);

        var part = new Part(GuidGenerator.Create());
        Apply(part, input);

        await _partRepository.InsertAsync(part, autoSave: true);

        return MapToDto(part);
    }

    public async Task<PartDto> UpdateAsync(Guid id, CreateUpdatePartDto input)
    {
        var part = await _partRepository.GetAsync(id);

        if (!string.Equals(part.PartCode, input.PartCode.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            await CheckCodeIsUniqueAsync(input.PartCode);
        }

        Apply(part, input);

        await _partRepository.UpdateAsync(part, autoSave: true);

        return MapToDto(part);
    }

    public async Task DeleteAsync(Guid id)
    {
        await _partRepository.DeleteAsync(id, autoSave: true);
    }

    private async Task CheckCodeIsUniqueAsync(string partCode)
    {
        var code = partCode.Trim();
        var existing = await _partRepository.FindAsync(p => p.PartCode == code);

        if (existing != null)
        {
            throw new UserFriendlyException($"قطعه‌ای با کد «{code}» از قبل ثبت شده است.");
        }
    }

    private static void Apply(Part part, CreateUpdatePartDto input)
    {
        part.PartCode = input.PartCode.Trim();
        part.PartName = input.PartName.Trim();
        part.UnitPrice = input.UnitPrice;
        part.StockQty = input.StockQty;
        part.MinStockQty = input.MinStockQty;
        part.IsActive = input.IsActive;
    }

    private static PartDto MapToDto(Part p) => new()
    {
        Id = p.Id,
        PartCode = p.PartCode,
        PartName = p.PartName,
        UnitPrice = p.UnitPrice,
        StockQty = p.StockQty,
        MinStockQty = p.MinStockQty,
        IsActive = p.IsActive,
        IsLowStock = p.StockQty <= p.MinStockQty
    };
}
