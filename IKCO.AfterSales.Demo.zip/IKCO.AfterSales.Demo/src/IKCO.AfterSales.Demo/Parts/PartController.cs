using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp.Application.Dtos;
using Volo.Abp.AspNetCore.Mvc;

namespace IKCO.AfterSales.Demo.Parts;

[ApiController]
[Route("api/parts")]
public class PartController : AbpControllerBase
{
    private readonly IPartAppService _partAppService;

    public PartController(IPartAppService partAppService)
    {
        _partAppService = partAppService;
    }

    [HttpGet]
    public Task<PagedResultDto<PartDto>> GetListAsync([FromQuery] GetPartListInput input)
        => _partAppService.GetListAsync(input);

    [HttpGet("{id}")]
    public Task<PartDto> GetAsync(Guid id)
        => _partAppService.GetAsync(id);

    [HttpPost]
    public Task<PartDto> CreateAsync([FromBody] CreateUpdatePartDto input)
        => _partAppService.CreateAsync(input);

    [HttpPut("{id}")]
    public Task<PartDto> UpdateAsync(Guid id, [FromBody] CreateUpdatePartDto input)
        => _partAppService.UpdateAsync(id, input);

    [HttpDelete("{id}")]
    public Task DeleteAsync(Guid id)
        => _partAppService.DeleteAsync(id);
}
