using System;
using System.ComponentModel.DataAnnotations;
using Volo.Abp.Application.Dtos;

namespace IKCO.AfterSales.Demo.Parts;

public class PartDto : EntityDto<Guid>
{
    public string PartCode { get; set; } = string.Empty;
    public string PartName { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public int StockQty { get; set; }
    public int MinStockQty { get; set; }
    public bool IsActive { get; set; }
    public bool IsLowStock { get; set; }
}

public class GetPartListInput : PagedAndSortedResultRequestDto
{
    public string? Filter { get; set; }
    public bool? OnlyLowStock { get; set; }
}

public class CreateUpdatePartDto
{
    [Required]
    [StringLength(20)]
    public string PartCode { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string PartName { get; set; } = string.Empty;

    [Range(0, 999999999)]
    public decimal UnitPrice { get; set; }

    [Range(0, 1000000)]
    public int StockQty { get; set; }

    [Range(0, 1000000)]
    public int MinStockQty { get; set; }

    public bool IsActive { get; set; } = true;
}
