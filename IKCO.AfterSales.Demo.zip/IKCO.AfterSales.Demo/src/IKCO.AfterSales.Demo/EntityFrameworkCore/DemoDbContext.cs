using IKCO.AfterSales.Demo.Parts;
using Microsoft.EntityFrameworkCore;
using Volo.Abp.Data;
using Volo.Abp.EntityFrameworkCore;
using Volo.Abp.EntityFrameworkCore.Modeling;

namespace IKCO.AfterSales.Demo.EntityFrameworkCore;

[ConnectionStringName("Default")]
public class DemoDbContext : AbpDbContext<DemoDbContext>
{
    public DbSet<Part> Parts { get; set; } = null!;

    public DemoDbContext(DbContextOptions<DemoDbContext> options)
        : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Part>(b =>
        {
            b.ToTable("Parts");
            b.ConfigureByConvention();

            b.Property(x => x.PartCode).IsRequired().HasMaxLength(20);
            b.Property(x => x.PartName).IsRequired().HasMaxLength(100);
            b.Property(x => x.UnitPrice).HasColumnType("decimal(18,2)");

            b.HasIndex(x => x.PartCode).IsUnique();
        });
    }
}
