using System.Threading.Tasks;
using IKCO.AfterSales.Demo.Data;
using IKCO.AfterSales.Demo.EntityFrameworkCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Volo.Abp;
using Volo.Abp.Application;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.Autofac;
using Volo.Abp.EntityFrameworkCore;
using Volo.Abp.EntityFrameworkCore.SqlServer;
using Volo.Abp.Modularity;
using Volo.Abp.Uow;

namespace IKCO.AfterSales.Demo;

[DependsOn(
    typeof(AbpAutofacModule),
    typeof(AbpAspNetCoreMvcModule),
    typeof(AbpDddApplicationModule),
    typeof(AbpEntityFrameworkCoreSqlServerModule)
)]
public class DemoModule : AbpModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAbpDbContext<DemoDbContext>(options =>
        {
            options.AddDefaultRepositories(includeAllEntities: true);
        });

        Configure<AbpDbContextOptions>(options =>
        {
            options.UseSqlServer();
        });

        // Wide-open CORS: this is a demo host, not a production API.
        context.Services.AddCors(options =>
        {
            options.AddDefaultPolicy(builder => builder
                .AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod());
        });
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var app = context.GetApplicationBuilder();

        app.UseDeveloperExceptionPage();
        app.UseDefaultFiles();   // serves wwwroot/index.html at "/"
        app.UseStaticFiles();
        app.UseRouting();
        app.UseCors();
        app.UseUnitOfWork();

        app.UseConfiguredEndpoints(endpoints =>
        {
            // SPA fallback: any non-API route returns index.html so
            // react-router can handle it. No-op when wwwroot is empty.
            endpoints.MapFallbackToFile("index.html");
        });
    }

    public override async Task OnPostApplicationInitializationAsync(ApplicationInitializationContext context)
    {
        using var scope = context.ServiceProvider.CreateScope();
        var uowManager = scope.ServiceProvider.GetRequiredService<IUnitOfWorkManager>();

        using var uow = uowManager.Begin(requiresNew: true, isTransactional: false);

        var dbContext = await scope.ServiceProvider
            .GetRequiredService<IDbContextProvider<DemoDbContext>>()
            .GetDbContextAsync();

        // No migrations needed for a demo: create the schema if it isn't there.
        await dbContext.Database.EnsureCreatedAsync();

        await scope.ServiceProvider.GetRequiredService<DemoDataSeeder>().SeedAsync();

        await uow.CompleteAsync();
    }
}
