using System;
using System.Threading.Tasks;
using IKCO.AfterSales.Demo.Parts;
using Volo.Abp.DependencyInjection;
using Volo.Abp.Domain.Repositories;
using Volo.Abp.Guids;

namespace IKCO.AfterSales.Demo.Data;

/// <summary>Fills the table with sample rows so the demo has something to show.</summary>
public class DemoDataSeeder : ITransientDependency
{
    private readonly IRepository<Part, Guid> _partRepository;
    private readonly IGuidGenerator _guidGenerator;

    public DemoDataSeeder(IRepository<Part, Guid> partRepository, IGuidGenerator guidGenerator)
    {
        _partRepository = partRepository;
        _guidGenerator = guidGenerator;
    }

    public async Task SeedAsync()
    {
        if (await _partRepository.GetCountAsync() > 0)
        {
            return;
        }

        await _partRepository.InsertManyAsync(new[]
        {
            Create("P-1001", "لنت ترمز جلو سمند", 2_450_000m, 50, 10),
            Create("P-1002", "روغن موتور 10W40 بهران", 1_180_000m, 8, 15),
            Create("P-1003", "فیلتر هوا پژو ۴۰۵", 450_000m, 100, 20),
            Create("P-1004", "شمع موتور NGK", 350_000m, 3, 10),
            Create("P-1005", "دیسک ترمز عقب دنا", 3_900_000m, 24, 8),
            Create("P-1006", "تسمه تایم تیبا", 1_650_000m, 12, 12),
            Create("P-1007", "واشر سرسیلندر پراید", 890_000m, 5, 6),
            Create("P-1008", "پمپ بنزین رانا", 5_200_000m, 31, 5),
            Create("P-1009", "کمک فنر جلو سورن", 4_100_000m, 18, 6),
            Create("P-1010", "باتری ۷۴ آمپر سپاهان", 8_750_000m, 2, 4)
        }, autoSave: true);
    }

    private Part Create(string code, string name, decimal price, int stock, int minStock)
    {
        return new Part(_guidGenerator.Create())
        {
            PartCode = code,
            PartName = name,
            UnitPrice = price,
            StockQty = stock,
            MinStockQty = minStock,
            IsActive = true
        };
    }
}
